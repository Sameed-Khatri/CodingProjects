public class Driver {
    public static void main(String[] args) {
        Employee[] a = new Employee[5];
        Employee obj1 = new HourlyEmployee("Mr", "ABC", 12, 40);
        Employee obj2 = new HourlyEmployee("Mr", "CDE", 10, 40);
        Employee obj3 = new SalaryEmployee("Mr", "GHI", 120);
        Employee obj4 = new SalaryEmployee("Mr", "JKL", 140);
        Employee obj5 = new SalaryEmployee("Mr", "KZX", 100);
        a[0]=obj1;
        a[1]=obj2;
        a[2]=obj3;
        a[3]=obj4;
        a[4]=obj5;
        for(int i=0;i<a.length;i++){
            System.out.println(a[i]);
        }
    }
}
