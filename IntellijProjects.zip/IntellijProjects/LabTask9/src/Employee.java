public class Employee {
    protected String fname;
    protected String lname;
    public Employee(String fn, String ln){
        fname=fn;
        lname=ln;
    }
    public String getFname(){
        return fname;
    }
    public String getLname(){
        return lname;
    }
    public void setFname(String f){
        fname=f;
    }
    public void setLname(String l){
        lname=l;
    }
    public String toString(){
        String s="First Name: "+fname+"  Last Name: "+lname;

        return s;
    }
}
class SalaryEmployee extends Employee{
    double WeeklySalary;
    public SalaryEmployee(String fn, String ln, double WS) {
        super(fn, ln);
        WeeklySalary=WS;
    }
    public void setWeeklySalary(double WeekSal){
        WeeklySalary=WeekSal;
    }
    public double getWeeklySalary(){
        return WeeklySalary;
    }
    public double Earnings(){
        return WeeklySalary*4;
    }
    public String toString(){
        String s="  Monthly earnings: "+Earnings();
        return super.toString()+s;
    }
}
class HourlyEmployee extends Employee{
    double HourlyWage;
    int NoHoursWorked;
    public HourlyEmployee(String fn, String ln, double HW, int NHW) {
        super(fn, ln);
        HourlyWage=HW;
        NoHoursWorked=NHW;
    }
    public void setHourlyWage(double HrlyW){
        HourlyWage=HrlyW;
    }
    public void setNoHoursWorked(int NohrsW){
        NoHoursWorked=NohrsW;
    }
    public double getHourlyWage() {
        return HourlyWage;
    }
    public int getNoHoursWorked(){
        return NoHoursWorked;
    }
    public double Earnings(){
        return NoHoursWorked*HourlyWage;
    }
    public String toString(){
        String s="  Working Hours: "+NoHoursWorked+"  Hourly Wage:"+HourlyWage+"  Total Earnings:"+Earnings();
        return super.toString()+s;
    }
}

