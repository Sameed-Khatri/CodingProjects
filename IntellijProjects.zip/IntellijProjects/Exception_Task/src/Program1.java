import java.util.InputMismatchException;

public class Program1 {
    public static void main(String[] args) {
        try{
            int numerator=5;
            int denominator=0;
            System.out.println(numerator/denominator);}
        catch(ArithmeticException e){
            System.out.println("Error"+e.getMessage());
            System.out.println("Error"+e);
        }
        catch (InputMismatchException e){
            System.out.println("Invalid Input");
        }
        finally {
            System.out.println("End Point");
        }
    }
}
