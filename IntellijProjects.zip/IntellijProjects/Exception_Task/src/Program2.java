import java.util.InputMismatchException;
import java.util.Scanner;

public class Program2 {
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        int num = 0;
        try{
            do {
                System.out.println("Enter a number between 1 and 10");
                num = scan.nextInt();
                if (num < 1 || num > 10)
                    System.out.println("\nIllegal value, " + num + " entered.  Please try again.");
            }  while (num < 1 || num > 10);
            System.out.println("\nValue correctly entered! Thank you.");}
        catch(InputMismatchException e) {
            InputMismatch obj= new InputMismatch("invalid value entered");
            System.out.println(obj);
            System.out.println("Enter whole numbers only, with no spaces or other characters");
            scan.next();// clear the scanner buffer
        }
    }
}
class InputMismatch extends Exception{
    String s;
    public InputMismatch(){

    }
    public InputMismatch(String in){
        super(in);
        s=in;
    }
}
