import java.util.ArrayList;
import java.util.Collections;

public class Card {
    public enum Suit{
        Diamond,Club,Heart,Spade
    }
    public enum Rank {
        ACE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN, JACK, QUEEN, KING
    }
    public final  Rank rank;
    public final Suit suit;
    public Card( Suit suit1, Rank rank1){
        this.suit=suit1;
        this.rank = rank1;
    }

    public Rank getRank() {
        return rank;
    }

    public Suit getSuit() {
        return suit;
    }
    public int getValue(){
        return rank.ordinal()+1;
    }

    public String toString(){
        return rank+"of"+suit;
    }
}
class CardDeck{
    Card.Rank rank;
    Card.Suit suit;
    ArrayList deck=new ArrayList<>();
    CardDeck(){
        for(Card.Suit: Card.Suit.values()){
            for(Card.Rank:Card.Rank.values()){
                deck.add(new Card(suit,rank));
            }
        }
    }
    public void shuffle(){
        Collections.shuffle(deck);
    }
    public void print(){
        System.out.println(deck);
    }
}
class CardTest{
    public static void main(String args[])
    {
        CardDeck deck  = new CardDeck();
        deck.print();
        deck.shuffle();
        deck.print();

    }
}
