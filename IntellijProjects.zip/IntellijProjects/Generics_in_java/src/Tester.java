public class Tester <T,S>{
    T var1;
    S var2;
    public Tester(T a, S b){
        var1=a;
        var2=b;
    }
    public  <T> void print(){
        System.out.println(var1);
        System.out.println(var2);
    }
    public static void main(String[]args){
        Tester<Integer,String> obj=new Tester<Integer,String>(22,"hi");
        obj.print();

    }
}
