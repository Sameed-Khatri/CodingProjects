public class Test {
    public <T,S> void genMethod(T t, S s){
        System.out.println(t);
        System.out.println(s);
    }

    public static void main(String[] args) {
        Test obj=new Test();
        obj.genMethod(22,"hi!!");
    }
}
