import java.util.Random;

class HashingDemo {
    public static void main(String args[]){

        HashTable H=new HashTable(100);
        Random R = new Random();
        for (int i = 0; i < 100; i++) {
            int i1 = R.nextInt(900) + 100;
            H.linearRehash(i1);
            H.QuadraticRehash(i1);
            H.insert(i1);
        }
        System.out.println(H);
        System.out.println("Is the number present : "+H.search(283));
        System.out.println("Is the number present : "+H.search(1));
        //H.search(); // find number you already insert , also check the not found case
//        System.out.println(H);
    }
}