public class HashTable {
    int[] Table;
    int tempHash;
    int numOfCollisionsLinear = 0;
    int numOfCollisionsLinear2 = 0;
    int numOfCollisionsQuadratic = 0;
    int numOfCollisionsQuadratic2 = 0;
    int numOfOccupiedCells = 0;
    int GlobalKey;
    int[]arr1;
    int[]arr2;
    HashTable(int s){
        // table size should be a prime number and 1/3 extra.
        int size=s+(s/3);
        int newSize = getPrime(size);

        Table=new int [newSize];
        arr1=new int [newSize];
        arr2=new int [newSize];// if value is 0 for integer the cell will consider empty.
    }
    private int getPrime(int n) {
        while(true) {
            if (isPrime(n)) return n;
            n++;
        }
    }
    private boolean isPrime(int n) {
        for (int i = 2; i <= n/2; i++) {
            if (n % i == 0) return false;
        }
        return true;
    }
    public int Hash(int key){
        //compute hash value by taking mod on key value and return remainder
        tempHash=key% Table.length;
        return
                tempHash;
    }
    public int Rehash(int key, int i) {
        int j=0;
            int rehashLinear = (key + i) % Table.length;
            if (Table[rehashLinear] != 0) {
                numOfCollisionsLinear2++;
                int rehashQuadratic = (key + (i*i)) % Table.length;
                if (Table[rehashQuadratic] != 0) {
                    numOfCollisionsQuadratic2++;
                    j=Rehash(key, i + 1);
                } else j= rehashQuadratic;
            }
            else
                j= rehashLinear;
            return j;
        }
        public void linearRehash(int key){
            int hash=key% Table.length;
            int i=1;
            while (arr1[hash]!=0){
                hash=(key+i)% Table.length;
                numOfCollisionsLinear++;
                i++;
            }
            arr1[hash]=key;
        }
    public void QuadraticRehash(int key){
        int hash=key% Table.length;
        int i=1;
        while (arr2[hash]!=0){
            hash=(key+(i*i))% Table.length;
            numOfCollisionsQuadratic++;
            i++;
        }
        arr2[hash]=key;
    }

    // first test linear probing, then test Quadratic probing and compare both technique on same data
    //with respect to number of collision
    public void insert(int key){
        GlobalKey=key;
        int hash=Hash(key);
        if(Table[hash]!=0){
            int rehash=Rehash(key,1);
            Table[rehash]=key;
        }
        else
            Table[hash]=key;
        // keep maintain 1/3 empty cells
        // call Hash(key) and save return hash-value
        // if (no collision on hash-value) then place in table
        //else call rehash function until empty cell found or reached to threshold limit of rehashes
        // also count number of collisions on each key insertion
    }
    public boolean search (int key) {
        int hash=Hash(key);
        boolean flag=false;
        if(Table[hash]==key)
            return true;
        for(int i=0;i< Table.length;i++){
            if(Table[i]==key){
                flag=true;
                break;
            }
            else
                flag=false;
        }
        return flag;
        // search word in a hash table
        // call Hash(key) and save return hash-value
        // if (value match at hash-value index) return true
        //else call rehash function until empty cell found or it reaches threshold limit of rehashes.
    }
    public String toString(){
        String str="";
        System.out.println("Number of collisions for linear rehash : "+numOfCollisionsLinear);
        System.out.println("Number of collisions for quadratic rehash : "+numOfCollisionsQuadratic);
        System.out.println("Number of collisions for linear and quadratic combine __linear : "+numOfCollisionsLinear2);
        System.out.println("Number of collisions for linear and quadratic combine __quadratic : "+numOfCollisionsQuadratic2);
        for (int i = 0; i < Table.length; i++) {
            str=str+"["+i+"] "+Table[i]+"\n";
        }
        return str;
    }
}