public class FeetInches {
    private int feet;
    private int inches;
    public FeetInches(){
        feet=0;
        inches=0;
    }
    public FeetInches(int f, int i){
        feet=f;
        inches=i;
        simplify();
    }
    public FeetInches(FeetInches obj){
        feet=obj.feet;
        inches= obj.inches;
    }
    public void simplify(){
        if(inches>11){
            feet=feet+(inches/12);
            inches=inches%12;
        }
    }
    public void setFeet(int f){
        feet=f;
    }
    public void setInches(int i){
        inches=i;
        simplify();
    }
    public int getFeet(){
        return feet;
    }
    public int getInches(){
        return inches;
    }
    public String toString(){
        String s=feet+" feet "+inches+" inches";
        return s;
    }
    public FeetInches add(FeetInches obj){
        int totalFeet;
        int totalInches;
        totalFeet=feet+ obj.feet;
        totalInches=inches+ obj.inches;
        return new FeetInches(totalFeet,totalInches);
    }
    public boolean equals(FeetInches obj){
        if(feet==obj.feet&&inches==obj.inches)
            return true;
        return false;
    }
    public FeetInches copy(){
        FeetInches obj2=new FeetInches();
        obj2.feet=feet;
        obj2.inches=inches;
        obj2=add(obj2);
        return obj2;
    }
    public static void main(String[]args){
        FeetInches obj=new FeetInches();
        obj.setFeet(3);
        obj.setInches(11);
        System.out.println(obj.getFeet()+" feet "+obj.getInches()+" inches");
        System.out.println (obj.equals(obj));
        System.out.println(obj.copy());
    }
}
