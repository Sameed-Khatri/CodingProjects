import java.util.Scanner;

public class driver {
    public static void main(String[] args) {
        System.out.println("Enter number of words between 0 and 21 exclusive");
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        if(n<=0 || n>=21){
            System.out.println("Number of words are not in the limit, re run the code ");
        }
        String[]words=new String[n];
        String s;
        System.out.println("Enter "+n+" space-separated lower case english words ");
        sc.nextLine();
        s=sc.nextLine();
        words=s.split(" ");
        for(int i=0;i< words.length;i++){
            String temp=words[i];
            if(temp.length()>15){
                System.out.println("Number of letters are not in the limit, re run the code with correct input");
                sc.close();
            }
            else{
                for(int j=0;j<temp.length();j++){
                    char c=temp.charAt(i);
                    if(! Character.isLowerCase(c)){
                        System.out.println("Letter is not in lower case format, re run the code with correct input");
                        sc.close();
                    }
                }
            }
        }
//        int score=score_words(words);
        System.out.println("Word score is :");
//        System.out.println(score);
    }
}
