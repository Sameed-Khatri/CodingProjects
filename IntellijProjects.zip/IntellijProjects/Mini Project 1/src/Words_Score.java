import java.util.Scanner;
public class Words_Score {
    public static boolean is_vowel(char letter) {
        if(letter=='a' || letter=='e'||letter=='i'||letter=='o'||letter=='u'||letter=='y') {
            return true;
        }
        else
            return false;
    }
    public static int score_word(String word) {
        int m=0;
        int score;
        for(int i=0;i<word.length();i++) {
            char c=word.charAt(i);
            if(is_vowel(c)) {
                m++;
            }
        }
        if(m>=3)
            score=2;
        else if(m>=1 && m<3)
            score=1;
        else
            score=0;
        return score;
    }
    public static int score_words(String[]list_of_words) {
        int score_list=0;
        for(int i=0;i<list_of_words.length;i++) {
            String s= list_of_words[i];
            int temp=score_word(s);
            score_list=score_list+temp;
        }
        return score_list;
    }
    public static void main(String[] args) {
        System.out.println("Enter number of words between 0 and 21 exclusive");
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        if(n<=0 || n>=21){
            System.out.println("Number of words are not in the limit, re run the code ");
        }
        String[]words;
        String s;
        System.out.println("Enter "+n+" space-separated lower case english words ");
        sc.nextLine();
        s=sc.nextLine();
        words=s.split(" ");
        for(int i=0;i< words.length;i++){
            String temp=words[i];
            if(temp.length()>15){
                System.out.println("Number of letters are not in the limit, re run the code with correct input");
            }
            else{
                for(int j=0;j<temp.length();j++){
                    char c=temp.charAt(i);
                    if(! Character.isLowerCase(c)){
                        System.out.println("Letter is not in lower case format, re run the code with correct input");
                    }
                }
            }
        }
        int score=score_words(words);
        System.out.println("Word score is :");
        System.out.println(score);
        sc.close();
    }
}
