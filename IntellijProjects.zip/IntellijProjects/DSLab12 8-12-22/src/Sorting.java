public class Sorting {
    int QuickSortComparisons;
    int MergeSortComparisons;
    int QuickSortSwapping;
    int MergeSortSwapping;
    public void QuickSort(int[]arr, int L, int U) {
        int m = Partition(arr, L, U);
        if (m - 1 > L) {
            QuickSort(arr, L, m - 1);
        }
        if (m + 1 < U) {
            QuickSort(arr, m + 1, U);
        }
    }
    public int Partition(int[]arr,int l, int u){
        int pivot=arr[l];
        int startPoint= l;
        while(l <u){
            while(arr[l]<=pivot && l< arr.length-1){
                if(l<arr.length)
                    l++;
                QuickSortComparisons++;
            }
            while(arr[u]>pivot){
                u--;
                QuickSortComparisons++;
            }
            if(l <u){
                swap(arr,l,u);
                QuickSortSwapping++;
            }
        }
        swap(arr,startPoint,u);
        QuickSortSwapping++;
        return u;
    }
    public void swap(int[]arr,int index1, int index2){
        int temp=arr[index1];
        arr[index1]=arr[index2];
        arr[index2]=temp;
    }
    public void Mergesort(int[] a, int left, int right) {
        if( left < right){
            int mid = (left + right)/2;
            Mergesort(a,left,mid);
            Mergesort(a,mid+1,right);
            Merge(a,left,mid,right);
        }
    }
    public void Merge(int[] arr, int l, int m, int r){
        int n1 = m - l + 1;
        int n2 = r - m;

        int L[] = new int[n1];
        int R[] = new int[n2];

        for (int i = 0; i < n1; i++)
            L[i] = arr[l + i];
        for (int j = 0; j < n2; j++)
            R[j] = arr[m + 1 + j];

        int i = 0;
        int j = 0;

        int k = l;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                arr[k] = L[i];
                i++;
                MergeSortComparisons++;
            }
            else {
                arr[k] = R[j];
                j++;
                MergeSortComparisons++;
            }
            k++;
        }

        while (i < n1) {
            arr[k] = L[i];
            i++;
            k++;
            MergeSortSwapping++;
        }

        while (j < n2) {
            arr[k] = R[j];
            j++;
            k++;
            MergeSortSwapping++;
        }
    }
}
