public class Driver {
    public static void main(String[]args) {

        int[]arr1=new int[100];
        int[]arr2=new int[100];
        for(int i=0;i<100;i++){
            int j=(int)(Math.random()*100)+1;
            arr1[i]=j;
            arr2[i]=j;
        }
        System.out.println("Quick Sort : ");
        Sorting q=new Sorting();
        q.QuickSort(arr1,0,arr1.length-1);

        for(int i=0;i<100;i++){
            System.out.print(arr1[i]+" ");
        }
        System.out.println();
        System.out.println("Number of comparisons in Quick sort : "+q.QuickSortComparisons);
        System.out.println("Number of swapping in Quick sort : "+q.QuickSortSwapping);
        System.out.println();
        System.out.println("Merge Sort : ");
        q.Mergesort(arr2,0, arr2.length-1);
        for(int i=0;i<100;i++){
            System.out.print(arr2[i]+" ");
        }
        System.out.println();
        System.out.println("Number of comparisons in Merge sort : "+q.MergeSortComparisons);
        System.out.println("Number of swapping in Merge sort : "+q.MergeSortSwapping);
    }
}
