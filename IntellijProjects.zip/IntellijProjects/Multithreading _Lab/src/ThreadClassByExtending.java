public class ThreadClassByExtending {
    public static void main(String[] args) {
        T1 obj1=new T1();
        obj1.start();
        System.out.println();
        T2 obj2=new T2();
        obj2.start();
        System.out.println();
        T3 obj3=new T3();
        obj3.start();
        System.out.println();


    }
}
class T1 extends Thread{

    @Override
    public void run() {
        System.out.println("Start Time --> "+System.currentTimeMillis());
        try{
            for(int i=1;i<=100;i++){
                System.out.println(i+" "+"Thread name --> "+Thread.currentThread().getName());
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        finally {
            System.out.println("End Time --> "+System.currentTimeMillis());
            System.out.println();
        }
    }
}
class T2 extends Thread{

    @Override
    public void run() {
        System.out.println("Start Time --> "+System.currentTimeMillis());
        try{
            for(int i=101;i<=200;i++){
                System.out.println(i+" "+"Thread name --> "+Thread.currentThread().getName());
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        finally {
            System.out.println("End Time --> "+System.currentTimeMillis());
            System.out.println();
        }
    }
}
class T3 extends Thread{


    @Override
    public void run() {
        System.out.println("Start Time --> "+System.currentTimeMillis());
        try{
            for(int i=201;i<=300;i++){
                System.out.println(i+" "+"Thread name --> "+Thread.currentThread().getName());
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        finally {
            System.out.println("End Time --> "+System.currentTimeMillis());
            System.out.println();
        }
    }
}
