public class ThreadClass {
    public static void main(String[] args) {
        C1 obj1=new C1();
        Thread t =new Thread(obj1);
        t.start();
        System.out.println();
        C2 obj2=new C2();
        Thread f =new Thread(obj2);
        f.start();
        System.out.println();
        C3 obj3=new C3();
        Thread l =new Thread(obj3);
        l.start();
        System.out.println();


    }
}
class C1 implements Runnable{

    @Override
    public void run() {
        System.out.println("Start Time --> "+System.currentTimeMillis());
        try{
            for(int i=1;i<=100;i++){
                System.out.println(i+" "+"Thread name --> "+Thread.currentThread().getName());
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        finally {
            System.out.println("End Time --> "+System.currentTimeMillis());
            System.out.println();
        }
    }
}
class C2 implements Runnable{

    @Override
    public void run() {
        System.out.println("Start Time --> "+System.currentTimeMillis());
        try{
            for(int i=101;i<=200;i++){
                System.out.println(i+" "+"Thread name --> "+Thread.currentThread().getName());
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        finally {
            System.out.println("End Time --> "+System.currentTimeMillis());
            System.out.println();
        }
    }
}
class C3 implements Runnable{


    @Override
    public void run() {
        System.out.println("Start Time --> "+System.currentTimeMillis());
        try{
            for(int i=201;i<=300;i++){
                System.out.println(i+" "+"Thread name --> "+Thread.currentThread().getName());
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        finally {
            System.out.println("End Time --> "+System.currentTimeMillis());
            System.out.println();
        }
    }
}
