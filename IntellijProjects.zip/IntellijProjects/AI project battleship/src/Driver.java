import java.util.ArrayList;
import java.util.Scanner;

public class Driver {
    public static void main(String[] args) {
        BattleShip obj=new BattleShip();
        obj.fillSea();
        obj.printHumanBoard();
        System.out.println();
        String replay="yes";
        char[][]goalState=new char[5][5];
        char[][]compBoard=new char[5][5];
        int computer_hit_count=0;
        int player_hit_count=0;
        String tell="miss";
        Scanner sc = new Scanner(System.in);
        System.out.println("Type play and press enter");
        while(sc.hasNext()){
            String trash=sc.next();
            while(replay.equals("yes")){
                obj.fillSea();
                for(int i=0;i<3;i++){
                    System.out.println("enter the co-ordinates (row column) and vertical or horizontal manner to place your ship");
                    System.out.println("the numbers should be between 0 and 4 inclusive");
                    System.out.println("enter row,column,placement manner(vertical or horizontal) each in separate line");
                    int row=sc.nextInt();
                    int col=sc.nextInt();
                    String manner=sc.next();
                    String s=obj.placeShipsHuman(row,col,manner);
                    if(s.equals("Invalid position")){
                        System.out.println("invalid co-ordinates");
                        sc.close();
                        break;
                    }
                    obj.printHumanBoard();
                }
                ArrayList<geneticNode> geneticShipPositions=new ArrayList<>();
                    String[]ships=new String[3];
                    for(int i=0;i<3;i++){
                        ships[i]=obj.generateShipsComputer();
                    }
                    geneticNode n=new geneticNode(ships,0);
                    geneticShipPositions.add(n);
                System.out.println();
                System.out.println("Printing computer ships for testing purpose");
                obj.printCompBoard();
                System.out.println("Printing computer ships co-ordinates for testing purpose");
                n.printShipLocations();
                goalState=obj.goalStateGenerate();
                compBoard= obj.compBoard;
                while(computer_hit_count<=5 && player_hit_count<=5){
                    System.out.println("Make your move");
                    int row= sc.nextInt();
                    int col= sc.nextInt();
                    String check=obj.check_hit_miss(row,col);
                    if(check.equals("hit")){
                        System.out.println("That's a Hit !");
                        obj.print_user_moves_board(row,col,"hit");
                        player_hit_count=player_hit_count+1;
                    }
                    if(check.equals("miss")){
                        System.out.println("You missed");
                        obj.print_user_moves_board(row,col,"miss");
                    }
                    System.out.println(player_hit_count);
                    if(player_hit_count==6){
                        System.out.println(" Victory !!");
                        break;
                    }
                    System.out.println("Computer's turn");
                    if(tell.equals("miss")){
                        String comp_attack=obj.computer_move_miss();
                        System.out.println("tell if the computer coordinates ("+comp_attack+") are hit or miss on your board");
                        System.out.println("Here is your board :");
                        obj.printHumanBoard();
                    }
                    else if(tell.equals("hit")){
                        String comp_attack=obj.computer_move_hit();
                        System.out.println("tell if the computer coordinates ("+comp_attack+") are hit or miss on your board");
                        computer_hit_count=computer_hit_count+1;
                        System.out.println("Here is your board :");
                        obj.printHumanBoard();
                    }
                    tell=sc.next();
                }
                System.out.println();
                System.out.println("If you want to replay then type yes otherwise type no");
                replay=sc.next();
                if(replay.equals("yes")){
                    obj.resetAll();
                    tell="miss";
                    computer_hit_count=0;
                    player_hit_count=0;
                }
                else
                    break;
            }
        }
        sc.close();
    }
}
