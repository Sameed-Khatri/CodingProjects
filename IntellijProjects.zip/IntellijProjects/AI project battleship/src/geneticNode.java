public class geneticNode {
    String[]totalShips;
    int miss;
    public geneticNode(String[]s,int m){
        totalShips=s;
        miss=m;
    }
    public void printShipLocations(){
        for(int i=0;i< totalShips.length;i++){
            System.out.println(totalShips[i]);
        }
    }
}
