import java.nio.charset.Charset;
import java.text.DecimalFormat;
import java.util.*;

public class BattleShip {
    char ship='S';
    char sea='~';
    char hit='*';
    char miss='X';
    char[][]compBoard=new char[5][5];
    char[][]humanBoard=new char[5][5];
    char[][]copyBoard=new char[5][5];
    char[][]user_moves_board=new char[5][5];
    double[][]probabilityBoard=new double[5][5];
    int hit_row;
    int hit_col;
    Set<String> generatedIndices = new HashSet<String>();
    public void fillSea(){
        for(int i=0;i<5;i++){
            for(int j=0;j<5;j++){
                compBoard[i][j]=sea;
                humanBoard[i][j]=sea;
                copyBoard[i][j]=sea;
                user_moves_board[i][j]=sea;
            }
        }
        int total_cells=probabilityBoard.length*probabilityBoard[0].length;
        double initial_probability=1/(double)total_cells;
        set_probability(initial_probability);
    }
    public void printCompBoard(){
        for(int i=0;i<5;i++){
            for(int j=0;j<5;j++){
                System.out.print(compBoard[i][j]+" ");
            }
            System.out.println();
        }
        System.out.println("---------------------------------");
    }
    public void printHumanBoard(){
        for(int i=0;i<5;i++){
            for(int j=0;j<5;j++){
                System.out.print(humanBoard[i][j]+" ");
            }
            System.out.println();
        }
    }
    public String placeShipsHuman(int row, int col, String manner){
        humanBoard[row][col]=ship;
        String s="";
        if(manner.equals("vertical")){
            if(row+1 > 4 && humanBoard[row-1][col]!='S'){
                humanBoard[row-1][col]=ship;
            }
            else if(row-1 < 0 && humanBoard[row+1][col]!='S'){
                humanBoard[row+1][col]=ship;
            }
            else{
                int random= (int) (Math.random() * 3);
                if(random>1 && humanBoard[row-1][col]!='S'){
                    humanBoard[row-1][col]=ship;
                }
                else if( humanBoard[row+1][col]!='S'){
                    humanBoard[row+1][col]=ship;
                }
                else
                    s="Invalid Position";
            }
        }
        if(manner.equals("horizontal")){
            if(col+1 > 4 && humanBoard[row][col-1]!='S'){
                humanBoard[row][col-1]=ship;
            }
            else if(col-1 < 0 && humanBoard[row][col+1]!='S'){
                humanBoard[row][col+1]=ship;
            }
            else{
                int random= (int) (Math.random() * 3);
                if(random>1 && humanBoard[row][col-1]!='S'){
                    humanBoard[row][col-1]=ship;
                }
                else if(humanBoard[row][col+1]!='S'){
                    humanBoard[row][col+1]=ship;
                }
                else
                    s="Invalid Position";
            }
        }
        return s;
    }
    public char[][] goalStateGenerate(){
        char[][]goalState=new char[5][5];
        for(int i=0;i<5;i++){
            for(int j=0;j<5;j++){
                if(humanBoard[i][j]=='S')
                    goalState[i][j]=hit;
                else
                    goalState[i][j]=humanBoard[i][j];
            }
        }
        return goalState;
    }
    public String generateShipsComputer(){
        Random rand=new Random();
        int row;
        int col;
        int up=-1;
        int down=-1;
        int left=-1;
        int right=-1;
        String s;
        String manner;
        int temp=(int)(Math.random()*2);
        if(temp<1){
            manner="vertical";
        }
        else{
            manner="horizontal";
        }
        do{
            row= rand.nextInt(compBoard.length);
            col= rand.nextInt(compBoard[0].length);
//            if(row==0){
//                down=row+1;
//            }
//            if(row==4){
//                up=row-1;
//            }
//            if(row!=0 && row!=4){
//                down=row+1;
//                up=row-1;
//            }
//            if(col==0){
//                right=col+1;
//            }
//            if(col==4){
//                left=col-1;
//            }
//            if(col!=0 && col!=4){
//                right=col+1;
//                left=col-1;
//            }
//            s=row+","+col+","+up+","+down+","+left+","+right;
            s=row+","+col;
        }while(generatedIndices.contains(s));
        generatedIndices.add(s);
        String s1 = placeShipsComputer(row,col,manner);
        if(s1.equals("Invalid Position")){
            return s1;
        }
        String position=s+"|"+s1;
        return position;
    }
    public String placeShipsComputer(int row, int col, String manner){
        compBoard[row][col]=ship;
        int r=-1;
        int c=-1;
        String s="";
        if(manner.equals("vertical")){
            if(row+1 > 4 && compBoard[row-1][col]!='S'){
                compBoard[row-1][col]=ship;
                r=row-1;
                c=col;
            }
            else if(row-1 < 0 && compBoard[row+1][col]!='S'){
                compBoard[row+1][col]=ship;
                r=row+1;
                c=col;
            }
            else{
                int random= (int) (Math.random() * 3);
                if(random>1 && compBoard[row-1][col]!='S'){
                    compBoard[row-1][col]=ship;
                    r=row-1;
                    c=col;
                }
                else if( compBoard[row+1][col]!='S'){
                    compBoard[row+1][col]=ship;
                    r=row+1;
                    c=col;
                }
                else
                    s="Invalid Position";
            }
        }
        if(manner.equals("horizontal")){
            if(col+1 > 4 && compBoard[row][col-1]!='S'){
                compBoard[row][col-1]=ship;
                r=row;
                c=col-1;
            }
            else if(col-1 < 0 && compBoard[row][col+1]!='S'){
                compBoard[row][col+1]=ship;
                r=row;
                c=col+1;
            }
            else{
                int random= (int) (Math.random() * 3);
                if(random>1 && compBoard[row][col-1]!='S'){
                    compBoard[row][col-1]=ship;
                    r=row;
                    c=col-1;
                }
                else if(compBoard[row][col+1]!='S'){
                    compBoard[row][col+1]=ship;
                    r=row;
                    c=col+1;
                }
                else
                    s="Invalid Position";
            }
        }
        if(s.equals("Invalid Position")){
            return s;
        }
        String combine=r+","+c;
        generatedIndices.add(combine);
        return combine;
    }
    public void set_probability(double probability){
        for(int i=0;i<5;i++){
            for(int j=0;j<5;j++){
                probabilityBoard[i][j]=probability;
            }
        }
    }
    public String reset_probability(int row, int col){
        double old_probability=1/(double)(probabilityBoard.length*probabilityBoard[0].length);
        int surround_cells=0;
        String cell_location="";
        //for corners
        if((row-1<0 && col-1<0) || (row-1<0 && col+1>4) || (row+1>4 && col-1<0) || (row+1>4 && col+1>4)){
            surround_cells=2;
            cell_location="corner";
        }
        //check borders
        else if((row-1<0) || (row+1>4) || (col-1<0) || (col+1>4)){
            surround_cells=3;
            cell_location="border";
        }
        else{
            surround_cells=4;
            cell_location="middle";
        }
        double probability_surround_cell=(old_probability*surround_cells)+old_probability;
        double temp=1-probability_surround_cell;
        double remaining_cells=25-surround_cells-1;
        double new_probability=temp/remaining_cells;
        DecimalFormat df = new DecimalFormat("#.###");
        new_probability=Double.parseDouble(df.format(new_probability));
        set_probability(new_probability);
        probabilityBoard[row][col]=0.0;
        if(cell_location.equals("corner")){
            if(row-1<0 && col-1<0){
                probabilityBoard[row][col+1]=probability_surround_cell;
                probabilityBoard[row+1][col]=probability_surround_cell;
                cell_location="top left";
            }
            if(row-1<0 && col+1>4){
                probabilityBoard[row][col-1]=probability_surround_cell;
                probabilityBoard[row+1][col]=probability_surround_cell;
                cell_location="top right";
            }
            if(row+1>4 && col-1<0){
                probabilityBoard[row][col+1]=probability_surround_cell;
                probabilityBoard[row-1][col]=probability_surround_cell;
                cell_location="bottom left";
            }
            if(row+1>4 && col+1>4){
                probabilityBoard[row][col-1]=probability_surround_cell;
                probabilityBoard[row-1][col]=probability_surround_cell;
                cell_location="bottom right";
            }
        }
        else if(cell_location.equals("border")){
            if(row-1<0){
                probabilityBoard[row][col+1]=probability_surround_cell;
                probabilityBoard[row][col-1]=probability_surround_cell;
                probabilityBoard[row+1][col]=probability_surround_cell;
                cell_location="top";
            }
            if(row+1>4){
                probabilityBoard[row][col+1]=probability_surround_cell;
                probabilityBoard[row][col-1]=probability_surround_cell;
                probabilityBoard[row-1][col]=probability_surround_cell;
                cell_location="bottom";
            }
            if(col-1<0){
                probabilityBoard[row+1][col]=probability_surround_cell;
                probabilityBoard[row-1][col]=probability_surround_cell;
                probabilityBoard[row][col+1]=probability_surround_cell;
                cell_location="left";
            }
            if(col+1>4){
                probabilityBoard[row+1][col]=probability_surround_cell;
                probabilityBoard[row-1][col]=probability_surround_cell;
                probabilityBoard[row][col-1]=probability_surround_cell;
                cell_location="right";
            }
        }
        else{
            probabilityBoard[row+1][col]=probability_surround_cell;
            probabilityBoard[row-1][col]=probability_surround_cell;
            probabilityBoard[row][col+1]=probability_surround_cell;
            probabilityBoard[row][col-1]=probability_surround_cell;
            cell_location="middle";
        }
        return cell_location;
    }
    public String computer_move_miss(){
        Random rand=new Random();
        int row;
        int col;
        do{
        row= rand.nextInt(compBoard.length);
        col= rand.nextInt(compBoard[0].length);
        hit_row=row;
        hit_col=col;
        }while (copyBoard[row][col]==miss);
        copyBoard[row][col]=miss;
        return row+","+col;
    }
    public String check_hit_miss(int r, int c){
        if(compBoard[r][c]==ship)
            return "hit";
        else
            return "miss";
    }
    public String computer_move_hit(){
        String cell_location=reset_probability(hit_row,hit_col);
        copyBoard[hit_row][hit_col]=hit;
        do{
        if(cell_location.equals("top left")){
            double r=Math.random();
            if(r<0.5)
                hit_row=hit_row+1;
            else
                hit_col=hit_col+1;
        }
        else if(cell_location.equals("top right")){
            double r=Math.random();
            if(r<0.5)
                hit_row=hit_row+1;
            else
                hit_col=hit_col-1;
        }
        else if(cell_location.equals("bottom right")){
            double r=Math.random();
            if(r<0.5)
                hit_row=hit_row-1;
            else
                hit_col=hit_col-1;
        }
        else if(cell_location.equals("bottom left")){
            double r=Math.random();
            if(r<0.5)
                hit_row=hit_row-1;
            else
                hit_col=hit_col+1;
        }
        else if(cell_location.equals("top")){
            double r=Math.random()*3;
            if(r<1)
                hit_row=hit_row+1;
            else if(r>1 && r<2)
                hit_col=hit_col-1;
            else
                hit_col=hit_col+1;
        }
        else if(cell_location.equals("bottom")){
            double r=Math.random()*3;
            if(r<1)
                hit_row=hit_row-1;
            else if(r>1 && r<2)
                hit_col=hit_col-1;
            else
                hit_col=hit_col+1;
        }
        else if(cell_location.equals("left")){
            double r=Math.random()*3;
            if(r<1)
                hit_row=hit_row+1;
            else if(r>1 && r<2)
                hit_row=hit_row-1;
            else
                hit_col=hit_col+1;
        }
        else if(cell_location.equals("right")){
            double r=Math.random()*3;
            if(r<1)
                hit_row=hit_row+1;
            else if(r>1 && r<2)
                hit_row=hit_row-1;
            else
                hit_col=hit_col-1;
        }
        else if(cell_location.equals("middle")){
            double r=Math.random()*4;
            if(r<1)
                hit_row=hit_row+1;
            else if(r>1 && r<2)
                hit_row=hit_row-1;
            else if(r>2 && r<3)
                hit_col=hit_col+1;
            else
                hit_col=hit_col-1;
        }
        }while (copyBoard[hit_row][hit_col]==hit);
        return hit_row+","+hit_col;
    }
    public void print_user_moves_board(int row,int col,String type){
        if(type.equals("miss"))
            user_moves_board[row][col]=miss;
        else if(type.equals("hit"))
            user_moves_board[row][col]=hit;
        for(int i=0;i<5;i++){
            for(int j=0;j<5;j++){
                System.out.print(user_moves_board[i][j]+" ");
            }
            System.out.println();
        }
    }
    public void resetAll(){
        for(int i=0;i<5;i++){
            for(int j=0;j<5;j++){
                compBoard[i][j]=' ';
                humanBoard[i][j]=' ';
                copyBoard[i][j]=' ';
                user_moves_board[i][j]=' ';
            }
        }
        double old_probability=1/(double)(probabilityBoard.length*probabilityBoard[0].length);
        DecimalFormat df = new DecimalFormat("#.###");
        old_probability=Double.parseDouble(df.format(old_probability));
        for(int i=0;i<5;i++){
            for(int j=0;j<5;j++){
                probabilityBoard[i][j]=old_probability;
            }
        }

    }
}
