import java.text.DecimalFormat;

public class test {
    public static void main(String[] args) {
        double[][]a=new double[5][5];
        System.out.println(a[0].length);
        int asize=a.length*a[0].length;
        System.out.println(asize);
        double p=1/(double)asize;
        System.out.print(p);
        for(int i=0;i<5;i++){
            for(int j=0;j<5;j++){
                a[i][j]=p;
            }
        }
        for(int i=0;i<5;i++){
            for(int j=0;j<5;j++){
                System.out.print(a[i][j]+" ");
            }
            System.out.println();
        }
        double t=(1-0.2)/21;
        DecimalFormat df = new DecimalFormat("#.###");
        t = Double.parseDouble(df.format(t));
        System.out.print(t);
    }
}
