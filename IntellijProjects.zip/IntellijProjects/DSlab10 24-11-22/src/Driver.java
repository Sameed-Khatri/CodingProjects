import java.util.ArrayList;
import java.util.LinkedList;

public class Driver {
    public static void main(String[] args) {
        Graph obj = new Graph(5);
        obj.AddVertex("A",22);
        obj.AddVertex("B",24);
        obj.AddVertex("C",30);
        obj.AddVertex("D",27);
        obj.AddVertex("E",29);
        obj.AddEdge("A","B");
        obj.AddEdge("A","C");
        obj.AddEdge("B","D");
        obj.DFS();
        System.out.println();
        System.out.println("Finding a vertex which is at :"+obj.FindVertex("C"));
        System.out.println();
        System.out.println("vertices that represent a path from source to destination :");
        ArrayList<vertex>v =obj.FindPath("A","D");
        for(int i=0;i<v.size();i++){
            System.out.println(v.get(i).name+","+v.get(i).age);
        }
        System.out.println();
        obj.deleteVertex("C");
        System.out.println("Friends of all after removing C :");
        System.out.println(obj);
        System.out.println();
        System.out.println("Removing relation between A and B");
        obj.deleteEdge("A","B");
        System.out.println(obj);
        System.out.println();
        System.out.println("Components of graph :");
        obj.component();
    }
}
