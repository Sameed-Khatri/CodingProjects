import java.util.ArrayList;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Stack;

public class Graph {
    ArrayList<vertex> adjList;
    int count;
    ArrayList<vertex>av=new ArrayList<>();
//    LinkedList<vertex>componentList
    Graph(int s){
        adjList=new ArrayList<>();
        count=0;
    }
    public void AddVertex(String n, int a){
        vertex v=new vertex(n,a);
//        adjList[count]=v;
        adjList.add(count,v);
        count++;
    }
    public void AddEdge(String n1,String n2) {
        int i=getIndex(n1);
        int j=getIndex(n2);
//        adjList[i].friendList.add(adjList[j]);
        adjList.get(i).friendList.add(adjList.get(j));
        adjList.get(j).friendList.add(adjList.get(i));
    }
    public int getIndex(String s){
        for(int i=0;i<count;i++){
            if(adjList.get(i).name.equals(s))
                return i;
        }
        return -1;
    }
    public void DFS() {
        Stack<vertex>s=new Stack<>();
        int[]visit=new int[adjList.size()];
//        for(int i=0;i< adjList.length;i++){
            s.push(adjList.get(0));
            visit[0]=1;
            System.out.println(adjList.get(0).name+" "+adjList.get(0).age);
            while(!s.isEmpty()){
                int c=0;
                LinkedList<vertex>l=s.peek().friendList;
                for(int j=0;j<l.size();j++){
                    vertex v= l.get(j);
                    int check=getIndex(v.name);
                    if(visit[check]==0){
                        visit[check]=1;
                        s.push(adjList.get(check));
                        System.out.println(adjList.get(check).name+" "+adjList.get(check).age);
                    }
                    else{
                        c++;
                        if(c==l.size())
                            s.pop();
                    }
                }
            }

//        }
        System.out.println("Printing visit array :");
        for(int i=0;i< visit.length;i++){
            System.out.println(visit[i]);
        }
    }
    public void deleteVertex(String n){
        vertex v1=FindVertex(n);
        int index=getIndex(n);
//        vertex v2=FindVertex(n2);
        LinkedList<vertex>l=v1.friendList;
        for(int i=0;i<l.size();i++){
            vertex v2=l.get(i);
            vertex v3=FindVertex(v2.name);
            LinkedList<vertex>l2=v3.friendList;
//            vertex temp=l2.get(0);
            ListIterator<vertex>list_iterate=l2.listIterator();
            while (list_iterate.hasNext()){
//                vertex v4=list_iterate.next();
                if(list_iterate.next().name.compareTo(n)==0){
                    list_iterate.remove();
                    break;
                }
            }
        }
//        adjList[index]=null;
        adjList.remove(index);
    }
    public void deleteEdge(String n1,String n2){
        int i=getIndex(n1);
        int j=getIndex(n2);
        adjList.get(i).friendList.remove(adjList.get(j));
        adjList.get(j).friendList.remove(adjList.get(i));
    }
    public vertex FindVertex(String n){
        int i=getIndex(n);
        return adjList.get(i);
    }
    public ArrayList<vertex> FindPath(String source, String destination){
        if(source==null){}
        else{
        vertex start=FindVertex(source);
        vertex end=FindVertex(destination);
        LinkedList<vertex>l1=start.friendList;
        if(l1.contains(end)){
            av.add(start);
            av.add(end);
        }
        else{
            for(int i=0;i<l1.size();i++){
                if(av.contains(end))
                    break;
                FindPath(l1.get(i).name,destination);
            }
        }
        }
        return av;
    }
    public void DFSUtil(int v, boolean[] visited){
        visited[v]=true;
        System.out.println(adjList.get(v).name+" ");
        for(int i=0;i< getIndex(adjList.get(v).name);i++){
            if(!visited[i])
                DFSUtil(i,visited);
        }
    }
    public void component() {
        boolean[]visited=new boolean[adjList.size()];
        for(int i=0;i< adjList.size();i++){
            if(!visited[i]){
                DFSUtil(i,visited);
                System.out.println();
            }
        }
    }
    public String toString(){
        String s1="";
        String s3="";
        for(int i=0;i<adjList.size();i++){
            String s2="";
            LinkedList<vertex>l=adjList.get(i).friendList;
            for(int j=0;j<l.size();j++){
                s2=s2+" ("+l.get(j).name+","+l.get(j).age+")";
            }
            s1=s1+"Person :"+adjList.get(i).name+","+adjList.get(i).age+"\n"+"Friends :"+s2+"\n";
        }
        return s1;
    }
}
