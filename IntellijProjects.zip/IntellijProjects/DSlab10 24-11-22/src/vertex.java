import java.util.LinkedList;

class vertex{
    String name;
    int age;
    LinkedList<vertex>friendList=new LinkedList<>();
    vertex(String d, int a){
        name=d;
        age=a;
    }
}