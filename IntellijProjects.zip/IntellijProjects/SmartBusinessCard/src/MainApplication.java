import spark.Spark;

public class MainApplication {
    public static void main(String[] args) {
        Spark.port(4567); // Set the port number

        // Initialize the User class and register routes
        User user = new User();
        user.registerSignupRoute();
    }
}
