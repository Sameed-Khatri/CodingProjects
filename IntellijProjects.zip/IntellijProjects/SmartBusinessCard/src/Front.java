import java.sql.*;

public class Front {
    private static final String DB_URL = "jdbc:sqlite:smartcard.db"; // Replace with your database path

    public static Connection connect() {
        Connection connection = null;
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(DB_URL);
            System.out.println("Connected to the database");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }

    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Database connection closed");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static void createTable() {
        String createTableUsers = "CREATE TABLE IF NOT EXISTS users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "first_name TEXT NOT NULL," +
                "last_name TEXT NOT NULL," +
                "country TEXT NOT NULL," +
                "city TEXT NOT NULL," +
                "phone_number TEXT NOT NULL," +
                "email TEXT NOT NULL," +
                "password TEXT NOT NULL" +
                ")";

        try (Connection connection = connect();
             Statement statement = connection.createStatement()) {
            statement.execute(createTableUsers);
            System.out.println("Table 'users' created successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println("table created");
    }
    public static void deleteTable() {
        String deleteTableUsers = "DROP TABLE IF EXISTS users";

        try (Connection connection = connect();
             Statement statement = connection.createStatement()) {
            statement.execute(deleteTableUsers);
            System.out.println("Table 'users' deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void insertUser(String firstName, String lastName, String country, String city, String phoneNumber,
                           String email, String password) {
        String insertQuery = "INSERT INTO users (first_name, last_name, country, city, phone_number, email, password) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = connect();
             PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {

            preparedStatement.setString(1, firstName);
            preparedStatement.setString(2, lastName);
            preparedStatement.setString(3, country);
            preparedStatement.setString(4, city);
            preparedStatement.setString(5, phoneNumber);
            preparedStatement.setString(6, email);
            preparedStatement.setString(8, password);

            preparedStatement.executeUpdate();

            System.out.println("User inserted into the database.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void printUsers() {
        String selectUsers = "SELECT * FROM users";

        try (Connection connection = connect();
             PreparedStatement preparedStatement = connection.prepareStatement(selectUsers);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String firstName = resultSet.getString("first_name");
                String lastName = resultSet.getString("last_name");
                String country = resultSet.getString("country");
                String city = resultSet.getString("city");
                String phoneNumber = resultSet.getString("phone_number");
                String email = resultSet.getString("email");
                String password = resultSet.getString("password");

                System.out.println("User ID: " + id);
                System.out.println("First Name: " + firstName);
                System.out.println("Last Name: " + lastName);
                System.out.println("Country: " + country);
                System.out.println("City: " + city);
                System.out.println("Phone Number: " + phoneNumber);
                System.out.println("Email: " + email);
                System.out.println("Password: " + password);
                System.out.println();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        Connection connection = connect();
//        createTable();
        printUsers();
        closeConnection(connection);
    }
}
