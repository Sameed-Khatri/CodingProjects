import spark.Route;
import spark.Spark;

public class User {
    private String firstName;
    private String lastName;
    private String country;
    private String city;
    private String phoneNumber;
    private String email;
    private String password;
    Front add_user=new Front();
//    public User(String firstName, String lastName, String country, String city, String phoneNumber, String email, String password) {
//        this.firstName = firstName;
//        this.lastName = lastName;
//        this.country = country;
//        this.city = city;
//        this.phoneNumber = phoneNumber;
//        this.email = email;
//        this.password = password;
//    }
    public void registerSignupRoute() {
        Spark.post("/signup", signupRoute);
    }

    // This is the route handler for signup requests
    private Route signupRoute = (req, res) -> {
        // Parse data from request body
        String fN = req.queryParams("firstname");
        String lN = req.queryParams("lastname");
        String cntry = req.queryParams("country");
        String cty = req.queryParams("city");
        String pN = req.queryParams("phone");
        String eml = req.queryParams("email");
        String pswrd = req.queryParams("password");

        this.firstName=fN;
        this.lastName=lN;
        this.country=cntry;
        this.city=cty;
        this.phoneNumber=pN;
        this.email=eml;
        this.password=pswrd;
        add_user.insertUser(firstName, lastName, country, city, phoneNumber, email, password);
        // Return a response (e.g., success message)
        return "User signed up successfully!";
    };
}
