import java.util.Scanner;

public class Game {
    public boolean check_win_row(String player_mark, String[][] box){
        int count=0;
        for(int i=0;i<7;i++){    //rows
            for(int j=0;j<7;j++){    //columns
                if(box[i][j].equals(player_mark)){
                    count++;
                    if(count==4)
                        return true;
                }
                else
                    count=0;
            }
        }
        return false;
    }
    public boolean check_win_column(String player_mark, String[][] box){
        int count=0;
        for(int i=0;i<7;i++){      //columns
            for(int j=0;j<7;j++){    //rows
                if(box[j][i].equals(player_mark)){
                    count++;
                    if(count==4)
                        return true;
                }
                else
                    count=0;
            }
        }
        return false;
    }
    public boolean check_win_south_east(String player_mark, String[][] box, int r, int c){
        int count=0;
        for(int i=r, j=c; i< box.length && j< box.length;i++,j++){
            if(box[i][j].equals(player_mark)){
                count++;
                if(count==4)
                    return true;
            }
            else count=0;
        }
        return false;
    }
    public boolean check_win_north_west(String player_mark, String[][] box, int r, int c){
        int count=0;
        for(int i=r,j=c; i>=0 && j< box.length; i--,j++){
            if(box[i][j].equals(player_mark)){
                count++;
                if(count==4)
                    return true;
            }
            else
                count=0;
        }
        return false;
    }
    public boolean check_box_isFull(String[][]box){
        int count=-1;
        for(int i=0;i< box.length;i++){
            for(int j=0;j< box.length;j++){
                if(box[i][j].equals("X") || box[i][j].equals("O"))
                    count++;
            }
        }
        if(count==48)
            return true;
        else
            return false;
    }
    public int evaluate(String [][]box){
        boolean x1=check_win_column("X",box);
        boolean x2=check_win_row("X",box);
        boolean x3=false;
        boolean x4=false;
        int posVal=1;
        int negVal=(-posVal);
        int tie=0;
        outer: for(int col=0;col< box.length;col++){
            for(int row=0;row< box.length;row++){
                x3= check_win_south_east("O",box,row,col);
                if(x3)
                    break outer;
            }
        }
        outer:for(int col=0;col< box.length;col++){
            for(int row= box.length-1;row>=0;row--){
                x4= check_win_north_west("O",box,row,col);
                if(x4)
                    break outer;
            }
        }
        boolean o1=check_win_column("O",box);
        boolean o2=check_win_row("O",box);
        boolean o3=false;
        boolean o4=false;
        outer: for(int col=0;col< box.length;col++){
            for(int row=0;row< box.length;row++){
                o3= check_win_south_east("O",box,row,col);
                if(o3)
                    break outer;
            }
        }
        outer:for(int col=0;col< box.length;col++){
            for(int row= box.length-1;row>=0;row--){
                o4= check_win_north_west("O",box,row,col);
                if(o4)
                    break outer;
            }
        }
        boolean isFull=check_box_isFull(box);
        if(x1 || x2 || x3 || x4)
            return posVal;
        else if(o1 || o2 || o3 || o4)
            return negVal;
        else if(isFull)
            return tie;
        else
            return 2;
    }
    public void minimax(String player, float alpha, float beta, int depth){
        if(depth==0)

    }
    public int eval(String[][]box){
        int threeInRowX;
        int threeInRowO;
        for(int i=0;i<7;i++){
            for(int j=0;j<7;j++){
                if(j==5||j==6)
                    break;
                else if(box[j][i].equals("X")){
                    if(box[j+1][i].equals("x")&&box[j+2][i].equals("x"))
                }
            }
        }
    }
}
