import java.util.Scanner;

public class Driver {
    public static void main(String[] args) {
        int num=0;
        Game obj=new Game();
        String[][]box=new String[7][7];
        for(int i=0;i<7;i++){
            for(int j=0;j<7;j++){
                String s=String.valueOf(num);
                if(num<10)
                    box[i][j]="0"+s;
                else
                    box[i][j]=s;
                System.out.print(box[i][j]+" ");
                num++;
            }
            System.out.println();
        }
//        for(int i=0;i<7;i++){
//            for(int j=0;j<7;j++){
//                if(box[i][j].equals("02") || box[i][j].equals("10") || box[i][j].equals("26"))
//                    box[i][j]="O";
//            }
//        }
//        System.out.println();
//        for(int i=0;i<7;i++){
//            for(int j=0;j<7;j++){
//                System.out.print(box[i][j]+" ");
//            }
//            System.out.println();
//        }
        System.out.println("Enter any one position number from 00-48 where you want to put your mark");
        Scanner sc=new Scanner(System.in);
        while(sc.hasNext()){
            String mark_number=sc.next();
            for(int i=0;i<7;i++){
                for(int j=0;j<7;j++){
                    if(box[i][j].equals(mark_number))
                        box[i][j]="O";
                }
            }
            boolean win_col= obj.check_win_column("O",box);
            boolean win_row= obj.check_win_row("O",box);
            boolean win_south_east=false;
            boolean win_north_west=false;
            outer: for(int col=0;col< box.length;col++){
                for(int row=0;row< box.length;row++){
                    win_south_east= obj.check_win_south_east("O",box,row,col);
                    if(win_south_east)
                        break outer;
                }
            }
            outer:for(int col=0;col< box.length;col++){
                for(int row= box.length-1;row>=0;row--){
                    win_north_west= obj.check_win_north_west("O",box,row,col);
                    if(win_north_west)
                        break outer;
                }
            }
            if(win_col || win_row || win_south_east || win_north_west){
                System.out.println("YOU WON !!");
                sc.close();
                break;
            }
            System.out.println("Enter any one position number from 00-48 where you want to put your mark");
            for(int i=0;i<7;i++){
                for(int j=0;j<7;j++){
                    System.out.print(box[i][j]+" ");
                }
                System.out.println();
            }
        }
        for(int i=0;i<7;i++){
            for(int j=0;j<7;j++){
                System.out.print(box[i][j]+" ");
            }
            System.out.println();
        }
    }
}
