public class Program1 {
    public static void main(String[] args) {
        double a= Double.parseDouble(args[0]);

        try{
            double b=Double.parseDouble(args[1]);
            System.out.println(a*b);
        }
        catch (NumberFormatException e) {
            String n=args[1];
            for(int i=0;i<a;i++){
                System.out.print(n);}
        }
    }
}
