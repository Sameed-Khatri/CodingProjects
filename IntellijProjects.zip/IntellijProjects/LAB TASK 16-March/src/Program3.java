public class Program3 {
    public static void main(String[] args) {
        int a=Integer.parseInt(args[0]);
        try{
            int b=Integer.parseInt(args[1]);
            System.out.println(a-b);
        }
        catch (NumberFormatException e){
            String n=(args[1]);
            for(int i=0;i<n.length()-a;i++){
                System.out.print(n.charAt(i));
            }
        }
    }
}
