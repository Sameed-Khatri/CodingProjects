import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.DecimalFormat;

public class SellingStatistics {
    public JPanel SellingStatisticsPanel;
    private JLabel sellingStatisticsLabel;
    private JComboBox<String>TypeComboBox;
    private JComboBox<String>MonthComboBox;
    private JComboBox<String>OptionComboBox;
    private JLabel typeLabel;
    private JLabel yearLabel;
    private JLabel monthLabel;
    private JLabel optionLabel;
    private JSpinner YearSpinner;
    private JTextArea PopularityTextArea;
    private JButton showButton;
    private JLabel popularityLabel;
    private static final String DATABASE_URL = "jdbc:sqlite:SuperMarketDatabase.db";

    public SellingStatistics() {
        int targetYearValue=2023;
        Type type=new Type();
        TypeComboBox.addItem("--");
        String[]types= type.getType();
        for(int i=0;i< types.length;i++){
            TypeComboBox.addItem(types[i]);
        }
        Months month=new Months();
        MonthComboBox.addItem("--");
        String[]months=month.getMonths();
        for(int i=0;i< months.length;i++){
            MonthComboBox.addItem(months[i]);
        }
        PopularityOption option=new PopularityOption();
        String[]options= option.getOptions();
        for(int i=0;i< options.length;i++){
            OptionComboBox.addItem(options[i]);
        }
        OptionComboBox.setSelectedIndex(0);
        YearSpinner.setModel(new SpinnerNumberModel(2023, 1900, 2100, 1));
        JSpinner.NumberEditor editor = (JSpinner.NumberEditor) YearSpinner.getEditor();
        DecimalFormat format = editor.getFormat();
        format.setGroupingUsed(false);
        YearSpinner.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                JSpinner spinner = (JSpinner) e.getSource();
                SpinnerNumberModel spinnerModel = (SpinnerNumberModel) spinner.getModel();
                spinnerModel.setMinimum(1900); // Set minimum year value
                spinnerModel.setMaximum(2100); // Set maximum year value
            }
        });
        YearSpinner.setValue(targetYearValue);
        showButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String productType=(String)TypeComboBox.getSelectedItem();
                String sellYear=String.valueOf(YearSpinner.getValue());
                String sellMonth=(String)MonthComboBox.getSelectedItem();
                String popularityOption=(String)OptionComboBox.getSelectedItem();

                try(Connection connection = DriverManager.getConnection(DATABASE_URL)){
                    String check = "SELECT ProductName, ProductQuantity FROM SellingHistory WHERE ProductType = ? AND SellingMonth = ? AND SellingYear = ?";
                    PreparedStatement statement = connection.prepareStatement(check);
                    statement.setString(1,productType);
                    statement.setString(2,sellMonth);
                    statement.setString(3,sellYear);
                    ResultSet resultSet= statement.executeQuery();
                    String output="";
                    if(popularityOption.equals("Max_ON_TXN")){
                        int maxSellQuantity=Integer.MIN_VALUE;
                        String mostPopularProductName="";
                        while(resultSet.next()){
                            String name=resultSet.getString("ProductName");
                            int sellQuantity=resultSet.getInt("ProductQuantity");
                            if(sellQuantity>maxSellQuantity){
                                maxSellQuantity=sellQuantity;
                                mostPopularProductName=name;
                            }
                        }
                        output=mostPopularProductName+" is the most popular product";
                    }
                    else if(popularityOption.equals("Min_ON_TXN")) {
                        int minSellQuantity = Integer.MAX_VALUE;
                        String leastPopularProductName = "";
                        while (resultSet.next()) {
                            String name = resultSet.getString("ProductName");
                            int sellQuantity = resultSet.getInt("ProductQuantity");
                            if (sellQuantity < minSellQuantity) {
                                minSellQuantity = sellQuantity;
                                leastPopularProductName = name;
                            }
                        }
                        output = leastPopularProductName + " is the least popular product";
                    }
                    else{
                        output = "no products in the table";
                    }
                    PopularityTextArea.setText(output);
                    resultSet.close();
                    statement.close();
                }
                catch (SQLException exception){
                    System.out.println(exception.getMessage());
                }
            }
        });
    }
}
