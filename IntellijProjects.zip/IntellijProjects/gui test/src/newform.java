import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class newform {
    private JButton importProductsButton;
    private JButton sellProductsButton;
    private JButton statisticsButton;
    public JPanel panel1;
    private JLabel mainMenuLabel;

    public newform() {
        importProductsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame importProductsFrame = new JFrame("Import Products");
                importProductsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                importProductsFrame.setContentPane(new ImportProducts().importProductsPanel);
                importProductsFrame.setLocationRelativeTo(null);
                importProductsFrame.setSize(600, 300);
                importProductsFrame.setVisible(true);
            }
        });

        sellProductsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame sellProductsFrame = new JFrame("Sell Products");
                sellProductsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                sellProductsFrame.setContentPane(new SellProducts().SellProductPanel);
                sellProductsFrame.setLocationRelativeTo(null);
                sellProductsFrame.setSize(600,300);
                sellProductsFrame.setVisible(true);
            }
        });

        statisticsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame SellingStatisticsFrame = new JFrame("Statistics");
                SellingStatisticsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                SellingStatisticsFrame.setContentPane(new SellingStatistics().SellingStatisticsPanel);
                SellingStatisticsFrame.setLocationRelativeTo(null);
                SellingStatisticsFrame.setSize(600,300);
                SellingStatisticsFrame.setVisible(true);
            }
        });
    }

//    public static void main(String[] args) {
//        JFrame mainFrame = new JFrame("Main Form");
//        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        mainFrame.setContentPane(new newform().panel1);
//        mainFrame.pack();
//        mainFrame.setLocationRelativeTo(null);
//        mainFrame.setVisible(true);
//    }
}
