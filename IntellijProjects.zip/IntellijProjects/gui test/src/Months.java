public class Months {
    String[] months = {
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"};
    public void setMonths(String[] months) {
        this.months = months;
    }
    public String[] getMonths() {
        return months;
    }
}
