import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class ImportProducts {
    public JPanel importProductsPanel;
    private JLabel importProductsLabel;
    private JLabel productNameLabel;
    private JLabel productTypeLabel;
    private JLabel productQuantityLabel;
    private JTextField ProductNameText;
    private JComboBox <String> ProductTypeComboBox;
    private JTextArea ImportStatusTextArea;
    private JTextField productQuantityText;
    private JButton importButton;
    private JLabel importStatusLabel;
    private static final String DATABASE_URL = "jdbc:sqlite:SuperMarketDatabase.db";
    public ImportProducts() {
        Type type=new Type();
        ProductTypeComboBox.addItem("--");
        String[]types= type.getType();
        for(int i=0;i< types.length;i++){
            ProductTypeComboBox.addItem(types[i]);
        }
        importButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String productName=ProductNameText.getText();
                String productType=(String) ProductTypeComboBox.getSelectedItem();
                int productQuantity=Integer.parseInt(productQuantityText.getText());
                boolean status=addProductInTable(productName,productType,productQuantity);
                if(status){
                    ImportStatusTextArea.setText("Product Imported Successfully");
                    ProductNameText.setText("");
                    ProductTypeComboBox.setSelectedIndex(0);
                    productQuantityText.setText("");
                }
                else
                    ImportStatusTextArea.setText("Failed to Import Product");
            }
        });
    }
    public boolean addProductInTable(String productName, String productType, int productQuantity){
        try(Connection connection= DriverManager.getConnection(DATABASE_URL)){
            String matchProduct = "SELECT ProductQuantity FROM products WHERE ProductName = ?";
            PreparedStatement selectStatement=connection.prepareStatement(matchProduct);
            selectStatement.setString(1,productName);
            ResultSet resultSet=selectStatement.executeQuery();

            if(resultSet.next()){
                int currentProductQuantity=resultSet.getInt("ProductQuantity");
                int newProductQuantity=currentProductQuantity+productQuantity;
                String updateProduct = "UPDATE products SET ProductQuantity = ? WHERE ProductName = ?";
                PreparedStatement updateStatement = connection.prepareStatement(updateProduct);
                updateStatement.setInt(1, newProductQuantity);
                updateStatement.setString(2, productName);
                int rowsUpdated = updateStatement.executeUpdate();
                updateStatement.close();
                resultSet.close();
                selectStatement.close();
                return rowsUpdated>0;
            }
            else{
                String insertProducts = "INSERT INTO products (ProductName, ProductType, ProductQuantity) VALUES (?, ?, ?)";
                PreparedStatement insertStatement = connection.prepareStatement(insertProducts);
                insertStatement.setString(1,productName);
                insertStatement.setString(2,productType);
                insertStatement.setInt(3,productQuantity);
                int rowsInserted=insertStatement.executeUpdate();
                insertStatement.close();
                resultSet.close();
                selectStatement.close();
                return rowsInserted>0;
            }
        }
        catch (SQLException e){
            System.out.println(e.getMessage());
        }
        return false;
    }
}
