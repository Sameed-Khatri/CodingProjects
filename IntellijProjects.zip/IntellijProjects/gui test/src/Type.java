public class Type {
    String[]type={"vegetable","fruit","meat","bakery","pet","baby","beauty"};
    public void setType(String[] type) {
        this.type = type;
    }
    public String[] getType() {
        return type;
    }
}
