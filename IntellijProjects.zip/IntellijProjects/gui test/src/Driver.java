import javax.swing.*;

public class Driver {
//    public static void showTables(){
//        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:SuperMarketDatabase.db")) {
//            // Execute a query to retrieve the metadata of the SellingHistory table
//            ResultSet resultSet = connection.getMetaData().getColumns(null, null, "SellingHistory", null);
//
//            // Iterate over the result set to get the column details
//            while (resultSet.next()) {
//                String columnName = resultSet.getString("COLUMN_NAME");
//                String dataType = resultSet.getString("TYPE_NAME");
//                int columnSize = resultSet.getInt("COLUMN_SIZE");
//                int decimalDigits = resultSet.getInt("DECIMAL_DIGITS");
//                String isNullable = resultSet.getString("IS_NULLABLE");
//
//                // Print the column details
//                System.out.println("Column Name: " + columnName);
//                System.out.println("Data Type: " + dataType);
//                System.out.println("Column Size: " + columnSize);
//                System.out.println("Decimal Digits: " + decimalDigits);
//                System.out.println("Nullable: " + isNullable);
//                System.out.println("------------------------");
//            }
//
//            // Close the result set
//            resultSet.close();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//
//    }
    public static void main(String[] args) {
        //creating main menu gui
        JFrame mainFrame = new JFrame("Main Menu");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setContentPane(new newform().panel1);
        mainFrame.pack();
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setSize(400,300);
        mainFrame.setVisible(true);
//        showTables();
        //creating import products gui
//        JFrame importProductsFrame=new JFrame("Import Products");
//        importProductsFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        importProductsFrame.setContentPane(new ImportProducts().importProductsPanel);
//        importProductsFrame.pack();
//        importProductsFrame.setLocationRelativeTo(null);
//        importProductsFrame.setVisible(true);
    }
}
