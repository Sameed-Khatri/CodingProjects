import org.junit.Assert;
import org.junit.jupiter.api.Test;

class TypeTest {
 @Test
 public void testTypeElements() {
     Type typeObj = new Type();
     String[] expected = {"vegetable", "fruit", "meat", "bakery", "pet", "baby", "beauty"};
     String[] actual = typeObj.getType();

     Assert.assertArrayEquals(expected, actual);
 }
}