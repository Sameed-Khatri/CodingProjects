import javax.swing.*;
import java.awt.*;

public class DropdownMenuExample {
    public static void main(String[] args) {
        // Create a JFrame to hold the dropdown menu
        JFrame frame = new JFrame("Dropdown Menu Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);

        // Create a panel to hold the components
        JPanel panel = new JPanel(new GridBagLayout());

        // Create a dropdown menu
        String[] options = {"Option 1", "Option 2", "Option 3"};
        JComboBox<String> dropdown = new JComboBox<>(options);
        dropdown.setSelectedIndex(0); // Set initial selected option

        // Set preferred size for the dropdown menu
        dropdown.setPreferredSize(new Dimension(150, 30));

        // Create GridBagConstraints to control component positioning
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Add some padding

        // Add the dropdown menu to the panel
        panel.add(dropdown, gbc);

        // Add the panel to the frame
        frame.getContentPane().add(panel);

        // Center the frame on the screen
        frame.setLocationRelativeTo(null);

        // Display the frame
        frame.setVisible(true);
    }
}
