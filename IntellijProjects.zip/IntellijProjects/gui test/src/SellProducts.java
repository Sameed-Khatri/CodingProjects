import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.DecimalFormat;

public class SellProducts {
    public JPanel SellProductPanel;
    private JTextField productNameText;
    private JLabel productNameLabel;
    private JLabel productQuantityLabel;
    private JTextField productQuantityText;
    private JLabel productTypeLabel;
    private JComboBox<String>productTypeComboBox;
    private JLabel sellingDateLabel;
    private JTextArea statusTextArea;
    private JLabel statusLabel;
    private JButton sellButton;
    private JComboBox<String>sellMonthComboBox;
    private JSpinner sellYearSpinner;
    private static final String DATABASE_URL = "jdbc:sqlite:SuperMarketDatabase.db";
    public SellProducts() {
        int targetYearValue=2023;
        Type type=new Type();
        productTypeComboBox.addItem("--");
        String[]types= type.getType();
        for(int i=0;i< types.length;i++){
            productTypeComboBox.addItem(types[i]);
        }
        Months month=new Months();
        sellMonthComboBox.addItem("--");
        String[]months=month.getMonths();
        for(int i=0;i< months.length;i++){
            sellMonthComboBox.addItem(months[i]);
        }
        sellYearSpinner.setModel(new SpinnerNumberModel(2023, 1900, 2100, 1));
        JSpinner.NumberEditor editor = (JSpinner.NumberEditor) sellYearSpinner.getEditor();
        DecimalFormat format = editor.getFormat();
        format.setGroupingUsed(false);
        sellYearSpinner.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                JSpinner spinner = (JSpinner) e.getSource();
                SpinnerNumberModel spinnerModel = (SpinnerNumberModel) spinner.getModel();
                spinnerModel.setMinimum(1900); // Set minimum year value
                spinnerModel.setMaximum(2100); // Set maximum year value
            }
        });
        sellButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String productName=productNameText.getText();
                String productType=(String)productTypeComboBox.getSelectedItem();
                int productQuantity=Integer.parseInt(productQuantityText.getText());
                String sellYear=String.valueOf(sellYearSpinner.getValue());
                String sellMonth=(String)sellMonthComboBox.getSelectedItem();
                boolean status=sell(productName,productType,productQuantity,sellYear,sellMonth);
                if(status){
                    statusTextArea.setText("Product Sold Successfully");
                    productNameText.setText("");
                    productTypeComboBox.setSelectedIndex(0);
                    productQuantityText.setText("");
                    sellMonthComboBox.setSelectedIndex(0);
                    sellYearSpinner.setValue(targetYearValue);
                }
                else{
                    statusTextArea.setText("Not Enough Products");
                }
            }
        });
    }
    public boolean sell(String productName, String productType, int productQuantity, String sellYear, String sellMonth) {
        try (Connection connection = DriverManager.getConnection(DATABASE_URL)) {
            String matchProduct = "SELECT ProductQuantity FROM products WHERE ProductName = ?";
            PreparedStatement selectStatement = connection.prepareStatement(matchProduct);
            selectStatement.setString(1, productName);
            ResultSet resultSet = selectStatement.executeQuery();

            if(resultSet.next()){
                int currentProductQuantity=resultSet.getInt("ProductQuantity");
                int remainingQuantity=currentProductQuantity-productQuantity;
                if(remainingQuantity>=0){
                    String updateProduct="UPDATE products SET ProductQuantity = ? WHERE ProductName = ?";
                    PreparedStatement updateStatement = connection.prepareStatement(updateProduct);
                    updateStatement.setInt(1,remainingQuantity);
                    updateStatement.setString(2,productName);
                    int rowsUpdated=updateStatement.executeUpdate();
                    updateStatement.close();

                    if(rowsUpdated>0){
                        String insertSaleDone="INSERT INTO SellingHistory (ProductName, ProductType, ProductQuantity, SellingYear, SellingMonth) VALUES (?, ?, ?, ?, ?)";
                        PreparedStatement insertSaleStatement=connection.prepareStatement(insertSaleDone);
                        insertSaleStatement.setString(1,productName);
                        insertSaleStatement.setString(2,productType);
                        insertSaleStatement.setInt(3,productQuantity);
                        insertSaleStatement.setString(4,sellYear);
                        insertSaleStatement.setString(5,sellMonth);
                        int saleInserted=insertSaleStatement.executeUpdate();
                        insertSaleStatement.close();
                        return saleInserted>0;
                    }
                }
            }
            resultSet.close();
            selectStatement.close();
        }
        catch (SQLException e){
            System.out.println(e.getMessage());
        }
        return false;
    }

}
