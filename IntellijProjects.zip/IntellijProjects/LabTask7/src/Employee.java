public class Employee {
    protected int hours=40;
    protected double salary=40000;
    protected int VacationDays=10;
    protected String VacationForm="yellow";
    public int getHours(){
        return hours;
    }
    public double getSalary(){
        return salary;
    }
    public String getVacationForm(){
        return VacationForm;
    }
    public int getVacationDays(){
        return VacationDays;
    }
    static class Lawyer extends Employee {
        void sue() {
            System.out.println("I will sue you");
        }
        public int getVacationDays(){
            return VacationDays+7;
        }
        public String getVacationForm(){
            VacationForm="pink";
            return VacationForm;
        }
    }
    static class Secretary extends Employee{
        void takeDictation(){
            System.out.println("Dictation Text");
        }
    }
    static class LegalSecretary extends Employee{
        public double getSalary() {
            return salary + 5000;
        }
        void fileLegalBriefs(){
            System.out.println("I could file all day!");
        }
    }
    static class Marketer extends Employee{
        public double getSalary() {
            return salary + 10000;
        }
        public void advertise(){
            System.out.println("Act now, while supplies last!");
        }
    }
    static class Janitor extends Employee{
        public int getHours() {
            return hours * 2;
        }
        public double getSalary() {
            return salary - 10000;
        }
        public int getVacationDays(){
            return VacationDays-5;
        }
        public void clean(){
            System.out.println("Workin' for the man.");
        }
    }
}
