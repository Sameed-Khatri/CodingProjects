public class DynamicArray2d {
    int row;
    int col;
    int currRowInd;
    int currColInd;
    int[][]arr2d;
    DynamicArray2d(int row, int col) {
        this.row=row;
        this.col=col;
        if(row==0 || col==0){
            System.out.println("Invalid Parameters");
        }
        else{
        arr2d=new int[row][col];
        currRowInd=-1;
        for(int i=0;i<arr2d.length;i++){
            currColInd=-1;
            for(int j=0;j<arr2d.length;j++){
                arr2d[i][j]=(int)(Math.random()*10);
                currColInd++;
            }
            currRowInd++;
        }
    }
    }
    public void appendRow(int[] rowArray) {
        if(rowArray.length==(currColInd+1)){
            row=this.arr2d.length;
            col=this.arr2d[0].length;
            int row_temp=-1;
            int col_temp=-1;
            int[][]arr2d_temp=new int[2*row][col];
            for(int i=0;i< arr2d_temp.length;i++){
                for(int j=0;j< arr2d_temp[0].length;j++){
                    arr2d_temp[i][j]=0;
                }
            }
            for(int i=0;i<this.arr2d.length;i++){
                col_temp=-1;
                for(int j=0;j<this.arr2d[0].length;j++){
                    arr2d_temp[i][j]=this.arr2d[i][j];
                    col_temp++;
                }
                row_temp++;
            }
            this.arr2d=arr2d_temp;

            for(int i=row_temp+1;i<=rowArray.length;i++){
                for(int j=0;j<rowArray.length ;j++){
                    this.arr2d[i][j]=rowArray[j];
                }
            }
        }
        else
            System.out.println("Error : Array size invalid");
    }
    public void appendCol(int[] colArray) {
        int temp=0;
        if(colArray.length==(currRowInd+1)){
            row=this.arr2d.length;
            col=this.arr2d[0].length;
            int row_temp=-1;
            int col_temp=-1;
            int[][]arr2d_temp=new int[row][2*col];
            for(int i=0;i< arr2d_temp.length;i++){
                for(int j=0;j< arr2d_temp[0].length;j++){
                    arr2d_temp[i][j]=0;
                }
            }
            for(int i=0;i<this. arr2d.length;i++){
                col_temp=-1;
                for(int j=0;j<this.arr2d[0].length;j++){
                    arr2d_temp[i][j]=this.arr2d[i][j];
                    col_temp++;
                }
                row_temp++;
            }
            this.arr2d=arr2d_temp;

            for(int i=0;i<colArray.length;i++){
                for(int j=col_temp+1;j<= colArray.length;j++){
                    this.arr2d[i][j]=colArray[i];
                }
            }
        }
        else
            System.out.println("Error : Array size invalid");
    }
    public void print2d() {
        for (int i=0;i< arr2d.length;i++){
            for(int j=0;j< arr2d[0].length;j++){
                System.out.print(arr2d[i][j]+" ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        System.out.println("ATTEMPTING ASSIGNMENT TEST CASE");
        DynamicArray2d obj1=new DynamicArray2d(3,3);
        int[]n={3,6,3};
        int[]m={3,6,3,2,1};
        System.out.println("Actual array created : ");
        obj1.print2d();
        System.out.println();
        System.out.println("Appending column :");
        obj1.appendCol(n);
        obj1.appendCol(n);
        obj1.appendCol(n);
        obj1.appendCol(n);
        obj1.appendCol(n);
        obj1.print2d();
        System.out.println();
        System.out.println("Appending row :");
        obj1.appendRow(m);
        obj1.appendRow(m);
        obj1.appendRow(m);
        obj1.appendRow(m);
        obj1.appendRow(m);
        obj1.appendRow(m);
        obj1.print2d();
        System.out.println();
        System.out.println("SAMPLE RUN TO PROVE THE FUNCTIONING OF THE PROGRAM");
        DynamicArray2d obj2=new DynamicArray2d(3,3);
        int[]k={4,5,4};
        int[]x={9,1,9};
        System.out.println("Actual array created :");
        obj2.print2d();
        System.out.println();
        System.out.println("Appending column :");
        obj2.appendCol(k);
        obj2.print2d();
        System.out.println();
        System.out.println("Appending row :");
        obj2.appendRow(x);
        obj2.print2d();
    }
}
