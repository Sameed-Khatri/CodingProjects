public class Sudoku {
//    int row_temp;
//    int col_temp;
    int[][]arr_sudoku;
    Sudoku(int[][]a){
        arr_sudoku=a;
    }
    public void tempArrayCreate(){
        int row_temp=0;
        int col_temp=0;
        int[][]arr_temp=new int[9][9];
        for(int i=0;i< arr_temp.length;i++){
            for(int j=0;j<arr_temp[0].length;j++){
                arr_temp[i][j]=0;
            }
        }
        for(int p=0;p< arr_sudoku.length;p++){
            col_temp=0;
            for(int k=0;k< arr_sudoku[0].length;k++){
                arr_temp[p][k]= arr_sudoku[p][k];
                col_temp++;
            }
            row_temp++;
        }
        arr_sudoku=arr_temp;
//        System.out.println(col_temp+","+row_temp);
        SudokuRows();
        SudokuColumns();
        boolean checking=validityChecks();
        if(checking){
            System.out.println("ERROR");
            System.out.println();}
        else{
            System.out.println("Sudoku completed successfully, no repeated value.");
            System.out.println();}
    }
    public void SudokuRows(){
        int row_temp=0;
        int col_temp=0;
        int TotalSum_1_9=45;
        int row_sum=0;
        int missingNum=0;
        int rowMissingNum=0;
        for(int i=row_temp;i< arr_sudoku.length-1;i++){
            col_temp=0;
            for(int j=0;j<arr_sudoku.length;j++){
                row_sum=row_sum+arr_sudoku[i][j];
                col_temp++;
            }
//            System.out.println(col_temp);
            missingNum=TotalSum_1_9-row_sum;
            arr_sudoku[i][col_temp-1]=missingNum;
            row_sum=0;
            rowMissingNum=missingNum;
            missingNum=0;
        }
    }
    public void SudokuColumns(){
        int row_temp=0;
        int col_temp=0;
        int TotalSum_1_9=45;
        int col_sum=0;
        int missingNum=0;
        int colMissingNum=0;
        for (int k=col_temp;k< arr_sudoku[0].length;k++){
            row_temp=0;
            for(int p=0;p< arr_sudoku.length;p++){
                col_sum=col_sum+arr_sudoku[p][k];
                row_temp++;
            }
//            System.out.println(row_temp);
            missingNum=TotalSum_1_9-col_sum;
            arr_sudoku[row_temp-1][k]=missingNum;
            col_sum=0;
            colMissingNum=missingNum;
            missingNum=0;
        }
    }
    public boolean validityChecks(){
//        boolean check_1=false;
//        boolean check_2=false;
//        boolean check_3=false;
//        boolean check_4=false;
        boolean FinalCheck=false;
        int row_temp1=0;
//        int col_temp1;
//        int row_temp2=0;
        int col_temp2=0;
        int row_temp3=0;
//        int col_temp3;
        for(int i=0;i< arr_sudoku.length;i++){
            for(int j=0;j<arr_sudoku.length;j++){
                if(arr_sudoku[i][j]>9 || arr_sudoku[i][j]<1){
                    System.out.println("Invalid value :"+arr_sudoku[i][j]+" in row :"+i);
                    return true;}
//                else
//                    check_4=false;
            }
        }
        for(int i=row_temp1;i< arr_sudoku.length;i++){
//            col_temp1=0;
            for(int j=0;j<arr_sudoku.length;j++){
                for(int k= arr_sudoku.length-1;k>j;k--){
                    if(arr_sudoku[i][j]==arr_sudoku[i][k]){
//                        check_1=true;
                        System.out.println("Repeated value found :"+arr_sudoku[i][j]+" in row :"+i);
                        return true;
                    }
//                    else
//                        check_1=false;
                }
//                col_temp1++;
            }
        }
        for(int i=col_temp2;i< arr_sudoku.length;i++){
//            row_temp2=0;
            for(int j=0;j< arr_sudoku.length;j++){
                for(int k= arr_sudoku.length-1;k>j;k--){
                    if(arr_sudoku[j][i]==arr_sudoku[k][i]){
//                        check_2=true;
                        System.out.println("Repeated value found :"+arr_sudoku[j][i]+" in row :"+j);
                        return  true;
                    }
//                    else
//                        check_2=false;
                }
//                row_temp2++;
            }
        }
        int rowStart=0;
        int rowEnd=2;
        int colStart=0;
        int colEnd=2;
        int count=0;
        while(count<9){
            int temp=-1;
            int[]arr_temp=new int[9];
            if(colStart==9&&colEnd==11){
                rowStart=rowStart+3;
                rowEnd=rowEnd+3;
                colStart=0;
                colEnd=2;
            }
            try{
            while(temp<arr_temp.length-1){
        for(int i=rowStart;i<=rowEnd;i++){
            for(int j=colStart;j<=colEnd;j++){
                temp++;
                arr_temp[temp]=arr_sudoku[i][j];
            }
        }}} catch (ArrayIndexOutOfBoundsException e) {
                e.getMessage();
            }

            colStart=colStart+3;
        colEnd=colEnd+3;
        for(int i=0;i<arr_temp.length;i++){
           for(int j=arr_temp.length-1;j>i;j--){
               if(arr_temp[i]==arr_temp[j]){
//                   check_3=true;
                   System.out.println("Repeated value found :"+arr_temp[i]+" in "+count+"   3 x 3 sub-box");
                   return true;
               }
//               else
//                   check_3=false;
           }
        }
        count++;
        }
//        if(check_1 && check_2 && check_3){
//            FinalCheck=true;
//        }
//        else
//            FinalCheck=false;
        return FinalCheck;
    }
    public void printing(){
        for(int i=0;i< arr_sudoku.length;i++){
            for(int j=0;j< arr_sudoku[0].length;j++){
                System.out.print(arr_sudoku[i][j]+" ");
            }
            System.out.println();
        }
    }
    public static void main(String[] args) {
        int[][]arr= {{7 ,1 ,4 ,5 ,6 ,3 ,2 ,9},
                    {9 ,2 ,6 ,7 ,8 ,1 ,5 ,4},
                    {3 ,8 ,5 ,2 ,9 ,4 ,6 ,7},
                    {1 ,4 ,9 ,8 ,7 ,2 ,3 ,5},
                    {2 ,3 ,8 ,6 ,4 ,5 ,9 ,1},
                    {5 ,6 ,7 ,1 ,3 ,9 ,4 ,8},
                    {4 ,9 ,2 ,3 ,1 ,7 ,8 ,6},
                    {8 ,7 ,3 ,9 ,5 ,6 ,1 ,2}};
        Sudoku obj1=new Sudoku(arr);
        obj1.tempArrayCreate();
        obj1.printing();
    }
}
