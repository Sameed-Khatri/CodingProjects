import java.util.Scanner;

public class ArrayUtility {
    public static void swap(int[] A, int i, int j){
        int temp=0;
        temp=A[i];
        A[i]=A[j];
        A[j]=temp;
    }
    public static void shiftRight(int[] B, int i, int j){
//        int temp=0;
//        temp=A[i];
        for(int k=j;k>i;k--){
//            temp=A[k+1];
            B[k]=B[k-1];
//            A[k+1]=temp;
        }
//        printing(B);
    }
    public static void MaxSortSwap(int[]A){
        int temp=0;
        int ArraySize=0;
        while (ArraySize<A.length){
            int max=Integer.MIN_VALUE;
            for(int i=ArraySize;i<A.length;i++){
                if(A[i]>max){
                    max=A[i];
                    temp=i;
                }
            }
            swap(A,temp,ArraySize);
            ArraySize++;
        }
        printing(A);
    }
    public static void MaxSortShiftRight(int[]D){
        int temp=0;
        int overRidden=0;
        int temp2=0;
        while(temp2<D.length){
            int max=Integer.MIN_VALUE;
            for(int j=temp2;j<D.length;j++){
                if(D[j]>max){
                    max=D[j];
                    temp=j;
                }
            }
            overRidden=D[temp];
            shiftRight(D,temp2,temp);
            D[temp2]=overRidden;
            temp2++;
        }
        printing(D);
    }
//    Adding a print function to ease the process.
    public static void printing(int[]A){
        for(int j=0;j<A.length;j++){
            System.out.print(A[j]+" ");
        }
    }

    public static void main(String[] args) {
        int A[]={1,2,3,4,5};
        int B[]={6,7,8,9,10};
        int C[]={4,7,3,2,5};
        int D[]={4,7,3,2,5};
        System.out.println("Array before swapping :");
        printing(A);
        System.out.println();
        System.out.println("Array after swapping :");
        swap(A,3,0);
        printing(A);
        System.out.println();
        System.out.println("Array before shifting right : ");
        printing(B);
        System.out.println();
        System.out.println("Array after shifting right :");
        shiftRight(B,1,4);
        printing(B);
        System.out.println();
        System.out.println("Array to sort using swap function : ");
        printing(C);
        System.out.println();
        System.out.println("Sorting array using swap function : ");
        MaxSortSwap(C);
        System.out.println();
        System.out.println("Array to sort using shift right function : ");
        printing(D);
        System.out.println();
        System.out.println("Sorting array using shift right function : ");
        MaxSortShiftRight(D);
        System.out.println();
        System.out.println("________________________________");

/* EXPLANATION OF PART B WRITTEN AT THE END.

   INPUT OF ARRAY SIZE 'N' USING SCANNER. */
        Scanner sc=new Scanner(System.in);
        System.out.println("INPUT ARRAY SIZE");
        while (sc.hasNextInt()){
        int N= sc.nextInt();
        int[]timeTest1=new int[N];
        int[]timeTest2=timeTest1;
        for(int i=0;i<timeTest1.length;i++){
            timeTest1[i]=(int)(Math.random()*10);
        }
//        for(int i=0;i<timeTest2.length;i++){
//            timeTest2[i]=(int)(Math.random()*10);
//        }
        long StartTime=System.nanoTime();
        System.out.println("Sorted Array is :");
        MaxSortShiftRight(timeTest2);
        System.out.println();
        long EndTime=System.nanoTime();
        long EstimatedTime=EndTime-StartTime;
        System.out.println("Estimated time of sorting using MaxSort-ShiftRight method :"+EstimatedTime+" nano seconds");
        System.out.println();
        long startTime=System.nanoTime();
        System.out.println("Sorted Array is :");
        MaxSortSwap(timeTest1);
        System.out.println();
        long endTime=System.nanoTime();
        long estimatedTime=endTime-startTime;
        System.out.println("Estimated time of sorting using MaxSort-Swap method :"+estimatedTime+" nano seconds");
        System.out.println();
        if(EstimatedTime>estimatedTime)
            System.out.println("MaxSort-Swap implementation is faster for N="+N);
        else if(EstimatedTime<estimatedTime)
            System.out.println("MaxSort-ShiftRight implementation is faster for N="+N);
        else if(EstimatedTime==estimatedTime)
            System.out.println("Array size at which running times are same is N="+N);
    }
        /* EXPLANATION FOR PART B :
        The array size N can be changed by giving different inputs as the scanner reads them until scanner is terminated.
        Most of the runs for array size N<=1000 the running time of MaxSort-ShiftRight method is better and less than
        the running time of MaxSort-Swap method which means that array size N=1000 is a crossover value as for array size N>1000
        the running time of MaxSort-Swap method is better and less than the running time of MaxSort-ShiftRight method. But,
        these values are not fixed as they might vary for multiple runs but calculating the average the above-mentioned
        array size and observation is likely the case. */
    }
}
