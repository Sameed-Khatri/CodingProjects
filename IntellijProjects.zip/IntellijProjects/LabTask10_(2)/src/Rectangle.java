public class Rectangle implements polygon{
    public double height;
    public double width;

    public void setHeight(double h) {
        height = h;
    }

    public void setWidth(double w) {
        width = w;
    }
    public double getHeight(){
        return height;
    }
    public double getWidth(){
        return width;
    }

    @Override
    public double getArea() {
        return height*width;
    }

    @Override
    public double getPerimeter() {
        return 2*(height+width);
    }
    public String toString(){
        return "area of rectangle="+getArea()+"  perimeter of rectangle="+getPerimeter();
    }
}
