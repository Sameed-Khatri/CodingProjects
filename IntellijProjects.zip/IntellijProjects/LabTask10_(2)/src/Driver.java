public class Driver {
    public static void main(String[] args) {
        Square obj1=new Square();
        obj1.length=5;
        System.out.println(obj1);
        Rectangle obj2=new Rectangle();
        obj2.width=4;
        obj2.height=7;
        System.out.println(obj2);
    }
}
