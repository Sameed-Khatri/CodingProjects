public interface polygon {
    public double getArea();
    public double getPerimeter();
}
