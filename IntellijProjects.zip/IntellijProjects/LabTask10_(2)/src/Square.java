public class Square implements polygon{
    public double length;
    public void setLength(double l){
        length=l;
    }

    public double getLength() {
        return length;
    }

    @Override
    public double getArea() {
        return length*length;
    }

    @Override
    public double getPerimeter() {
        return 4*length;
    }
    public String toString(){
        return "area of square="+getArea()+"  perimeter of square="+getPerimeter();
    }
}
