public class GradeBook {
    String coursename;
    public void SetCourseName(String cn){
        this.coursename=cn;
    }
    public String GetCourseName(){
        return coursename;
    }
}
