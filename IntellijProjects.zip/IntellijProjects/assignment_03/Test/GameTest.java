import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class GameTest {

    @Test
    public void play() {
        Game test = new Game();
        int check = test.playOnce();
        Assert.assertTrue(-4 == check || 1 == check || -1 == check || 4 == check);
//        Assert.assertEquals(1,check);
//        Assert.assertEquals(-1,check);
//        Assert.assertEquals(-4,check);
//        Assert.assertEquals(4,check);
    }
}
