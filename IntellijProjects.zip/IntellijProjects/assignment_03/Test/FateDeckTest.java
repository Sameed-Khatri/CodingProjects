import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class FateDeckTest {

    @Test
    public void fateDeckConstructorTest()
    {
        FateDeck f = new FateDeck();

        assertNotNull("Discard stack not created.", f.discardStack);
        assertNotNull("Drawing stack not created.", f.drawingStack);
    }


    @Test
    public void populateFateDeckTest()
    {
        FateDeck f = new FateDeck();

        f.populateDeck();

        assertEquals("Initial drawing stack does not have 2 cards.", 2, f.drawingStack.size());
        assertEquals("Initial discard stack does not have 0 cards.", 0, f.discardStack.size());
    }


    @Test
    public void contentsOfPopulatedFateDeckTest()
    {
        // Create the deck
        FateDeck f = new FateDeck();

        // Populate the dek
        f.populateDeck();

        int numberOfRiches = 0;
        int numberOfRevolution = 0;

        Fate card;

        // Loop until there are no cards in the stack
        while (!f.drawingStack.isEmpty())
        {
            // Get the value of the next card
            card = f.drawCard();

            // Count the card types
            if (card == Fate.RICHES)
            {
                numberOfRiches++;
            }
            else
            {
                numberOfRevolution++;
            }
        }

        assertEquals("Fate deck does not have 1 riches card.", 1, numberOfRiches);
        assertEquals("Fate deck does not have 1 revolution card.", 1, numberOfRevolution);
        assertEquals("After drawing all cards from fate deck, there are still cards left.",
                0, f.drawingStack.size());
        assertEquals("After drawing all cards from fate deck, there are not 2 cards in the discard stack",
                2, f.discardStack.size());
    }


    @Test
    public void resetFateDeckTest()
    {
        // Create and populate deck
        FateDeck f = new FateDeck();

        f.populateDeck();

        // Draw down all of the cards
        while (!f.drawingStack.isEmpty())
        {
            f.drawCard();
        }

        // Reset the deck
        f.resetDeck();

        assertEquals("After resetting the fate deck, there are not 2 cards in the drawing stack",
                2, f.drawingStack.size());
        assertEquals("After resetting the fate deck, there are not 0 cards in the discard stack",
                0, f.discardStack.size());
    }


    @Test
    public void destroyFateDeckTest()
    {
        // Create and populate the deck
        FateDeck f = new FateDeck();

        f.populateDeck();

        // Destroy  the deck
        f.destroyDeck();

        assertEquals("After destroying the fate deck, there are not 0 cards in the discard stack.",
                0, f.discardStack.size());
        assertEquals("After destroying the fate deck, there are not 0 cards in the drawing stack.",
                0, f.drawingStack.size());
    }


    @Test
    public void drawCardFromEmptyFateDeckTest()
    {
        // Create and populate the deck
        FateDeck f = new FateDeck();

        f.populateDeck();

        // Draw down the deck
        while (!f.drawingStack.isEmpty())
        {
            f.drawCard();
        }

        //Force a shuffle by drawing one more card
        f.drawCard();

        assertEquals("After shuffling the fate deck, there are not 2 cards in the drawing stack.",
                1, f.drawingStack.size());
        assertEquals("After shuffling the fate deck, there is not 1 card in the discard stack",
                1, f.discardStack.size());
    }
}