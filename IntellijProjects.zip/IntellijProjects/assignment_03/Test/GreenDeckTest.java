import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class GreenDeckTest {


    @Test
    public void greenDeckConstructorTest()
    {
        GreenDeck g = new GreenDeck();

        Assert.assertNotNull("Discard stack not created.", g.discardStack);
        Assert.assertNotNull("Drawing stack not created.", g.drawingStack);
    }


    @Test
    public void populateGreenDeckTest()
    {
        GreenDeck g = new GreenDeck();

        g.populateDeck();

        Assert.assertEquals("Initial drawing stack does not have 5 cards.", 5, g.drawingStack.size());
        Assert.assertEquals("Initial discard stack does not have 0 cards.", 0, g.discardStack.size());
    }


    @Test
    public void contentsOfPopulatedGreenDeckTest()
    {
        // Create the deck
        GreenDeck g = new GreenDeck();

        // Populate the dek
        g.populateDeck();

        int numberOfBlack = 0;
        int numberOfGreen = 0;

        Color card;

        // Loop until there are no cards in the stack
        while (!g.drawingStack.isEmpty())
        {
            // Get the value of the next card
            card = g.drawCard();

            // Count the card types
            if (card == Color.GREEN)
            {
                numberOfGreen++;
            }
            else
            {
                numberOfBlack++;
            }
        }

        Assert.assertEquals("Green deck does not have 1 green card.", 1, numberOfGreen);
        Assert.assertEquals("Green deck does not have 4 black cards.", 4, numberOfBlack);
        Assert.assertEquals("After drawing all cards from green deck, there are still cards left.",
                0, g.drawingStack.size());
        Assert.assertEquals("After drawing all cards from green deck, there are not 5 cards in the discard stack",
                5, g.discardStack.size());
    }


    @Test
    public void resetGreenDeckTest()
    {
        // Create and populate deck
        GreenDeck g = new GreenDeck();

        g.populateDeck();

        // Draw down all of the cards
        while (!g.drawingStack.isEmpty())
        {
            g.drawCard();
        }

        // Reset the deck
        g.resetDeck();

        Assert.assertEquals("After resetting the green deck, there are not 5 cards in the drawing stack",
                5, g.drawingStack.size());
        Assert.assertEquals("After resetting the green deck, there are not 0 cards in the discard stack",
                0, g.discardStack.size());
    }


    @Test
    public void destroyGreenDeckTest()
    {
        // Create and populate the deck
        GreenDeck g = new GreenDeck();

        g.populateDeck();

        // Destroy  the deck
        g.destroyDeck();

        Assert.assertEquals("After destroying the green deck, there are not 0 cards in the discard stack.",
                0, g.discardStack.size());
        Assert.assertEquals("After destroying the green deck, there are not 0 cards in the drawing stack.",
                0, g.drawingStack.size());
    }


    @Test
    public void drawCardFromEmptyGreenDeckTest()
    {
        // Create and populate the deck
        GreenDeck g = new GreenDeck();

        g.populateDeck();

        // Draw down the deck
        while (!g.drawingStack.isEmpty())
        {
            g.drawCard();
        }

        //Force a shuffle by drawing one more card
        g.drawCard();

        assertEquals("After shuffling the green deck, there are not 4 cards in the drawing stack.",
                4, g.drawingStack.size());
        assertEquals("After shuffling the green deck, there is not 1 card in the discard stack",
                1, g.discardStack.size());
    }
}