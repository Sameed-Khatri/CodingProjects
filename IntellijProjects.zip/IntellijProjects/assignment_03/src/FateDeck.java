public class FateDeck extends Deck<Fate,Card<Fate>>{
    public FateDeck() {super("The Deck of Fate");}

    @Override
    public void populateDeck() {
        destroyDeck();
        drawingStack.add(new Card<Fate>(Fate.REVOLUTION) );
        drawingStack.add(new Card<Fate>(Fate.RICHES) );
    }
}
