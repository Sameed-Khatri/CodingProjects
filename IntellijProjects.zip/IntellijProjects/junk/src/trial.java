import java.util.Scanner;

public class trial {
    public static void main(String[] args) {
        String[]s={"4","+","5"};
        String v=s[0];
        if(Character.isDigit(v.charAt(0)))
            System.out.println(s[0]);
        else
            System.out.println(s[2]);
    }
}
