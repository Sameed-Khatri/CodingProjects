import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

public class trying {
    public static void main(String[] args) {
        File f=new File("C:\\Users\\hp\\Desktop\\testing.txt");
        String line;
        String u="Usage";
        int i=0;
        ArrayList<String>dictFile=new ArrayList<>();
        try {
            Scanner sc=new Scanner(new FileReader(f));
            while (sc.hasNextLine()){
                line= sc.nextLine();
                int k=0;
                int c=0;
                if((line.isEmpty()) || (line.length()==1)){
                }
                else{
                    while(k<u.length()){
                        if(line.charAt(k)==u.charAt(k)){
                            c++;
                        }
                        k++;
                    }
                    if(c==u.length()){

                    }
                    else
                        dictFile.add(line);
                }
            }
        }
        catch (Exception e){
            e.getMessage();
        }
        int j=0;
        while (j< dictFile.size()){
            String sr= dictFile.get(j);
            System.out.println(sr);
            j++;
        }
    }
}
