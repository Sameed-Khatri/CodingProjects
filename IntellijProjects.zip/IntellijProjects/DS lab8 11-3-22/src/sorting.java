public class sorting<T extends Comparable<T>>{
        T[]arr;
    public sorting(T[]a){
        arr=a;
    }
    public void buildMaxHeap(){
        int c=1;
        while (c<arr.length){
            int p=(c-1)/2;
            while (p>=0){
                if(arr[c].compareTo(arr[p])>0){
                    T temp=arr[c];
                    arr[c]=arr[p];
                    arr[p]=temp;
                }
                else {
                    break;
                }
                c=p;
                p=(c-1)/2;
            }
            c++;
        }
        for(int i=0;i< arr.length;i++){
            System.out.print(arr[i]+" ");
        }
    }
    public void ReHeap(int r){
        int i=0;
        int LC;
        int RC;
        while (i<=r){
            LC=(i*2)+1;
            RC=(i*2)+2;
            if((LC<=r)&&(RC<=r)){
                if(arr[LC].compareTo(arr[RC])>0){
                    if(arr[LC].compareTo(arr[i])>0){
                        T temp=arr[LC];
                        arr[LC]=arr[i];
                        arr[i]=temp;
                    }
                }
                else if(arr[RC].compareTo(arr[LC])>0){
                    if(arr[RC].compareTo(arr[i])>0){
                        T temp=arr[RC];
                        arr[RC]=arr[i];
                        arr[i]=temp;
                    }
                }
            }
            else if((LC<=r) && (RC>r)){
                if(arr[LC].compareTo(arr[i])>0){
                    T temp=arr[LC];
                    arr[LC]=arr[i];
                    arr[i]=temp;
                }
            }
            else{
                return;
            }
            i++;
        }
    }
    public void delete(){
        int r= arr.length-1;
        arr[0]=arr[r];
        arr[r]=null;
        r=r-1;
        for(int i=0;i<=r;i++){
            System.out.print(arr[i]+" ");
        }
        System.out.println();
        ReHeap(r);
        System.out.println("RE-HEAPING TREE : ");
        for(int j=0;j< arr.length-1;j++){
            System.out.print(arr[j]+" ");
        }
        System.out.println();
    }

}