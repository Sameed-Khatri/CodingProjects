public class Driver<T extends Comparable<T>> {
    public static void main(String[] args) {
        Integer[] arr = {5, 4, 9, 7, 19, 8, 17, 2, 6, 5, 21};
        sorting<Integer> obj1 = new sorting<>(arr);
        System.out.println("MAX-HEAP : ");
        obj1.buildMaxHeap();
        System.out.println();
        System.out.println("DELETING ROOT NODE : ");
        obj1.delete();
    }
}
