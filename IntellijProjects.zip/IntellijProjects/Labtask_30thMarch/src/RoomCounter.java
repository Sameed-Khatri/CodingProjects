import java.io.*;
import java.util.Scanner;

public class RoomCounter implements java.io.Serializable{
    public static int person=50;
    public  String s;
    public RoomCounter(){

    }
    public static void  addPerson(int add){
        person=person+add;
    }
    public static void removePerson (int minus) throws NegativeCounterException {
        try{
            person=person-minus;
        }
        catch (Exception e){
            if(person<0)
                throw new NegativeCounterException("Number of person(s) is less than zero(0)!!");
        }
    }
    public int GetPersonCount(){
        return person;
    }
    public int wordcount(String s){
        this.s=s;
        int count=0;
        Scanner sc=new Scanner(s);
        while (sc.hasNext())
            count++;
        return count;
    }

    public static void main(String[] args) throws NegativeCounterException, ClassNotFoundException {
        RoomCounter obj = new RoomCounter();
        addPerson(Integer.parseInt(args[0]));
        removePerson(Integer.parseInt(args[1]));
        String filename="file.ser";
        try{
            FileOutputStream file=new FileOutputStream(filename);
            ObjectOutputStream out=new ObjectOutputStream(file);
            out.writeObject(obj);
            out.close();
            file.close();
        }
        catch (IOException e){
            e.printStackTrace();
        }
        RoomCounter obj2=null;
        System.out.println(obj.GetPersonCount());
        try{

            FileInputStream file=new FileInputStream(filename);
            ObjectInputStream in=new ObjectInputStream(file);
            obj2=(RoomCounter)in.readObject();
            String line;
            int count=0;
            Scanner sc=new Scanner(in);
            while(sc.hasNextLine()){
                line=sc.nextLine();
                String word[]=line.split(" ");
                count=count+ word.length;
            }
            System.out.println("number of words: "+count);
            System.out.println(obj2.wordcount("hello"));
            in.close();
            file.close();
        }catch (ArrayIndexOutOfBoundsException e){
            e.printStackTrace();
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }

}
class NegativeCounterException extends Exception{
    public NegativeCounterException(String s){
        System.out.println(s);;
    }
}
