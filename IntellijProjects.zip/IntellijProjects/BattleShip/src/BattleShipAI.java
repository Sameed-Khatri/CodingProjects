import java.util.ArrayList;
import java.util.Random;

public class BattleShipAI {
    private int boardSize;
    private int numShips;
    private int[][] board;
    private int remainingShips;
    private ArrayList<int[]> hits;
    private double[][] probabilityGrid;

    public BattleShipAI() {
        boardSize = 10;
        numShips = 5;
        board = new int[boardSize][boardSize];
        remainingShips = numShips;
        hits = new ArrayList<int[]>();
        probabilityGrid = new double[boardSize][boardSize];
        for(int i=0; i<boardSize; i++) {
            for(int j=0; j<boardSize; j++) {
                probabilityGrid[i][j] = 1.0 / (boardSize * boardSize);
            }
        }
    }

    public int[] makeGuess() {
        Random rand = new Random();
        int[] guess = new int[2];
        double[][] probabilityGridCopy = probabilityGrid.clone();
        boolean found = false;

        while(!found) {
            guess[0] = rand.nextInt(boardSize);
            guess[1] = rand.nextInt(boardSize);

            for(int[] hit : hits) {
                if(hit[0] == guess[0] && hit[1] == guess[1]) {
                    found = false;
                    break;
                }
                else {
                    found = true;
                }
            }
        }

        return guess;
    }

    public void updateProbabilityGrid(int[] guess, boolean hit) {
        if(hit) {
            board[guess[0]][guess[1]] = 1;
            remainingShips--;

            for(int i=0; i<boardSize; i++) {
                for(int j=0; j<boardSize; j++) {
                    if(board[i][j] == 0) {
                        double probability = 0.0;
                        for(int k=0; k<100; k++) {
                            int[] simulatedGuess = new int[]{i, j};
                            ArrayList<int[]> simulatedHits = new ArrayList<int[]>(hits);
                            simulatedHits.add(guess);
                            BattleshipGame simulatedGame = new BattleshipGame(boardSize, numShips);
                            simulatedGame.setBoard(board);
                            simulatedGame.setRemainingShips(remainingShips);
                            simulatedGame.setHits(simulatedHits);
                            while(simulatedGame.getRemainingShips() > 0) {
                                simulatedGuess = makeGuess();
                                boolean simulatedHit = simulatedGame.makeGuess(simulatedGuess);
                                updateProbabilityGrid(simulatedGuess, simulatedHit);
                            }
                            probability += simulatedGame.getScore();
                        }
                        probability /= 100.0;
                        probabilityGrid[i][j] = probability;
                    }
                }
            }
        }
        else {
            board[guess[0]][guess[1]] = -1;
        }

        hits.add(guess);
    }
}

