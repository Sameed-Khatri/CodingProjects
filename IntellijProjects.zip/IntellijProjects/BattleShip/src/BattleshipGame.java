import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class BattleshipGame {
    private int boardSize;
    private int numShips;
    private int[][] board;
    private int remainingShips;
    private ArrayList<int[]> hits;
    private BattleShipAI ai;
    private Random rand;

    public BattleshipGame(int boardSize, int numShips) {
        this.boardSize = boardSize;
        this.numShips = numShips;
        board = new int[boardSize][boardSize];
        remainingShips = numShips;
        hits = new ArrayList<int[]>();
        ai = new BattleShipAI();
        rand = new Random();
    }

    public void play() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to Battleship!");

        for(int i=0; i<numShips; i++) {
            boolean placed = false;
            while(!placed) {
                int x = rand.nextInt(boardSize);
                int y = rand.nextInt(boardSize);
                if(board[x][y] == 0) {
                    board[x][y] = 1;
                    placed = true;
                }
            }
        }

        while(remainingShips > 0) {
            System.out.println("Remaining ships: " + remainingShips);

            System.out.println("Your turn. Enter x and y coordinates separated by a space:");
            int x = scanner.nextInt();
            int y = scanner.nextInt();

            boolean hit = makeGuess(new int[]{x, y});
            if(hit) {
                System.out.println("Hit!");
            }
            else {
                System.out.println("Miss!");
            }

            if(remainingShips == 0) {
                break;
            }

            int[] aiGuess = ai.makeGuess();
            hit = makeGuess(aiGuess);
            if(hit) {
                System.out.println("AI hit at (" + aiGuess[0] + ", " + aiGuess[1] + ")");
            }
            else {
                System.out.println("AI missed at (" + aiGuess[0] + ", " + aiGuess[1] + ")");
            }
        }

        System.out.println("Game over!");
        if(remainingShips == 0) {
            System.out.println("You won!");
        }
        else {
            System.out.println("The AI won!");
        }

        scanner.close();
    }

    public boolean makeGuess(int[] guess) {
        int x = guess[0];
        int y = guess[1];

        if(board[x][y] == 1) {
            board[x][y] = -1;
            remainingShips--;
            hits.add(guess);
            ai.updateProbabilityGrid(guess, true);
            return true;
        }
        else if(board[x][y] == 0) {
            board[x][y] = -1;
            hits.add(guess);
            ai.updateProbabilityGrid(guess, false);
            return false;
        }
        else {
            return false;
        }
    }

    public void setBoard(int[][] board) {
        this.board = board;
    }

    public void setRemainingShips(int remainingShips) {
        this.remainingShips = remainingShips;
    }

    public void setHits(ArrayList<int[]> hits) {
        this.hits = hits;
    }

    public int getRemainingShips() {
        return remainingShips;
    }

    public double getScore() {
        return (double)remainingShips / (double)numShips;
    }
    public static void main(String[] args) {
        BattleshipGame game = new BattleshipGame(10, 5);
        game.play();
    }
}

