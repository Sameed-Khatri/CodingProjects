public interface Salary {
    public double compute_salary();
}
