public class employee implements Salary{
    String name;
    float cnic;
    public employee(String n, float c){
        name=n;
        cnic=c;
    }
    @Override
    public double compute_salary() {
        return 0;
    }

    @Override
    public String toString() {
        return "employee{" +
                "name='" + name + '\'' +
                ", cnic=" + cnic +
                '}';
    }
}
class SalariedEmployee extends employee{
    double weeklyWage;

    public SalariedEmployee(String n, float c, double w) {
        super(n, c);
        weeklyWage=w;
    }

    @Override
    public double compute_salary() {
        return weeklyWage*4;
    }

    @Override
    public String toString() {
        return "SalariedEmployee{"+name+cnic +
                "weeklyWage=" + weeklyWage +
                '}';
    }
}
class HourlyEmployee extends employee{
    double hourlyWage;
    int hoursWorked;

    public HourlyEmployee(String n, float c, double h, int hw) {
        super(n, c);
        hoursWorked=hw;
        hourlyWage=h;
    }

    @Override
    public String toString() {
        return "HourlyEmployee{" +
                "hourlyWage="+name+cnic + hourlyWage +
                ", hoursWorked=" + hoursWorked +
                '}';
    }

    @Override
    public double compute_salary() {
        if(hoursWorked<40)
            return hourlyWage*40;
        return hourlyWage*hoursWorked;
    }
}
class ComissionEmployee extends employee{
    int sales;
    double commisionRate;

    @Override
    public String toString() {
        return "ComissionEmployee{"+name+cnic +
                "sales=" + sales +
                ", commisionRate=" + commisionRate +
                '}';
    }

    public ComissionEmployee(String n, float c, int s, double com) {
        super(n, c);
        sales=s;
        commisionRate=com;
    }

    @Override
    public double compute_salary() {
        return sales*commisionRate;
    }
}
