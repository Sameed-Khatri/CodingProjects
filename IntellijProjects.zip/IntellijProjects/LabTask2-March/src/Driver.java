import java.util.ArrayList;
import java.util.List;

public class Driver {
    public static void main(String[] args) {
        List<employee> e=new ArrayList<>(10);
        e.add(new HourlyEmployee("abc",12345, 15,40));
        e.add(new ComissionEmployee("xyz",46355,10,20));
        e.add(new SalariedEmployee("ghj",769678,105));
        e.add(new HourlyEmployee("hjc",12895, 15,40));
        e.add(new HourlyEmployee("abu",12385, 15,40));
        e.add(new HourlyEmployee("hbc",12565, 15,40));
        e.add(new HourlyEmployee("sdc",146345, 25,40));
        e.add(new HourlyEmployee("agc",16745, 19,41));
        e.add(new SalariedEmployee("ggg",7695128,111));
        e.add(new ComissionEmployee("xjz",445655,10,20));
        for(int i=0;i<10;i++){
            System.out.println(e.get(i));
        }
    }
}
