public class test {
    public static void main(String[] args) {
        int p=-1/2;
        System.out.println(p);
    }
}
