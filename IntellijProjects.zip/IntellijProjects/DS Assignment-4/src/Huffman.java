import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Huffman {
    ArrayList<Character> alphabet;
    ArrayList<Integer> alphaFreq;
    ArrayList<node> minHeap =new ArrayList<>();
    File binary=new File("C:\\Users\\hp\\Desktop\\Binary.txt");
    FileWriter fw;
    node root;
    {
        try {
            fw = new FileWriter(binary);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Huffman() throws IOException {
        ArrayList<Character> alphabet = new ArrayList<>();
        ArrayList<Integer> freqAlpha = new ArrayList<>();
        ArrayList<Character> alphabet2 = new ArrayList<>();
        ArrayList<Integer> freqAlpha2 = new ArrayList<>();
        int nextLine=0;
        try{
        File f=new File("C:\\Users\\hp\\Desktop\\MobyDick.txt");
        Scanner sc=new Scanner(new FileReader(f));
        String s="";
        while (sc.hasNextLine()){
            String line=sc.nextLine();
            if(line.isEmpty()){
                nextLine++;
            }
            else
                s=s+line;
        }
        String s2=s.toLowerCase();
            for(char ch=' ';ch<='~';ch++){
                int c=0;
                for(int i=0;i<s2.length();i++){
                    if(ch==s2.charAt(i))
                        c++;
                    }
                alphabet.add(ch);
                freqAlpha.add(c);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        for(int i=0;i<alphabet.size();i++){
            char c=alphabet.get(i);
            int t=freqAlpha.get(i);
            if(t==0){
                continue;
            }
            else if((c=='!')||(c=='"')||(c=='$')||(c=='&')||(c=='(')||(c==')')||(c=='*')||(c==',')||(c=='-')||(c==':')||
                    (c==';')||(c=='?')||(c=='[')||(c==']'))
                continue;
            else if((c=='0')||(c=='1')||(c=='2')||(c=='3')||(c=='4')||(c=='5')||(c=='6')||(c=='7')||(c=='8')||(c=='9'))
                continue;
            else{
                if(c==' '){
                    alphabet2.add('$');    /* 'S' represents Space character */
                    freqAlpha2.add(t);
                }
                else{
                    alphabet2.add(c);
                    freqAlpha2.add(t);
                }
            }

        }
        alphabet2.add('X');    /* 'X' represents next_line character*/
        freqAlpha2.add(nextLine);
        for(int i=0;i<alphabet2.size();i++){
            System.out.println(alphabet2.get(i)+" "+freqAlpha2.get(i));
            insert(new node(alphabet2.get(i),freqAlpha2.get(i)));
        }
        BuildTree();
        binaryGeneration(root);
        fw.close();
        encode();
        decode();
    }
    public void insert(node n){
        minHeap.add(n);
        node temp;
        for(int i=0;i<minHeap.size();i++){
            node n1= minHeap.get(i);
            for(int j=i+1;j< minHeap.size();j++){
                node n2=minHeap.get(j);
                if(n1.alphaFreq>n2.alphaFreq){
                    temp=n1;
                    minHeap.set(i,n2);
                    minHeap.set(j,temp);
                }
            }
        }
    }
    public node deQueue() {
        node temp=minHeap.get(0);
        minHeap.remove(0);
        for(int i=0;i<minHeap.size();i++){
            node n1= minHeap.get(i);
            for(int j=i+1;j< minHeap.size();j++){
                node n2=minHeap.get(j);
                if(n1.alphaFreq>n2.alphaFreq){
                    temp=n1;
                    minHeap.set(i,n2);
                    minHeap.set(j,temp);
                }
            }
        }
        return temp;
    }
    public void BuildTree(){
        while (!minHeap.isEmpty()){
            if(minHeap.size()==1){
                break;
            }
            node temp1=deQueue();
            node temp2=deQueue();
            char c1=temp1.alphabet;
            char c2=temp2.alphabet;
            char c3='\u0000';
            c3+=c1+c2;
            int sum= temp1.alphaFreq+temp2.alphaFreq;
            node n=new node(c3,sum);
            n.left=temp1;
            n.right=temp2;
            temp1.prev=n;
            temp2.prev=n;
//            if(root==null)
//                root=n;
            minHeap.add(n);
        }
        root= minHeap.get(0);
    }
    public void binaryGeneration(node n) throws IOException {
        if(n==null)
            return;
        else{
            System.out.print("0");
            fw.write("0");
            binaryGeneration(n.left);
//            System.out.print(n.alphabet+""+n.alphaFreq+"  ");
            System.out.print("1");
            fw.write("1");
            binaryGeneration(n.right);
        }
    }
    public void encode() throws IOException {
        File f=new File("C:\\Users\\hp\\Desktop\\Binary.txt");
        Scanner sc=new Scanner(new FileReader(f));
        File compressed=new File("C:\\Users\\hp\\Desktop\\Compressed File.txt");
        FileWriter fileWriter=new FileWriter(compressed);
        String s1="";
        String s2="";
        while (sc.hasNext()){
            s1=s1+sc.next();
        }
        for(int i=0;i<s1.length()/8;i++){
            int bit=Integer.parseInt(s1.substring(8*i,(i+1)*8),2);
            s2=s2+(char)bit;
        }
        fileWriter.write(s2);
//        System.out.println(s2);
        fileWriter.close();
    }
    public void decode() throws IOException {
        File compressed=new File("C:\\Users\\hp\\Desktop\\Compressed File.txt");
        File decompressedBinaryConversion=new File("C:\\Users\\hp\\Desktop\\Decompressed Binary.txt");
        FileWriter fileWriter=new FileWriter(decompressedBinaryConversion);
        Scanner sc=new Scanner(new FileReader(compressed));
        String s="";
        while (sc.hasNext()){
            s=s+sc.next();
        }
        String decompressedBin="";
        for(int i=0;i<s.length();i++){
            decompressedBin=decompressedBin+Integer.toBinaryString(s.charAt(i));
        }
        fileWriter.write(decompressedBin);
        fileWriter.close();
//        fileComparison();
    }
//    public void fileComparison() throws FileNotFoundException {
//        File binary=new File("C:\\Users\\hp\\Desktop\\Binary.txt");
//        File decompressedBinary=new File("C:\\Users\\hp\\Desktop\\Decompressed Binary.txt");
//        Scanner sc1=new Scanner(new FileReader(binary));
//        Scanner sc2=new Scanner(new FileReader(decompressedBinary));
//        String s1="";
//        String s2="";
//        String s3="";
//        while(sc2.hasNext()){
//            s2=s2+sc2.next();
//        }
////        for(int i=0;i<14;i++){
////            garbage=garbage+sc1.next();
////        }
//        while(sc1.hasNext()){
//            s1=s1+sc1.next();
//        }
//        for(int i=14;i<s2.length();i++){
//            s3=s3+s2.charAt(i);
//        }
//        int count=0;
//        for(int i=0;i<s3.length();i++){
//            if(s3.charAt(i)==s2.charAt(i))
//                count++;
//        }
//        System.out.println(s2.length()+"len");
//        System.out.println(count+"ll");
//    }
    public static void main(String[] args) throws IOException {
        Huffman h=new Huffman();
    }

}
