public class node {
    node left;
    node right;
    node prev;
    int alphaFreq;
    char alphabet;
    public node(char a,int af){
        alphabet=a;
        alphaFreq=af;
    }
}
