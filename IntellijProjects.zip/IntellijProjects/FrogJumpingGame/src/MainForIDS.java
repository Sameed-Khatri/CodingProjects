//Sameed Khatri 25249
public class MainForIDS {
    public static void main(String[] args) throws Exception {
        String[]startState={"A","B","_","X","Y"};
        String[]endState={"X","Y","_","A","B"};
        FrogJump obj=new FrogJump(startState,endState);
        System.out.println();
        System.out.println(FrogJump.ANSI_PURPLE+"IDS search solution set starting at depth 0 and iterating to more depths until Goal State is found : "+ FrogJump.ANSI_RESET);
        System.out.println();
        obj.ids();
    }
}
