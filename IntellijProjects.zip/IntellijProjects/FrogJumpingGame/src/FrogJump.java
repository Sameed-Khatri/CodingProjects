//Sameed Khatri 25249
import java.util.*;
public class FrogJump {
    String[] StartingState;
    String[] GoalState;
    ArrayList<String> array1 = new ArrayList<>();
    ArrayList<String> array2 = new ArrayList<>();
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_PURPLE = "\u001B[35m";

    public FrogJump(String[] start, String[] end) {
        StartingState = start;
        GoalState = end;
    }

    public ArrayList<String[]> validMoves(String[] a) throws Exception {
        ArrayList<String[]> supreme = new ArrayList<>();
        separate(a);
        int i = 0;
        while (i < a.length) {
            String[] temp = a.clone();
            int num = number(a[i]);
            if (num == 0) {
                if (a[i].equals("A") || a[i].equals("B")) {
                    if (a[i + 1].equals("_")) {
                        swap(temp, i, i + 1);
                        supreme.add(temp);
                    } else if (a[i + 2].equals("_")) {
                        swap(temp, i, i + 2);
                        supreme.add(temp);
                    }
                } else if (a[i].equals("X") || a[i].equals("Y")) {
                    if (a[i - 1].equals("_")) {
                        swap(temp, i, i - 1);
                        supreme.add(temp);
                    } else if (a[i - 2].equals("_")) {
                        swap(temp, i, i - 2);
                        supreme.add(temp);
                    }
                }
            } else if (num == 1) {
                if(a[i].equals("A")||a[i].equals("B")){
                if (a[i + 1].equals("_")) {
                    swap(temp, i, i + 1);
                    supreme.add(temp);
                } else if (a[i + 2].equals("_")) {
                    swap(temp, i, i + 2);
                    supreme.add(temp);
                }
                }
                else if(i==0 && a[i].equals("_")){
                    if(a[i+1].equals("X") || a[i+1].equals("Y")){
                        swap(temp,i,i+1);
                        supreme.add(temp);
                    }
                }
            }
            else if (num == -1) {
                if(a[i].equals("X")||a[i].equals("Y")){
                if (a[i - 1].equals("_")) {
                    swap(temp, i, i - 1);
                    supreme.add(temp);
                } else if (a[i - 2].equals("_")) {
                    swap(temp, i, i - 2);
                    supreme.add(temp);
                }
                }
                else if(i==a.length-1 && a[i].equals("_")){
                    if(a[i-1].equals("A") || a[i-1].equals("B")){
                        swap(temp,i,i-1);
                        supreme.add(temp);
                    }
                }
            }
            i++;
        }
        array1.clear();
        array2.clear();
        return
                supreme;
    }

    public void separate(String[] s) {
        int half = (s.length / 2);
        for (int i = 0; i < half; i++) {
            array1.add(s[i]);
        }
        for (int j = half + 1; j < s.length; j++) {
            array2.add(s[j]);
        }
    }

    public int number(String s) {
        if (array1.contains(s))
            return 1;
        else if (array2.contains(s))
            return -1;
        else
            return 0;
    }

    public String[] swap(String[] s, int i, int j) {
        String temp = s[i];
        s[i] = s[j];
        s[j] = temp;
        return s;
    }

    public void bfs() throws Exception {
        ArrayList<String[]> temp = new ArrayList<>();
        ArrayList<Integer> visit = new ArrayList<>();
        Queue<String[]> Q = new ArrayDeque<>();
        String[] s = StartingState.clone();
        Q.add(s);
        temp.add(s);
        for(int j=0;j<s.length;j++){
            System.out.print(s[j]+" ");
        }
        System.out.println();
        while (!Q.isEmpty()) {
            String[] top = Q.remove();
            ArrayList<String[]> arr = validMoves(top);
            for (int i = 0; i < arr.size(); i++) {
                int return_val = 0;
                String[] l = arr.get(i);
                if (Arrays.equals(l, GoalState)) {
                    temp.add(l);
                    visit.add(1);
                    for (int j = 0; j < l.length; j++) {
                        System.out.print(l[j] + " ");
                    }
                    System.out.println();
                    System.out.println(ANSI_PURPLE+"Goal State Reached :"+ANSI_RESET);
                    for (int j = 0; j < l.length; j++) {
                        System.out.print(l[j] + " ");
                    }
                    System.exit(0);
                } else {
                    for (int k = 0; k < temp.size(); k++) {
                        String[] check = temp.get(k);
                        if (Arrays.equals(check, l)) {
                            return_val = 100;
                            break;
                        }
                    }
                    if (return_val != 100) {
                        temp.add(l);
                        visit.add(1);
                        Q.add(l);
                        for(int j=0;j<l.length;j++){
                            System.out.print(l[j]+" ");
                        }
                        System.out.println();
                    }
                }
            }
        }
    }

    public void dfs() throws Exception {
        ArrayList<String[]> temp = new ArrayList<>();
        ArrayList<Integer> visit = new ArrayList<>();
        Stack<String[]> stack = new Stack<>();
        String[] s = StartingState.clone();
        stack.push(s);
        temp.add(s);
        for(int j=0;j<s.length;j++){
            System.out.print(s[j]+" ");
        }
        System.out.println();
        while (!stack.isEmpty()) {
            String[] top = stack.pop();
            ArrayList<String[]> arr = validMoves(top);
            for (int i = 0; i < arr.size(); i++) {
                int return_val = 0;
                String[] l = arr.get(i);
                if (Arrays.equals(l, GoalState)) {
                    temp.add(l);
                    visit.add(1);
                    for (int j = 0; j < l.length; j++) {
                        System.out.print(l[j] + " ");
                    }
                    System.out.println();
                    System.out.println(ANSI_PURPLE+"Goal State Reached :"+ANSI_RESET);
                    for (int j = 0; j < l.length; j++) {
                        System.out.print(l[j] + " ");
                    }
                    System.exit(0);
                } else {
                    for (int k = 0; k < temp.size(); k++) {
                        String[] check = temp.get(k);
                        if (Arrays.equals(check, l)) {
                            return_val = 100;
                            break;
                        }
                    }
                    if (return_val != 100) {
                        temp.add(l);
                        visit.add(1);
                        stack.push(l);
                        for(int j=0;j<l.length;j++){
                            System.out.print(l[j]+" ");
                        }
                        System.out.println();
                    }
                }
            }
        }
    }
    public void ids() throws Exception {
        String[]start=StartingState.clone();
        String[]end=GoalState.clone();
        String[]found={};
        int depth=0;
        System.out.println(ANSI_PURPLE+"States searched till depth "+depth+" :"+ANSI_RESET);
        for(int i=0;i<start.length;i++){
            System.out.print(start[i]+" ");
        }
        System.out.println();
        while(! Arrays.equals(found,end)){
            found=dls(depth,start,end);
            depth++;
        }
        if(Arrays.equals(found,end)){
            System.out.println();
            System.out.println(ANSI_PURPLE+"Goal State Reached :"+ANSI_RESET);
            for(int i=0;i< found.length;i++){
                System.out.print(found[i]+" ");
            }
        }
    }
    public String[] dls(int depth, String[]start, String[]end) throws Exception {
        int itr=0;
        String[]bait={};
        Queue<String[]>Q=new ArrayDeque<>();
        if(depth==0){
            if(Arrays.equals(start,end)){
                System.out.println(ANSI_PURPLE+"States searched till depth "+depth+" :"+ANSI_RESET);
                for(int i=0;i<start.length;i++){
                    System.out.print(start[i]+" ");
                }
                System.out.println();
                return start;
            }
        }
        else{
            Q.add(start);
            System.out.println(ANSI_PURPLE+"States searched till depth "+depth+" :"+ANSI_RESET);
            for(int j=0;j<start.length;j++){
                System.out.print(start[j]+" ");
            }
            System.out.println();
            int len;
            while(itr<depth){
                int itr2=0;
                len=Q.size();
                while(itr2<len){
                String[]top=Q.remove();
                ArrayList<String[]>arr=validMoves(top);
                for(int i=0;i< arr.size();i++){
                    String[]l=arr.get(i);
                    if(Arrays.equals(l,end)){
                        for(int j=0;j<l.length;j++){
                            System.out.print(l[j]+" ");
                        }
                        return l;
                    }
                    else{
                        Q.add(l);
                        for(int j=0;j<l.length;j++){
                            System.out.print(l[j]+" ");
                        }
                        System.out.println();
                    }
                }
                itr2++;
            }
                itr++;
        }
    }
        return bait;
    }
}
