//Sameed Khatri 25249
public class MainForDFS {
    public static void main(String[] args) throws Exception {
        String[]startState={"A","B","_","X","Y"};
        String[]endState={"X","Y","_","A","B"};
        FrogJump obj=new FrogJump(startState,endState);
        System.out.println(FrogJump.ANSI_PURPLE+"All the states searched to reach the Goal State using DFS :"+ FrogJump.ANSI_RESET);
        obj.dfs();
    }
}
