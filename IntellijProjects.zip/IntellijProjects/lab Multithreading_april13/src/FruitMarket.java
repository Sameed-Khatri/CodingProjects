import java.util.ArrayList;
import java.util.Scanner;

public class FruitMarket {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the total market capacity");
        int capacity=sc.nextInt();
        ArrayList<String> fruit=new ArrayList<>(capacity);
        System.out.println("adding fruits to the market");
        while(fruit.size()!=capacity)
            fruit.add(sc.next());
        System.out.println("Fruits added to the market");
        farmer obj=new farmer(capacity,fruit);
        Thread t=new Thread(obj);
        consumer obj2=new consumer(capacity,fruit);
        Thread t2=new Thread(obj2);
        t.start();
        t2.start();
    }
}
class market{
    int capacity;
    ArrayList<String> fruit;
    public market(int c,ArrayList<String> f){
        if(c>0)
            capacity=c;
        fruit=f;
    }}
class farmer extends market implements Runnable{
    public farmer(int c, ArrayList<String> l){
        super(c , l);

    }
    public void run(){
        try{
            synchronized (this){
                if(fruit.size()==capacity)
                    wait();
                if(fruit.size()!=capacity){
                    System.out.println("Add more fruits");
                    Scanner sc=new Scanner(System.in);
                    while(fruit.size()!=capacity)
                        fruit.add(sc.next());}
            }} catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }
}
class consumer extends market implements Runnable{
    public consumer(int c, ArrayList<String> l) {
        super(c,l);
    }
    public void run() {
        try{
            synchronized (this){
                Scanner sc=new Scanner(System.in);
                if(fruit.size()==0)
                    System.out.println("loading stock");
                System.out.println("Purchase your desired fruit");
                String FruitSell=sc.next();
                if(!fruit.contains(FruitSell))
                    System.out.println("Fruit out of stock, restocking in process");
                fruit.remove(FruitSell);
                System.out.println("Fruit "+FruitSell+" sold");
                if(!fruit.contains(FruitSell))
                    System.out.println("Fruit "+FruitSell+" out of stock, restocking in process");
                else System.out.println("Restocking in process");
                notifyAll();}
        }catch (Exception e){
            e.printStackTrace();
        }


    }
}
