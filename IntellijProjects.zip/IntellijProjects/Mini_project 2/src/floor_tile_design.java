import java.awt.Color;
public class floor_tile_design {
    public static void main(String[] args) {
        Color black=new Color(0,0,0);
        Color red=new Color(255,0,0);
        int n=Integer.parseInt(args[0]);
        StdDraw.setXscale(0,n);
        StdDraw.setYscale(0,n);
        for(int x=0; x<n; x++){
            for(int y=0; y<n; y++){
                if((x+y)%2==0){
                    StdDraw.setPenColor(black);
                    StdDraw.circle(x+0.5,y+0.5,0.5);
                }
                else{
                    StdDraw.setPenColor(red);
                    StdDraw.filledSquare(x+0.5,y+0.5,0.5);
                }
            }
        }
        StdDraw.show();
    }
}
