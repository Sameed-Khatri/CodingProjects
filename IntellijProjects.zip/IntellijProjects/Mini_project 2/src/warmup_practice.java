import java.awt.Color;
public class warmup_practice {
    public static void main(String[] args) {
        Color black=new Color(0,0,0);
        Color red=new Color(255,0,0);
        StdDraw.setPenColor(black);
        StdDraw.circle(0.3,0.3,0.1);

        StdDraw.setPenColor(red);
        StdDraw.filledSquare(0.6,0.6,0.1);
        StdDraw.show();
    }
}
