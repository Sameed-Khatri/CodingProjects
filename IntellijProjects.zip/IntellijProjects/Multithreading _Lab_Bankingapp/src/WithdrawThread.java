import java.security.PrivateKey;
import java.util.PrimitiveIterator;

public class WithdrawThread implements Runnable {
        private Account account;
        private double amount;
        public WithdrawThread(Account account, double amount) {
            this.account = account;
            this.amount = amount;
        }
        public void run() {
            account.withdraw(amount);
        }
    }

    class DepositThread implements Runnable {
        private Account account;
        private double amount;
        public DepositThread(Account account, double amount) {
            this.account = account;
            this.amount = amount;
        }
        public void run() {
            account.deposit(amount);
        }
    }
    class Deposit_To_Other_Account_Thread implements Runnable{
        private Account account_sender;
        private Account account_receiver;
        private double amount;
        public Deposit_To_Other_Account_Thread(Account account_sender,Account account_receiver,double amount){
            this.account_receiver=account_receiver;
            this.account_sender=account_sender;
            this.amount=amount;
        }
        public void run(){
            account_sender.withdraw(amount);
            account_receiver.deposit(amount);

        }
    }
