
public class Bankingapp {
    public static void main(String [] args ) throws InterruptedException {
        Account accountObject = new Account(100);
        Account obj2=new Account(70);
        Thread t7=new Thread(new Deposit_To_Other_Account_Thread(accountObject,obj2,50));
        t7.start();
        t7.join();
        System.out.println();
        Thread t1=new Thread(new DepositThread(accountObject,30));
        t1.start();
        t1.join();
        Thread t2=new Thread(new DepositThread(accountObject,20));
        t2.start();
        t2.join();
        Thread t3=new Thread(new DepositThread(accountObject,10));
        t3.start();
        t3.join();
        Thread t4=new Thread(new WithdrawThread(accountObject,30));
        t4.start();
        t4.join();
        Thread t5=new Thread(new WithdrawThread(accountObject,50));
        t5.start();
        t5.join();
        Thread t6=new Thread(new WithdrawThread(accountObject,20));
        t6.start();
        t6.join();
    }
}
