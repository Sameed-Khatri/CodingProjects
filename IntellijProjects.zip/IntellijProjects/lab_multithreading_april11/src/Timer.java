public class Timer {
    public static void main(String[] args) {
        System.out.println("main starts");
        print p=new print();
        Thread t=new Thread(p);
        t.start();
    }
}
class print implements Runnable{

    @Override
    public void run() {
        try{
            System.out.println("printing starts");
            for(int i=0;i<=5;i++){
                System.out.println(i+" "+"Thread name --> "+Thread.currentThread().getName());
                Thread.sleep(1000);
            }

        }
        catch (Exception e){
            e.printStackTrace();
        }finally {
            System.out.println("printing ends");
            System.out.println("main ends");
        }
    }
}
