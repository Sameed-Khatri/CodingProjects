import java.util.Scanner;

public class primeCheck_With_Implements {
    public static void main(String[] args) {
        prime2 p2=new prime2();
        Thread t=new Thread(p2);
        t.start();
    }}
class prime2 implements Runnable{

    @Override
    public void run() {
        try{
            Scanner sc =new Scanner(System.in);
            while(sc.hasNext()){
                int i =sc.nextInt();
                int count=0;
                for(int f=2;f<i;f++){
                    if((i%f)==0){
                        count++;
                        break;
                    }
                }
                if(count==0)
                    System.out.println("number is a prime");
                else
                    System.out.println("number is not a prime");

            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
