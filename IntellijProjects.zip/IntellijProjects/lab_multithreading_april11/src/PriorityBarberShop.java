public class PriorityBarberShop {
    public static void main(String[] args) {
        String s=args[0];
        int[] time={20,30,40,35};
        VIP v = new VIP(time);
        Thread vp = new Thread(v);
        NORMAL n=new NORMAL(time);
        Thread nml=new Thread(n);
        vp.setPriority(10);
        nml.setPriority(1);
        vp.start();
        nml.start();
        if(s.equals("NORMAL"))
            vp.suspend();
        if(s.equals("VIP")){
            try {
                nml.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
class VIP implements Runnable{
    int []time=new int[4];
    public VIP(int []t){
        for(int i=0;i<t.length;i++){
            time[i]=t[i];
        }
    }
    @Override
    public void run() {
        int temp=0;
        for(int i=0;i< time.length;i++){
            for(int j=i+1;j<time.length;j++){
                if(time[i]<time[j]){
                    temp=time[i];
                    time[i]=time[j];
                    time[j]=temp;
                }
            }
        }
        for(int i=0;i<time.length;i++){
            System.out.println("vip customer waiting for : "+time[i]+" minutes is served "+"  Thread name --> "+Thread.currentThread().getName());
        }}
}
class NORMAL implements Runnable{
    int []time=new int[4];
    public NORMAL(int[] t){
        for(int i=0;i<t.length;i++){
            time[i]=t[i];
        }
    }
    @Override
    public void run() {
        int temp=0;
        for(int i=0;i< time.length;i++){
            for(int j=i+1;j<time.length;j++){
                if(time[i]<time[j]){
                    temp=time[i];
                    time[i]=time[j];
                    time[j]=temp;
                }
            }}
        for(int i=0;i<time.length;i++){
            System.out.println("normal customer waiting for : "+time[i]+" minutes is served "+"  Thread name --> "+Thread.currentThread().getName());
        }
    }
}
