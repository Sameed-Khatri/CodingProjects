public class EncryptionDecryption {

    public static String encryption(int data, int length){
//        String s=data;
//        int length =s.length();
        int FinalNumber=0;
        String t;
        for(int i=0;i<length;i++){
            int temp=data%10;
            FinalNumber=(FinalNumber*10)+temp;
            data=data/10;
        }
        String encrypted="";
        String temp2="";
        int i=0;
        String s=String.valueOf(FinalNumber);
        while(i<s.length()) {
            if (s.charAt(i) == '0')
                temp2 = "A";
            else if (s.charAt(i) == '1')
                temp2 = "B";
            else if (s.charAt(i) == '2')
                temp2 = "C";
            else if (s.charAt(i) == '3')
                temp2 = "D";
            else if (s.charAt(i) == '4')
                temp2 = "E";
            else if (s.charAt(i) == '5')
                temp2 = "F";
            else if (s.charAt(i) == '6')
                temp2 = "G";
            else if (s.charAt(i) == '7')
                temp2 = "H";
            else if (s.charAt(i) == '8')
                temp2 = "I";
            else if (s.charAt(i) == '9')
                temp2 = "J";
            encrypted=encrypted+temp2;
            i++;
        }
        return encrypted;
    }
    public static String decryption(String data){
        String decrypted="";
        String temp3="";
        for(int i=data.length()-1;i>=0;i--){
            if(data.charAt(i)=='J')
                temp3="9";
            else if(data.charAt(i)=='I')
                temp3="8";
            else if(data.charAt(i)=='H')
                temp3="7";
            else if(data.charAt(i)=='G')
                temp3="6";
            else if(data.charAt(i)=='F')
                temp3="5";
            else if(data.charAt(i)=='E')
                temp3="4";
            else if(data.charAt(i)=='D')
                temp3="3";
            else if(data.charAt(i)=='C')
                temp3="2";
            else if(data.charAt(i)=='B')
                temp3="1";
            else if(data.charAt(i)=='A')
                temp3="0";
            decrypted=decrypted+temp3;
        }
        return decrypted;
    }
    public static void main(String[] args) {
        System.out.println("Encrypting data : ");
        int data =12345;
        String s= String.valueOf(data);
        System.out.println("Encrypted Data : "+encryption(data,s.length()));
        System.out.println();
        System.out.println("Decrypting data : ");
        System.out.println("Decrypted data : "+decryption(encryption(data,s.length())));
    }
}
