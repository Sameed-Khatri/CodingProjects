public class DLinkedList <T extends Comparable<T>>{
    node2 head;

    //implement the following Methods
    public void InsertInorder(T value) {
        node2<T> n= new node2<T>(value);
        node2<T> Temp=head;
        if(head==null){
            head=n;
        }
        else if (head.data.compareTo( n.data)>=0)
        {
            n.next = head;
            n.next.prev = n;
            head = n;
        }

        else
        {
            while (Temp.next != null && Temp.next.data.compareTo( n.data)<0) {
                Temp = Temp.next;
            }
                n.next = Temp.next;
                if (Temp.next != null)
                    n.next.prev = n;
                Temp.next = n;
                n.prev = Temp;
        }

//        node2<T> Temp=head;
////        node2<T> T2=Temp;
//        while (Temp!=null){//&& (Temp.data.compareTo(n.data)<0)){
//            if(Temp.data.compareTo(n.data)>=0){
//                n.prev=Temp.prev;
//                Temp.prev=n;
//                Temp.next=n.next;
//                n.next=Temp;
//            }
//            else if((Temp.data.compareTo(n.data)<=0)&&(Temp.next.data.compareTo(n.data)>=0)){
//                n.prev=Temp;
//                n.next=Temp.next;
//                Temp.next.prev=n;
//                Temp.next=n;
//            }
//            Temp=Temp.next;
//        }
//            if(Temp==head){
//                n.next=head;
//                n.next.prev=n;
//                head=n;
//            }
//            else if(Temp==null){
//                T2.next=n;
//                n.prev=T2;
//            }
//            else{
//                n.next=Temp;
//                n.prev=Temp.prev;
//            }
//            Temp.prev.next=n;
//            Temp.prev=n;
//        }

    }
    public node2 Find(T value) {
        node2<T> Temp=head;
        while(Temp!=null && Temp.data.compareTo(value)!=0){
            Temp=Temp.next;
        }
        return Temp;
    }
    public void Delete(T value) {
        node2<T> Temp=Find(value);
        if(Temp==head){
            head=head.next;
            head.prev=null;
        }
        else if(Temp.next==null){
            Temp.prev.next=null;
        }
        else{
            Temp.next.prev=Temp.prev;
            Temp.prev.next=Temp.next;
        }
    }

    @Override
    public String toString() {
        node2<T> Temp=head;
        String str="";
        while(Temp!=null){
            str=str+" "+Temp.data;
            Temp=Temp.next;
        }
        return str;
    }

    public void clearList(){
        head=null;
    }
    public boolean isEmpty(){
        if(head == null)
            return true;
        return false;
    }
    public int Length(){
        int ListLength=0;
        node2<T> Temp=head;
        while(Temp!=null){
            ListLength++;
            Temp=Temp.next;
        }
        return ListLength;
    }
    public void Reverselist() {
        node2<T> Temp=null;
        node2<T> curr=head;
        while(curr!=null){
            Temp=curr.prev;
            curr.prev=curr.next;
            curr.next=Temp;
            curr=curr.prev;
        }
        if(Temp!=null){
            head=Temp.prev;
        }
    }
}
