import org.w3c.dom.Node;

public class polynomial {
    node3 Head;
    public void insert(int c, int p){
        node3 n=new node3(c,p);
        node3 Temp=Head;
        if(Head==null){
            Head=n;
            n.prev=null;
        }
        else{
            while(Temp.next!=null){
                Temp=Temp.next;
            }
            Temp.next=n;
            n.prev=Temp;
        }

        //code here
    }
    public int Length(){
        int ListLength=0;
        node3 Temp=Head;
        while (Temp!=null){
            ListLength=ListLength+1;
            Temp=Temp.next;
        }
        return ListLength;
    }
    public void addition(polynomial p1, polynomial p2){
        node3 pointer1=p1.Head;
        node3 pointer2=p2.Head;
        node3 Temp=Head;
//        Temp.next=null;
//        polynomial output =new polynomial();
//        node3 result=null;
        while (pointer1!=null && pointer2!=null){
            if(pointer1.power==pointer2.power){
//                output.insert((pointer1.coefficient+ pointer2.coefficient), pointer1.power);
                Temp.coefficient=pointer1.coefficient+ pointer2.coefficient;
                Temp.power=pointer1.power;
                Temp=Temp.next;
                pointer1=pointer1.next;
                pointer2=pointer2.next;
            }
            else if (pointer1.power> pointer2.power){
//                output.insert(pointer1.coefficient, pointer1.power);
                Temp.coefficient=pointer1.coefficient;
                Temp.power=pointer1.power;
                Temp=Temp.next;
                pointer1=pointer1.next;
            }
            else if (pointer1.power< pointer2.power){
//                output.insert(pointer2.coefficient, pointer2.power);
                Temp.coefficient=pointer2.coefficient;
                Temp.power=pointer2.power;
                Temp=Temp.next;
                pointer2=pointer2.next;
            }
        }
        while(pointer1!=null){
//            output.insert(pointer1.coefficient, pointer1.power);
            Temp.coefficient=pointer1.coefficient;
            Temp.power=pointer1.power;
            Temp=Temp.next;
            pointer1=pointer1.next;
        }
        while (pointer2!=null){
//            output.insert(pointer2.coefficient,pointer2.power);
            Temp.coefficient=pointer2.coefficient;
            Temp.power=pointer2.power;
            Temp=Temp.next;
            pointer2=pointer2.next;
        }
        // code here
    }
    public void displayequation() {
        node3 Temp=Head;
        String s="";
        if(Temp==null)
            System.out.println("NO RESULT");
        else{
            while(Temp!=null){
                if(Temp.coefficient>0 && Temp.prev==null){
                    if(Temp.power==1){
                        s=Temp.coefficient+"x";
                    }
                    else if(Temp.power==0){
                        s=""+Temp.coefficient;
                    }
                    else    s=Temp.coefficient+"x^"+ Temp.power;
                }
                else if(Temp.coefficient>0){
                    if(Temp.power==1){
                        s=" + "+Temp.coefficient+"x";
                    }
                    else if(Temp.power==0){
                        s=" + "+Temp.coefficient;
                    }
                    else    s=" + "+Temp.coefficient+"x^"+ Temp.power;

                }
                else if(Temp.coefficient<0){
                    if(Temp.power==1){
                        s=Temp.coefficient+"x";
                    }
                    else if(Temp.power==0){
                        s=""+Temp.coefficient;
                    }
                    else    s=Temp.coefficient+"x^"+ Temp.power;
                }
                System.out.print(s);
                Temp=Temp.next;
            }
        }
        // code here
    }
}
