public class node {
    String name;
    node next;
    public node(String n){
        name=n;
    }
}
