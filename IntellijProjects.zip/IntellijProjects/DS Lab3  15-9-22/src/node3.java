public class node3 {
    int coefficient;
    int power;
    node3 prev;
    node3 next;
    public node3(int c, int p){
        coefficient=c;
        power=p;
    }

}
