public class Game {
    node Tail;
    public void insert(String player) {
        node n= new node(player);
        if(Tail==null){
            Tail=n;
            Tail.next=Tail;
        }
        else{
            n.next=Tail.next;
            Tail.next=n;
            Tail=n;
        }
    }
    public String playGame(){

        node Temp=Tail;
        while(Temp!=Temp.next){
// R=generate random number
            int r=(int) ((Math.random()*10));
//move pointer in list R time
            for(int i=0;i<r;i++){
                Temp=Temp.next;
            }
// delete node where pointer stop
            delete(Temp);
        }
        return Temp.name; // winner
    }
    public void delete(node temp){
        temp.next=temp.next.next;
        if(temp.next == Tail){
            Tail=Tail.next;
        }
    }
    public String toString(){
        return ("The winner is : "+playGame());
    }
}

