public class DriverPolynomial {
    public static void main(String[] args) {
        polynomial p1=new polynomial();
        polynomial p2=new polynomial();
        polynomial result=new polynomial();
        //**********3x^2 + 4x +10 *******// insert polynomial expression p1
        p1.insert(3, 2);
        p1.insert(4, 1);
        p1.insert(10, 0);
//************2x^2 - 2x +4 *******// insert polynomial expression p2
        p2.insert(2, 2);
        p2.insert(-2, 1);
        p2.insert(4, 0);
//******* now add polynomials p1 and p2********


// applying my own modification by adding three conditions to create a list ,of the size of which ever
// list of polynomial p1 or p2 is greater, for the result polynomial and setting all its data to zero which gets
// updated when addition function is called.
        if(p2.Length()==p1.Length()){
            for(int i=0;i< p1.Length();i++){
                result.insert(0,0);
            }
        }
        else if(p1.Length()>p2.Length()){
            for(int i=0;i< p1.Length();i++){
                result.insert(0,0);
            }
        }
        else if(p2.Length()>p1.Length()){
            for(int i=0;i< p2.Length();i++){
                result.insert(0,0);
            }
        }

        result.addition(p1, p2);
// ***********display the result of addition***********
        result.displayequation();
    }
}

