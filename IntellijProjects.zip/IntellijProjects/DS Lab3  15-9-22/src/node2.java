public class node2 <T extends Comparable<T>>{
    T data;
    node2<T> prev;
    node2<T> next;
    public node2(T d){
        data=d;
    }
}
