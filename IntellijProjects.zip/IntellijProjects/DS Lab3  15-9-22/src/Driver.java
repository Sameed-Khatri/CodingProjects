public class Driver {
    public static void main(String[] args) {
        System.out.println("TASK 1");
        Game one =new Game();
        one.insert("abc");
        one.insert("def");
        one.insert("ghi");
        one.insert("jkl");
        one.insert("mno");
        System.out.println(one.toString());
        System.out.println();
        System.out.println();


        System.out.println("TASK 2");
        DLinkedList<Integer> obj =new DLinkedList();
        obj.InsertInorder(10);
        obj.InsertInorder(40);
        obj.InsertInorder(30);
        obj.InsertInorder(20);
        obj.InsertInorder(5);
        System.out.println("List : "+obj);
        System.out.println("Value is at : "+obj.Find(30));
        System.out.println("Length of the list is : "+obj.Length());
        System.out.println("Is the node empty : "+obj.isEmpty());
        System.out.print("Reversing the list : ");
        obj.Reverselist();
        System.out.println(obj);
        obj.Delete(20);
        System.out.println("Reversed list after deletion : "+obj);
        obj.clearList();
        System.out.println("List Cleared");
    }
}
