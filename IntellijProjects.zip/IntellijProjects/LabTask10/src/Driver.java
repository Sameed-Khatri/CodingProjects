public class Driver {
    public static void main(String[] args) {
        Shape obj1 = new Rectangle();
        obj1.length = 5;
        obj1.breadth=2;
        System.out.println(obj1);
        Shape obj2 = new Square();
        obj2.length = 5;
        System.out.println(obj2);
        Shape obj3 = new Circle();
        obj3.Radius=3;
        System.out.println(obj3);
        Shape obj4 = new Trapezium();
        obj4.Height=5;
        obj4.ParallelSide1=3;
        obj4.ParallelSide2=5;
        System.out.println(obj4);
    }
}
