public abstract class Shape {
    public double length;
    public double breadth;
    public double Height;
    public double Base;
    public double Radius;
    public double ParallelSide1;
    public double ParallelSide2;
    public abstract double area();
}
class Rectangle extends Shape {
    @Override
    public double area() {
        return length * breadth;
    }
    public String toString(){
        return "area of rectangle="+area();
    }
}
class Square extends Shape{
    @Override
    public double area() {
        return length*length;
    }
    public String toString(){
        return "area of square="+area();
    }
}
class Circle extends Shape{
    @Override
    public double area() {
        return Math.PI*Radius*Radius;
    }
    public String toString(){
        return "area of circle="+area();
    }
}
class Trapezium extends Shape{
    @Override
    public double area() {
        return 0.5*Height*(ParallelSide1+ParallelSide2);
    }
    public String toString(){
        return "area of trapezium="+area();
    }
}

