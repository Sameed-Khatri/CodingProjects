public class node <T> {
    T data; node<T> left; node<T> right; node<T> prev;
    node(T d){
        data=d;
    }
}

