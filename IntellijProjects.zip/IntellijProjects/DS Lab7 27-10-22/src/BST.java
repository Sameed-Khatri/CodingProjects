public class BST<T extends Comparable<T>> {
    node<T> root;
    public void insert(T key) {
        node<T> n=new node<>(key);
        if(root==null){
            root=n;
            root.prev=null;
        }
        else{
            node<T>temp=root;
            node<T>p=temp;
            while (temp!=null){
                p=temp;
                if(key.compareTo(temp.data)<0){
                    temp=temp.left;
                }
                else{
                    temp=temp.right;
                }
            }
            if(key.compareTo(p.data)<0){
                p.left=n;
                n.prev=p;
            }
            else{
                p.right=n;
                n.prev=p;
            }
        }
    }
    public void LNR(node<T>n){ // required recursive implementation
        if(n==null){
            return;
        }
        else{
            LNR(n.left);
            System.out.print(n.data+" ");
            LNR(n.right);
        }
    }
    public void NLR(node<T>n){ // required recursive implementation
        if(n==null){
            return;
        }
        else{
            System.out.print(n.data+" ");
            NLR(n.left);
            NLR(n.right);
        }
    }
    public void LRN(node n){
        if(n==null)
            return;
        else{
            LRN(n.left);
            LRN(n.right);
            System.out.print(n.data+" ");
        }
    }
    public node<T>[] find(T key){
        node<T>[]arr=new node[2];
        node<T> found=null;
        if(key==null){
            System.out.println("invalid key");
            return null;
        }
        else{
            node<T>temp=root;
            while(temp!=null && (temp.data.compareTo(key)!=0)){
                if(key.compareTo(temp.data)<0){
                    temp=temp.left;
                }
                else{
                    temp=temp.right;
                }
            }
            found=temp;
            if(found==null){
                System.out.println("Node not found");
                return null;
            }
            else{
                arr[0]=found.prev;
                arr[1]=found;
            }
        }

//        System.out.println(found.data);
        return arr;
    }
    public node Minimum(){
        if(root.left==null)
            return root;
        else{
        node<T> temp=root;
        node<T> minimum=null;
        while (temp!=null){
            minimum=temp;
            temp=temp.left;
        }
//        System.out.println(minimum.data);
        return  minimum;
        }
    }
    public node Maximum(){
        if(root.right==null)
            return root;
        else{
            node<T> temp=root;
            node<T> maximum=null;
            while (temp!=null){
                maximum=temp;
                temp=temp.right;
            }
//        System.out.println(maximum.data);
            return maximum;
        }
    }
    public void deleteNoChild(node<T>t,node<T>p){
        if(p.right==t)
            p.right=null;
        else
            p.left=null;
    }
    public void deleteOneChild(node<T>t,node<T>p){
        if(p.left==t){
            if(t.left!=null){
                t.left.prev=p;
                p.left=t.left;
            }
            else{
                t.right.prev=p;
                p.left=t.right;
            }
        }
        else{
            if(t.left!=null){
                t.left.prev=p;
                p.right=t.left;
            }
            else{
                t.right.prev=p;
                p.right=t.right;
            }
        }
    }
    public void delete(T key){
        node<T>[]ref=find(key);
        node<T> p=ref[0];
        node<T> t=ref[1];
        if(t.left==null && t.right==null){
            deleteNoChild(t,p);
        }
        else if((t.left==null && t.right!=null) || (t.right==null && t.left!=null)){
            deleteOneChild(t,p);
        }
        else{
            node<T>minNode=t.right;
            while (minNode.left!=null){
                minNode=minNode.left;
            }
            t.data= minNode.data;
            if(minNode.left==null && minNode.right==null){
                deleteNoChild(minNode,minNode.prev);
            }
            else{
                deleteOneChild(minNode,minNode.prev);
            }
        }
    }
}