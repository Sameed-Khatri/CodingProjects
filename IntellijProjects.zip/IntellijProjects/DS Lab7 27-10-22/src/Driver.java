public class Driver {
    public static void main(String[] args) {
        BST<Integer> obj=new BST<>();
        obj.insert(24);
        obj.insert(20);
        obj.insert(10);
        obj.insert(23);
        obj.insert(30);
        obj.insert(26);
        obj.insert(40);
        System.out.println("LNR : ");
        obj.LNR(obj.root);
        System.out.println();
        System.out.println("LRN : ");
        obj.LRN(obj.root);
        System.out.println();
        System.out.println("NLR : ");
        obj.NLR(obj.root);
        System.out.println();
        System.out.println();
        System.out.println("Finding Node : ");
        node<Integer>[]arr1=obj.find(40);
        if(arr1==null){
            System.out.println("Node does not exist ");
        }
        else{
        System.out.println("Found node is : "+arr1[1]);
        System.out.println("Found node value is : "+arr1[1].data);
        }
        System.out.println();
        System.out.println("Node with minimum value : "+obj.Minimum());
        System.out.println("Minimum node value is : "+obj.Minimum().data);
        System.out.println("Node with maximum value : "+obj.Maximum());
        System.out.println("Maximum node value is : "+obj.Maximum().data);
        System.out.println();
        System.out.println("DELETION PROCESS : ");
        obj.delete(30);
        System.out.println("LNR after deletion : ");
        obj.LNR(obj.root);
        System.out.println();
        System.out.println("LRN after deletion : ");
        obj.LRN(obj.root);
    }
}
