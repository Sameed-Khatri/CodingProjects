public class Stock {
    private String ticker;
    private int shares;
    private double purchasePrice;
    public Stock(String initialTicker, int initialShares, double initialPurchasePrice){
        ticker=initialTicker;
        shares=initialShares;
        purchasePrice=initialPurchasePrice;
    }
    public Stock(){
        this("NONE",0,0.0);
    }
    public String toString(){
        String t=this.ticker;
        int sh=shares;
        double pp=purchasePrice;
        String s=t+" for "+sh+" shares at $"+pp+" per share";
        return s;
    }
    public static boolean equals(Stock obj1, Stock obj2){
        if(obj1.purchasePrice==obj2.purchasePrice || obj1.shares==obj2.shares || obj1.ticker==obj2.ticker)
            return true;
        return false;
    }
    public static void main(String[]args){
        Stock o1=new Stock();
        Stock o2=new Stock();
        o1.purchasePrice= 522.64;
        o1.ticker="AAPL";
        o1.shares=100;
        o2.ticker="BBPL";
        o2.shares=200;
        o2.purchasePrice=550.91;
        System.out.println(o1.toString());
        System.out.println(o2.toString());
        System.out.println("Are both Stocks equal : "+equals(o1,o2));
    }
}
