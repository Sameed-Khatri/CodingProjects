//public class Test {
//    int var;
//    Test(double var){ this.var = (int)var; }
//    Test(int var){ this("aaa"); }
//    Test(String s){ this(); System.out.println(s); }
//    Test(){ System.out.println("bbb"); }
//    public static void main(String[] args)
//    { Test t = new Test(5); }
//    public static void main(String[] args){ System.out.println("output="+m((int)1.5)); }
//    static int m(int x){ return ++x; }
//    int x;
//    public Test(int x){ this.x = x; }
//    public static void m(Test o){ o = new Test(2); }
//    public static void main(String[] args){
//        Test o = new Test(1);
//        m(o);
//        System.out.println("output="+o.x); }
//    private static int x;
//    public Test(){ x++; }
//    public static void main(String[] args){
//        Test o1 = new Test();
//        Test o2 = new Test();
//        System.out.println("output="+x); }
//    public static void main(String[] args){
//        System.out.println("output="+m((int)1.5)); }
//    public static int m(int x){ return ++x; }  <--correction
//}
//}
