public class SearchEngine {
    WordLinkedList obj1 =new WordLinkedList();
    public void searchEngineInsert(String word, String url){
        obj1.insertWord(word, url);
    }
    public String search(String word) {
        String outList="";
        int count=0;
        nodeWord temp =obj1.headWord;
        while(temp!=null){
            if(temp.word.equalsIgnoreCase(word)){
                count++;
                break;}
            else
                temp=temp.next;
        }
        if(count>0){
            nodeURL temp2=temp.headURL;
            while (temp2!=null){
                outList=outList+temp2.url+"  ";
                temp2=temp2.next;
            }
        }
        else
            System.out.println("Word not found");
        return outList;
    }
    public void delete(String word){
        nodeWord temp=obj1.headWord;
        int count=0;
        if(obj1.headWord.word.equalsIgnoreCase(word)){
            obj1.headWord.next.prev=null;
            obj1.headWord=obj1.headWord.next;
        }
        while (temp!=null){
            if(temp.word.equalsIgnoreCase(word)){
                count++;
                break;
            }
            else
                temp=temp.next;
        }
        if(count>0){
            if(temp.next==null){
                temp.prev.next=null;
                temp=null;
            }
            else{
                temp.prev.next=temp.next;
                temp.next.prev=temp.prev;
            }
        }
    }
    public String toString(){
        String str="";
        str=obj1.toString();
        return str;
    }
}
