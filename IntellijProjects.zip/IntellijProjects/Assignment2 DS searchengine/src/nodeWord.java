public class nodeWord {
    nodeWord prev;
    nodeWord next;
    String word;
    nodeURL headURL;
    public nodeWord(String w){
        word=w;
    }
}
