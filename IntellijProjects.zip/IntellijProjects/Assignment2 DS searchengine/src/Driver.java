public class Driver {
    public static void main(String[] args) {
        System.out.println("SIMPLE SEARCH ENGINE : ");
        System.out.println();
        SearchEngine obj1=new SearchEngine();
        obj1.searchEngineInsert("Asia","Wiki.com");
        obj1.searchEngineInsert("Asia","Iba.edu.pk");
        obj1.searchEngineInsert("Asia","ibm.com");
        obj1.searchEngineInsert("Asia","Wiki.com");
        obj1.searchEngineInsert("Karachi","Iba.com");
        obj1.searchEngineInsert("Karachi","Lums.com");
        obj1.searchEngineInsert("Karachi","Yahoo.com");
        obj1.searchEngineInsert("Admission","Wikipedia.com");
        obj1.searchEngineInsert("Admission","Nust.edu.pk");
        obj1.searchEngineInsert("Admission","Yahoo.com");
        System.out.println(obj1);
        System.out.println("URLs of searched word : "+obj1.search("Admission"));
        System.out.println();
        obj1.delete("Admission");
        System.out.println("Searching the deleted word : ");
        System.out.println(obj1.search("Admission"));
        System.out.println();
        System.out.println("MODIFIED SEARCH ENGINE : ");
        System.out.println();
        ModifiedSearchEngine obj2=new ModifiedSearchEngine();
        obj2.ModifiedSearchEngineInsert("Asia","Wiki.com");
        obj2.ModifiedSearchEngineInsert("Asia","Iba.edu.pk");
        obj2.ModifiedSearchEngineInsert("Asia","ibm.com");
        obj2.ModifiedSearchEngineInsert("Asia","Wiki.com");
        obj2.ModifiedSearchEngineInsert("Karachi","Iba.com");
        obj2.ModifiedSearchEngineInsert("Karachi","Lums.com");
        obj2.ModifiedSearchEngineInsert("Karachi","Yahoo.com");
        obj2.ModifiedSearchEngineInsert("Admission","Wikipedia.com");
        obj2.ModifiedSearchEngineInsert("Admission","Nust.edu.pk");
        obj2.ModifiedSearchEngineInsert("Admission","Yahoo.com");
        System.out.println(obj2);
        System.out.println("Urls of searched word : "+obj2.searchModified("Asia"));
        System.out.println();
        System.out.println("deleting a word ");
        obj2.deleteModified("Asia");
        System.out.println("Search engine result after deleting : ");
        System.out.println(obj2);

    }
}
