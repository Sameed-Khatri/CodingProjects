public class ModifiedSearchEngine {
    WordLinkedList obj1 =new WordLinkedList();
    public void ModifiedSearchEngineInsert(String word, String url){
        obj1.insertWord(word, url);
            nodeWord temp=obj1.headWord;
            while(temp.next!=null){temp=temp.next;}
            nodeWord temp2=obj1.headWord;
            int ascii=90;
                int num=(int)(temp.word.charAt(0));
                for(int k=ascii;k>=num;k--){
                    if((num==k)&&temp==obj1.headWord){
                        obj1.arr[num-65]=temp2;
                        break;
                    }
                    else if((num==k) && obj1.arr[num-65]==null){
                        obj1.arr[num-65]=temp;
                        break;
                    }
                    else if(num==k){
                        temp.prev=temp2;
                        temp2.next=temp;
                        temp2=temp;
                        break;
                    }
                }
            }
    public String searchModified(String word){
        String outURLList="";
        int count=0;
        nodeWord temp2=null;
        nodeWord trashNode=obj1.headWord;
        int i=0;
        while (i<26) {
            nodeWord temp = obj1.arr[i];
            if (temp == null) {
                temp = trashNode;
            } else if (temp.word.equalsIgnoreCase(word)) {
                count++;
                temp2 = temp;
                break;
            }
            i++;
        }
        if (count>0){
            nodeURL n=temp2.headURL;
            while (n!=null){
                outURLList=outURLList+n.url+" ";
                n=n.next;
            }
        }
        else{
            System.out.println("word not found ");
        }
        return outURLList;
    }
    public void deleteModified(String word){
        int count=0;
//        nodeWord temp2=null;
        nodeWord trashNode=obj1.headWord;
        int i=0;
        int delete=0;
        while (i<26) {
            nodeWord temp = obj1.arr[i];
            if (temp == null) {
                temp = trashNode;
            } else if (temp.word.equalsIgnoreCase(word)) {
                count++;
                break;
            }
            delete++;
            i++;
        }
        if (count>0){
            obj1.arr[delete]=null;
        }
    }
    public String toString(){
        String str1="";
        String str2="";
        String str3="";
        nodeWord trashNode=obj1.headWord;
        int i=0;
        while (i<26){
            nodeWord temp=obj1.arr[i];
            while (temp!=null) {
                if (temp == null) {
                    temp = trashNode;
                } else {
                    nodeURL temp2 = temp.headURL;
                    str1 = str1 + "WORD IS : " + temp.word + "\n" + "URLs ARE : ";
                    while (temp2 != null) {
                        str2 = str2 + temp2.url + "  ";
                        temp2 = temp2.next;
                    }
                    str3 = str3 + "\n" + str1 + str2 + "\n";
                    str1 = "";
                    str2 = "";
                }
                temp = temp.next;
            }
            i++;
            }
        return str3;
    }
}
