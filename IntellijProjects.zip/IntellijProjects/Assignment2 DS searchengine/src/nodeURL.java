public class nodeURL {
    nodeURL prev;
    nodeURL next;
    String url;
    public nodeURL(String u){
        url=u;
    }
}
