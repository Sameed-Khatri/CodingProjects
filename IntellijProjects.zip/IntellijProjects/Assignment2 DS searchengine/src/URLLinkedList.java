public class URLLinkedList {
    nodeURL headURL;
    public nodeURL insertURL(String url){
        nodeURL n=new nodeURL(url);
        if(headURL==null){
            headURL=n;
            n.prev=null;
        }
        else{
            nodeURL temp=headURL;
            while (temp.next!=null){
                temp=temp.next;
            }
            temp.next=n;
            n.prev=temp;
        }
        return n;
    }
}
