public class WordLinkedList {
    nodeWord headWord;
    int IN=0;
    nodeWord []arr=new nodeWord[26];
    public void insertWord(String word, String url) {
        nodeWord n = new nodeWord(word);
        URLLinkedList n2 = new URLLinkedList();
        if (headWord == null) {
            headWord = n;
            n.prev = null;
            n.headURL=n2.insertURL(url);
            IN++;
        }

        else {
            int count = 0;
            nodeWord temp = headWord;
            nodeURL temp2 = temp.headURL;
            while (temp != null) {
                if (temp.word.equals(word)) {
                    count++;
                    break;
                }
                if (temp.next == null)
                    break;
                else
                    temp = temp.next;
            }
            if (count < 1) {
                temp.next = n;
                n.prev = temp;
                n.headURL=n2.insertURL(url);
                IN++;
            } else if (count >= 1) {
                int count2 = 0;
                temp2=temp.headURL;
                while (temp2 != null) {
                    if (temp2.url.equals(url)) {
                        count2++;
                        break;
                    }
                    if (temp2.next == null)
                        break;
                    else
                        temp2 = temp2.next;
                }
                if (count2 >= 1)
                    System.out.println("Word '" + word + "' and URL '" + url + "' already exists : ");
                else {
                    assert temp2 != null;
                    temp2.next = n2.insertURL(url);

                }
            }

        }

    }

    @Override
    public String toString() {
        String str1="";
        String str2="";
        String str3="";
        nodeWord temp=headWord;
        while (temp!=null){
            nodeURL temp2=temp.headURL;
            str1=str1+"WORD IS : "+temp.word+"\n"+"URLs ARE : ";
            while (temp2!=null){
                str2=str2+temp2.url+"  ";
                temp2=temp2.next;
            }
            str3=str3+"\n"+str1+str2+"\n";
            str1="";
            str2="";
            temp=temp.next;
        }
        return str3;
    }
}

