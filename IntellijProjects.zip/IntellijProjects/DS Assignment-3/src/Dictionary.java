public class Dictionary<T extends Comparable<T>> {
    nodeDict root;
    public void insert(String name, String meaning){
        nodeDict n=new nodeDict(name,meaning);
        if(root==null){
            root=n;
            root.prev=null;
        }
        else{
            nodeDict temp=root;
            nodeDict p=temp;
            while (temp!=null){
                p=temp;
                if(name.compareTo(temp.word)<0){
                    temp=temp.left;
                }
                else {
                    temp=temp.right;
                }
            }
            if(name.compareTo(p.word)<0){
                p.left=n;
                n.prev=p;
            }
            else{
                p.right=n;
                n.prev=p;
            }
        }
    }
    public nodeDict[] find(String FindWord){
        nodeDict[]arr=new nodeDict[2];
        nodeDict found=null;
        if(FindWord==null){
            System.out.println("invalid input");
            return null;
        }
        else {
            nodeDict temp = root;
            while ((temp != null) && (temp.word.compareTo(FindWord) != 0)) {
                if (FindWord.compareTo(temp.word) < 0) {
                    temp = temp.left;
                } else {
                    temp = temp.right;
                }
                found = temp;
                if (found == null) {
                    System.out.println("Node not found");
                    return null;
                } else {
                    arr[0] = found.prev;
                    arr[1] = found;
                }
            }
        }
        return arr;
    }
    public void LNR(nodeDict n){
        if(n==null){
            return;
        }
        else{
            LNR(n.left);
            System.out.println(n.word+"  "+n.meaning);
            LNR(n.right);
        }
    }
    public void LRN(nodeDict n){
        if(n==null){
            return;
        }
        else{
            LRN(n.left);
            LRN(n.right);
            System.out.println(n.word+"  "+n.meaning);
        }
    }
    public void NLR(nodeDict n){
        if(n==null){
            return;
        }
        else{
            System.out.println(n.word+"  "+n.meaning);
            NLR(n.left);
            NLR(n.right);
        }
    }
    public void deleteNoChild(nodeDict t,nodeDict p){
        if(p.right==t)
            p.right=null;
        else
            p.left=null;
    }
    public void deleteOneChild(nodeDict t,nodeDict p){
        if(p.left==t){
            if(t.left!=null){
                t.left.prev=p;
                p.left=t.left;
            }
            else{
                t.right.prev=p;
                p.left=t.right;
            }
        }
        else{
            if(t.left!=null){
                t.left.prev=p;
                p.right=t.left;
            }
            else{
                t.right.prev=p;
                p.right=t.right;
            }
        }
    }
    public void delete(String Word){
        nodeDict[]ref=find(Word);
        nodeDict p=ref[0];
        nodeDict t=ref[1];
        if(t.left==null && t.right==null){
            deleteNoChild(t,p);
        }
        else if((t.left==null && t.right!=null) || (t.right==null && t.left!=null)){
            deleteOneChild(t,p);
        }
        else{
            nodeDict minNode=t.right;
            while (minNode.left!=null){
                minNode=minNode.left;
            }
            t.word= minNode.word;
            t.meaning= minNode.meaning;
            if(minNode.left==null && minNode.right==null){
                deleteNoChild(minNode,minNode.prev);
            }
            else{
                deleteOneChild(minNode,minNode.prev);
            }
        }
    }
}
