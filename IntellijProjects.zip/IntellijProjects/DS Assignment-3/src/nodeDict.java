public class nodeDict {
    String word;
    String meaning;
    nodeDict left;
    nodeDict right;
    nodeDict prev;
    nodeDict(String w, String m){
        word=w;
        meaning=m;
    }
}
