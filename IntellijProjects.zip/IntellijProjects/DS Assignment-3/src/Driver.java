import javax.sound.midi.Soundbank;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

                              /* COMMENT TASK2 TO SEE TASK1*/

import static java.util.Collections.shuffle;

public class Driver {
    public static void main(String[] args) {
        System.out.println("-------- TASK 1 --------");
        BST_Task1 <Integer> obj=new BST_Task1<>();
        obj.insert(24);
        obj.insert(20);
        obj.insert(10);
        obj.insert(23);
        obj.insert(30);
        obj.insert(26);
        obj.insert(40);
        System.out.println("Printing range : ");
        obj.PrintRange(obj.root,23,30);
        System.out.println();

        /* TO CHECK EACH FUNCTION IN TASK2 PLEASE COMMENT OUT THE OTHER FUNCTIONS AS THE TXT FILE IS TOO LONG*/

        System.out.println("-------- TASK 2 --------");
        Dictionary<String> obj1=new Dictionary<>();
        String line;
        ArrayList<String>dictFile =new ArrayList<>();
        String check="Usage";
        try{
            File f=new File("C:\\Users\\hp\\Downloads\\Dictionary.txt");
            Scanner sc=new Scanner(new FileReader(f));
        while (sc.hasNextLine()){
            line=sc.nextLine();
            if((line.isEmpty()) || (line.length()==1) ){
            }
            else{
                dictFile.add(line);
            }
        }
        shuffle(dictFile);
        int size=dictFile.size();
        int i=0;
        while (i<=size){
            String s= dictFile.get(i);
            String word="";
            String meaning="";
            String[]arr=s.split("  ");
            word=arr[0];
            for(int j=1;j< arr.length;j++){
                meaning=meaning+" "+arr[j];
            }

            obj1.insert(word,meaning);
            i++;
        }
        }
        catch (Exception e){
            e.getMessage();
        }
        System.out.println();
        System.out.println("LNR : ");
        obj1.LNR(obj1.root);
        System.out.println();
        System.out.println("LRN : ");
        obj1.LRN(obj1.root);
        System.out.println();
        System.out.println("NLR : ");
        obj1.NLR(obj1.root);
        System.out.println();
        System.out.println("Finding word : ");
        nodeDict[]arr2=obj1.find("Clear-headed");
        System.out.println("Word : "+arr2[1].word+" : is at node : "+arr2[1]);
        System.out.println();
        System.out.println("Deleting : ");
        obj1.delete("Black maria");
        System.out.println("Finding word : ");
        nodeDict[]arr3=obj1.find("Black maria");
        try{
        System.out.println("Word : "+arr3[1].word+" : is at node : "+arr3[1]);
        }
        catch (Exception e){
            e.getMessage();
        }
        System.out.println();
        System.out.println("LNR after deletion : ");
        obj1.LNR(obj1.root);
        System.out.println();
        System.out.println("LRN after deletion : ");
        obj1.LRN(obj1.root);
        System.out.println();
        System.out.println("NLR after deletion : ");
        obj1.NLR(obj1.root);
        System.out.println();
    }
}
