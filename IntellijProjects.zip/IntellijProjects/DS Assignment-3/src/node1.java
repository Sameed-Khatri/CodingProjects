public class node1 <T> {
    T data; node1<T> left; node1<T> right; node1<T> prev;
    node1(T d){
        data=d;
    }
}

