public class BST_Task1<T extends Comparable<T>> {
    node1<T> root;
    public void insert(T key) {
        node1<T> n=new node1<>(key);
        if(root==null){
            root=n;
            root.prev=null;
        }
        else{
            node1<T>temp=root;
            node1<T>p=temp;
            while (temp!=null){
                p=temp;
                if(key.compareTo(temp.data)<0){
                    temp=temp.left;
                }
                else{
                    temp=temp.right;
                }
            }
            if(key.compareTo(p.data)<0){
                p.left=n;
                n.prev=p;
            }
            else{
                p.right=n;
                n.prev=p;
            }
        }
    }
    public void PrintRange(node1<T> r,T key1,T key2){
        if(r==null){
            System.out.print("");
        }
        else{
            PrintRange(r.left,key1,key2);
            if((r.data.compareTo(key1)>=0)&&(r.data.compareTo(key2)<=0)){
                System.out.print(r.data+" ");
            }
            PrintRange(r.right,key1,key2);
        }
    }
}
