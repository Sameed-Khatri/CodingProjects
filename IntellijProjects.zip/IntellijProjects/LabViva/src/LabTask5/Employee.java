package LabTask5;

public class Employee {
    private int CNIC;
    private String name;
    private int salary;

    public Employee() {
        System.out.println("No-argument constructor called.");
    }

    public int setCNIC(int initialcnic) {
        return this.CNIC = initialcnic;
    }

    public String setName(String initialName) {
        return this.name = initialName;
    }

    public int setSalary(int initialSalary) {
        return this.salary = initialSalary;
    }

    public Employee(int cnic, String name) {
        this.CNIC = setCNIC(cnic);
        this.name = setName(name);
    }

    public Employee(int c, String n, int salary) {
        new Employee(c, n);
        this.salary = setSalary(salary);
    }

    public int getCNIC() {
        return this.CNIC;
    }

    public String getName() {
        return this.name;
    }

    public int getSalary() {
        return this.salary;
    }

    public static void main(String[] args) {
        Employee obj1 = new Employee();
        obj1.setCNIC(4230166);
        obj1.setName("MIKE");
        obj1.setSalary(42000);
        System.out.println("NAME " + obj1.getName());
        System.out.println("CNIC number " + obj1.getCNIC());
        System.out.println("Salary " + obj1.getSalary());
    }
}
