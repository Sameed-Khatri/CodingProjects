package LabTask5;

public class Pet {
    private String Name;
    private int Age;
    private double Weight;

    public Pet(String name, int age, double weight) {
        this.Name = name;
        if (age < 0)
            System.out.println("Enter a valid age");
        else
            this.Age = age;
        if (weight < 0)
            System.out.println("Enter valid weight");
        else
            this.Weight = weight;
    }

    public Pet() {
        System.out.println("Details of your pet");
    }

    public void setPet(String newName, int newAge, double newWeight) {
        this.Name = newName;
        if (newAge < 0)
            System.out.println("Enter a valid age");
        else
            this.Age = newAge;
        if (newWeight < 0)
            System.out.println("Enter valid weight");
        else
            this.Weight = newWeight;
    }

    public Pet(String s) {
        this.Name = s;
        this.Weight = 0.0;
        this.Age = 0;
    }

    public void setName(String newName) {
        this.Name = newName;
    }

    public Pet(double w) {
        this.Weight = w;
        this.Age = 0;
        this.Name = "";
    }

    public void setWeight(double newWeight) {
        this.Weight = newWeight;
    }

    public Pet(int a) {
        this.Age = a;
        this.Weight = 0;
        this.Name = "";
    }

    public void setAge(int newAge) {
        this.Age = newAge;
    }

    public String getName() {
        return this.Name;
    }

    public int getAge() {
        return this.Age;
    }

    public double getWeight() {
        return this.Weight;
    }

    public void writeOutput() {
        System.out.println("Name is : " + getName());
        System.out.println("Age is : " + getAge() + " years");
        System.out.println("Weight is : " + getWeight() + " kg");
    }

    public static void main(String[] args) {
        Pet obj = new Pet();
        obj.Name = "Spike";
        obj.Weight = 15.0;
        obj.Age = 7;
        obj.writeOutput();
        System.out.println();
        System.out.println("New Details");
        obj.setName("Oreo");
        obj.setAge(10);
        obj.setWeight(16.0);
        obj.writeOutput();
    }
}
