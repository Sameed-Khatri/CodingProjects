package LabTask2;

public class Television {
    private String manufacturer;
    private int screenSize;
    private boolean powerOn;
    private int channel;
    private int volume;
    public void setScreenSize(int size){
        screenSize=size;
    }
    public void setManufacturer(String s){
        manufacturer=s;
    }
    public void setChannel(int Station){
        channel=Station;
    }
    public void setVolume(int vol){
        volume=vol;
    }
    public boolean power(String n){
        if(n.charAt(0)=='O'&&n.charAt(1)=='N')
            powerOn=true;
        else
            powerOn=false;
        return powerOn;
    }
    public int increaseVolume(){
        if (volume<100)
            volume=volume+1;
        return volume;
    }
    public int decreaseVolume(){
        if (volume>0)
            volume=volume-1;
        return volume;
    }
    public int getChannel(){
        return channel;
    }
    public int getVolume(){
        return volume;
    }
    public String getManufacturer(){
        return manufacturer;
    }
    public int getScreenSize(){
        return screenSize;
    }
    public static void main(String[]args){
        Television obj=new Television();
        if(obj.power("ON")){
            obj.setChannel(55);
            obj.setVolume(20);
            obj.setManufacturer("SONY");
            obj.setScreenSize(50);
            System.out.println("Channel number "+obj.getChannel());
            System.out.println("Volume is "+ obj.getVolume());
            System.out.println("Volume up "+ obj.increaseVolume());
            System.out.println("Volume down "+ obj.decreaseVolume());
            System.out.println("Manufacturer of television is "+ obj.getManufacturer());
            System.out.println("Screen size of the television is "+ obj.getScreenSize()+" inches ");
        }
    }
}
