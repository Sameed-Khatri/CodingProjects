package LabTask2;

import LabTask2.GradeBook;

public class GradeBookTest {
    public static void main(String[]args){
        GradeBook obj=new GradeBook();
        obj.SetCourseName(args[0]);
        System.out.println("Welcome to the LabTask2.GradeBook of "+obj.GetCourseName());
    }
}
