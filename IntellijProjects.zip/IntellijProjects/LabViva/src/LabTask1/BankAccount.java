package LabTask1;

public class BankAccount {
    int accountNumber;
    String accountHolderName;
    String accountType;
    double balance;
    public void setAccountNumber(int acc_Number){
        this.accountNumber=acc_Number;
    }
    public void setAccountHolderName(String acc_HolderName){
        this.accountHolderName=acc_HolderName;
    }
    public void setAccountType(String acc_Type){
        this.accountType=acc_Type;
    }
    public void setBalance(double bal){
        this.balance=bal;
    }
    public int getAccountNumber(){
        return accountNumber;
    }
    public String getAccountHolderName(){
        return accountHolderName;
    }
    public String getAccountType(){
        return accountType;
    }
    public double getBalance(){
        return balance ;
    }
    public void depositAmount(){

    }
    public void withdrawl(){

    }
    public static void main(String[]args){
        BankAccount Account1=new BankAccount();
        Account1.setAccountNumber(22);
        Account1.setBalance(2000.5);
        Account1.setAccountType("Saving");
        Account1.setAccountHolderName("ABC");
        System.out.println("Account1");
        System.out.println(Account1.getAccountNumber());
        System.out.println(Account1.getAccountType());
        System.out.println(Account1.getAccountHolderName());
        System.out.println(Account1.getBalance());
        BankAccount Account2=new BankAccount();
        Account2.setAccountNumber(12);
        Account2.setBalance(1000.5);
        Account2.setAccountType("Joined");
        Account2.setAccountHolderName("XYZ");
        System.out.println("Account2");
        System.out.println(Account2.getAccountNumber());
        System.out.println(Account2.getAccountType());
        System.out.println(Account2.getAccountHolderName());
        System.out.println(Account2.getBalance());
    }
}
