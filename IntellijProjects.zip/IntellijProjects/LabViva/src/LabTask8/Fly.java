package LabTask8;

public class Fly {
    Boolean canFly;
    int Age;
    public Fly(){

    }
    public Fly(Boolean c, int a){
        canFly=c;
        Age=a;
    }
    public void setFly(boolean b){
        canFly=b;
    }
    public boolean getFly(){
        return canFly;
    }
    public String toString(){
        String s=",Age :"+Age+",can fly : "+canFly;
        return s;
    }
}
