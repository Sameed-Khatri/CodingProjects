package LabTask7;

public class run {
    public static void main(String[] args) {
        Employee.Lawyer obj1= new Employee.Lawyer();
        System.out.println("LabTask7.LabTask9.Employee type: Lawyer");
        System.out.println("Salary $"+obj1.getSalary());
        System.out.println("Vacation Days "+obj1.getVacationDays());
        System.out.println("Working Hours "+obj1.getHours());
        System.out.println("Vacation Form "+obj1.getVacationForm());
        Employee.Secretary obj2=new Employee.Secretary();
        System.out.println("LabTask7.LabTask9.Employee type: Secretary");
        System.out.println("Salary $"+obj2.getSalary());
        System.out.println("Vacation Days "+obj2.getVacationDays());
        System.out.println("Working Hours "+obj2.getHours());
        System.out.println("Vacation Form "+obj2.getVacationForm());
        Employee.LegalSecretary obj3=new Employee.LegalSecretary();
        System.out.println("LabTask7.LabTask9.Employee type: Legal Secretary");
        System.out.println("Salary $"+obj3.getSalary());
        System.out.println("Vacation Days "+obj3.getVacationDays());
        System.out.println("Working Hours "+obj3.getHours());
        System.out.println("Vacation Form "+obj3.getVacationForm());
        Employee.Marketer obj4=new Employee.Marketer();
        System.out.println("LabTask7.LabTask9.Employee type: Marketer");
        System.out.println("Salary $"+obj4.getSalary());
        System.out.println("Vacation Days "+obj4.getVacationDays());
        System.out.println("Working Hours "+obj4.getHours());
        System.out.println("Vacation Form "+obj4.getVacationForm());
        Employee.Janitor obj5=new Employee.Janitor();
        System.out.println("LabTask7.LabTask9.Employee type: Janitor");
        System.out.println("Salary $"+obj5.getSalary());
        System.out.println("Vacation Days "+obj5.getVacationDays());
        System.out.println("Working Hours "+obj5.getHours());
        System.out.println("Vacation Form "+obj5.getVacationForm());
    }
}
