import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class WordCount {
    public static void main(String[] args) throws FileNotFoundException {
        String line;
        int count = 0;
        Scanner inFile = new Scanner(new FileReader("employee.txt"));
        while(inFile.hasNextLine()){
            line=inFile.nextLine();
            String word[]=line.split(" ");
            count=count+word.length;
        }
        System.out.println("Number of words present in given file: "+count);
        inFile.close();
    }
}
