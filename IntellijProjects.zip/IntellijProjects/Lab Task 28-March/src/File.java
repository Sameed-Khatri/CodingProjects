import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class File {

//
//    public File(String s) {
//    }

    public static void main(String[] args) {
//        File f=new File("employee.txt");
        String FirstName;
        String LastName;
        double HoursWorked;
        double PayRate;
        double Wages;
        try{
//        FileWriter fw=new FileWriter("employee.txt");
//        fw.write(56);
            Scanner inFile=new Scanner(new FileReader("employee.txt"));
            FirstName= inFile.next();
            LastName=inFile.next();
            HoursWorked= inFile.nextDouble();
            PayRate=inFile.nextDouble();
            Wages=HoursWorked*PayRate;
            PrintWriter outFile=new PrintWriter("employee.txt");
            outFile.println("The pay check is: $"+Wages);
            inFile.close();
            outFile.close();
        }
        catch (IOException e){
            e.printStackTrace();
        }

    }
}
