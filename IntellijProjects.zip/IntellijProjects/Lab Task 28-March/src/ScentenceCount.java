import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class ScentenceCount {
    public static void main(String[] args) {
        try{
            Scanner sc=new Scanner(new FileReader("employee.txt"));
            String sentence=sc.nextLine();
            while(sentence.split(" ").length<2){
                sentence=sc.nextLine();
            }
            PrintWriter pw=new PrintWriter("temp.txt");
            pw.write("sentence count: ");
            pw.write(sentence.split(" ").length);
            System.out.println("Number of sentences present in given file: "+sentence.split(" ").length);
            sc.close();
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }
}
class CharacterCount{
    public static void main(String[] args) {
        try{
            Scanner sc=new Scanner(new FileReader("employee.txt"));
            String s=sc.next();
            int count=0;
            for(int i=0;i<s.length();i++){
                char c=s.charAt(i);
                count++;
            }
            PrintWriter pw =new PrintWriter("temp.txt");
            pw.write("character count");
            pw.write(count);
            System.out.println("Number of characters present in given file: "+count);
            sc.close();}
        catch (IOException e){
            e.printStackTrace();
        }
    }
}
class WhiteSpaceCount{
    public static void main(String[] args) {
        int count=0;
        try{
            Scanner sc=new Scanner(new FileReader("employee.txt"));
            String temp=sc.next();
            for(int i=0;i<temp.length();i++){
                char c=temp.charAt(i);
                if(c==' ')
                    count++;
            }
            PrintWriter pw=new PrintWriter("temp.txt");
            pw.write(count);
            System.out.println("Number of white spaces present in given file: "+count);
            sc.close();
        }

        catch (IOException e){
            e.printStackTrace();
        }
    }
}
