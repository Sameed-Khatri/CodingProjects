public class Bird {
    public String Name;
    public String Color;
    public  Bird(String n, String c){
        Name=n;
        Color=c;
    }

    public Bird() {

    }

    public String toString(){
        String s="Bird : "+Name+","+" Colour : "+Color;
        return s;
    }
    static class Duck extends Bird{
        Fly duckFly;
        public Duck(String n, String c, Fly f ) {
            super(n, c);
            duckFly=f;
        }

        public Duck() {
            super();
        }
        public void setFly(Fly a){
            duckFly=a;
        }
        public Fly getFly(){
            return duckFly;
        }
        public String toString(){
            String s=" "+duckFly;
            return super.toString()+" "+s;

        }

    }
}
