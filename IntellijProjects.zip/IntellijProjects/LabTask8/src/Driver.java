public class Driver {
    public static void main(String[] args) {
        Fly obj1=new Fly(false,18);
        Bird.Duck obj2=new Bird.Duck("duck","white",obj1);
        System.out.println(obj2);
    }
}
