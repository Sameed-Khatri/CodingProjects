public class Radiator {
    int RadiatorID;
    boolean isON=false;
    public Radiator(int ID){
        RadiatorIDSetter(ID);
        int temp=RadiatorIDGetter();
        RadiatorID=temp+15;
    }
    public void RadiatorIDSetter(int id){
        RadiatorID=id%100;
    }
    public int RadiatorIDGetter(){
        return RadiatorID;
    }
    public void heats(Room room){
        int slot1= room.radiatorIdList[0];
        int slot2= room.radiatorIdList[1];
        String s="";
        if(isON){
            s="turned on";
        }
        else {
            s="turned off";
        }
        if(slot1==RadiatorID || slot2==RadiatorID)
            System.out.println("Radiator "+RadiatorID+" is in room "+room.roomName+" with a seating capacity of "+room.seatingCapacity+" and the radiator is "+s);
        else
            System.out.println("Radiator "+RadiatorID+" is not in room "+room.roomName);
    }
}
