public class Room {
    String roomName;
    int seatingCapacity;
    int numRadiators=0;
    int[]radiatorIdList=new int[2];
    public Room(String rN){
        roomName=rN;
        seatingCapacity=12;
    }
    public String isHeatedBy(Radiator radiator){
        if(numRadiators<=2){
            for(int i=0;i<radiatorIdList.length;i++){
                if(radiatorIdList[i]!=0){
                    int temp=radiatorIdList[i];
                    if(temp==radiator.RadiatorIDGetter()){
                        return "Radiator already added to room.";
                    }
                }
                else if(radiatorIdList[i]==0){
                    int id=radiator.RadiatorIDGetter();
                    radiatorIdList[i]=id;
                    radiator.isON=true;
                    numRadiators++;
                    return "Radiator successfully added to room.";
                }
            }
        }
        return "Cannot add radiator. Room has a maximum number of radiators.";
    }
}
