public class Driver {
    public static void main(String[] args) {
        Room room=new Room("A1");
        Radiator rd1=new Radiator(225084);
        Radiator rd2=new Radiator(225078);
        Radiator rd3=new Radiator(225058);
        System.out.println(room.isHeatedBy(rd1));
        System.out.println(room.isHeatedBy(rd2));
        System.out.println(room.isHeatedBy(rd3));
        System.out.println(room.isHeatedBy(rd3));
        System.out.println(room.isHeatedBy(rd1));
        rd1.heats(room);
        rd2.heats(room);
        rd3.heats(room);
        rd1.heats(room);
    }
}
