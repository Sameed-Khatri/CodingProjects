import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;

public class EvolutionAlgorithm {
    ArrayList<Chromosome>population=new ArrayList<>();
    ArrayList<Chromosome>totalPopulationHistory=new ArrayList<>();
    double mutation_rate;
    double truncationPercent;
    public  EvolutionAlgorithm(String[]pop, double mutation_rate, double truncation_percent){
        this.mutation_rate=mutation_rate;
        this.truncationPercent=truncation_percent;
        for(int i=0;i<5;i++){
            for(int j=0;j<1;j++){
                String s=pop[i];
                String[] sArr = s.split(",");
                int x = Integer.parseInt(sArr[0]);
                int y = Integer.parseInt(sArr[1]);
                int fv=fitnessValue(x,y);
                Chromosome c=new Chromosome(x,y,fv);
                population.add(c);
            }
        }
    }
    public void addInTotalPop(){
        for(int i=0;i<5;i++){
            Chromosome c=population.get(i);
            totalPopulationHistory.add(c);
        }
    }
    public int fitnessValue(int x, int y){
        int x2=x*x;
        int y2=y*y;
        int sum=x2+y2;
        return sum;
    }
    public ArrayList<Chromosome> crossover_mutation(Chromosome c1, Chromosome c2){
        ArrayList<Chromosome>arr=new ArrayList<>();
        int fit1=fitnessValue(c1.x,c2.y);
        int fit2=fitnessValue(c2.x,c1.y);
        Chromosome crossover1=new Chromosome(c1.x,c2.y,fit1);
        Chromosome crossover2=new Chromosome(c2.x,c1.y,fit2);
        if(Math.random()<=mutation_rate){
            arr=mutation(crossover1,crossover2);
        }
        else{
            arr.add(crossover1);
            arr.add(crossover2);
        }
        return arr;
    }
    public ArrayList<Chromosome> mutation(Chromosome c1, Chromosome c2){
        ArrayList<Chromosome>arr=new ArrayList<>();
        int temp1=c1.x;
        int temp2=c1.y;
        c1.x=temp2;
        c1.y=temp1;
        int temp3=c2.x;
        int temp4=c2.y;
        c2.x=temp4;
        c2.y=temp3;
        int fit1=fitnessValue(c1.x,c1.y);
        c1.fitnessValue=fit1;
        int fit2=fitnessValue(c2.x,c2.y);
        c2.fitnessValue=fit2;
        arr.add(c1);
        arr.add(c2);
        return arr;
    }
    public Chromosome BinaryTournament(){
        Random random=new Random();
        ArrayList<Chromosome>parent_arr=new ArrayList<>();
        ArrayList<Chromosome>offspring=new ArrayList<>();
        for(int i=0;i<4;i++){
            Chromosome temp1=population.get(random.nextInt(population.size()-1));
            try {
                Thread.sleep(10);
                }
            catch (InterruptedException e) {
                    e.printStackTrace();
                }
            Chromosome temp2=population.get(random.nextInt(population.size()-1));
            Chromosome parent;
            if(temp1.fitnessValue>temp2.fitnessValue)
                parent=temp1;
            else
                parent=temp2;
            parent_arr.add(parent);
            if(parent_arr.size()==2){
                Chromosome parent1=parent_arr.get(0);
                Chromosome parent2=parent_arr.get(1);
                ArrayList<Chromosome>a=crossover_mutation(parent1,parent2);
                for(int j=0;j<a.size();j++){
                    offspring.add(a.get(j));
                }
                parent_arr.clear();
            }
        }
        population.addAll(offspring);
        SurvivorSelection(truncationPercent);
        return population.get(0);
    }
    public ArrayList<Chromosome> SortPopulation(ArrayList<Chromosome>sorted){
        Collections.sort(sorted, new Comparator<Chromosome>() {
            @Override
            public int compare(Chromosome o1, Chromosome o2) {
                return o2.fitnessValue-o1.fitnessValue;
            }
        });
        return sorted;
    }
    public void SurvivorSelection(double selectionPercent){
        ArrayList<Chromosome>nextPopulation= (ArrayList<Chromosome>) population.clone();
        population.clear();
        ArrayList<Chromosome>sortedPopulation=SortPopulation(nextPopulation);
        int numSelect=(int)(Math.round(selectionPercent*5));
        for(int i=0;i<numSelect;i++){
            Chromosome c=sortedPopulation.get(i);
            for(int j=0;j<5/numSelect;j++){
                population.add(c);
            }
        }
        if(population.size()==4)
            population.add(0,sortedPopulation.get(0));
        else if(population.size()==6)
            population.remove(population.size()-1);
        totalPopulationHistory.addAll(population);
    }
    public void printPopulation(){
        for(int i=0;i< population.size();i++){
            Chromosome c=population.get(i);
            System.out.println(c.x+" "+c.y+" "+c.fitnessValue);
        }
    }
}
