public class Chromosome {
    int x;
    int y;
    int fitnessValue;
    public Chromosome(int x, int y, int fv){
        this.x=x;
        this.y=y;
        fitnessValue=fv;
    }
}
