import java.util.ArrayList;
/* FOR DANIAL BHAI:  I have considered that there will be 20 iterations that will generate 20 populations each of size 5 and the...
....fittest chromosome of each population will be printed in the output (According to Ms.Sumaira this is the correct way).
I also asked her about binary conversion and she said its not necessary
Also no truncation percentile is given so i have taken it as 100%(1.0 truncation_percent) which can be changed if needed.
The code might converge at a local maxima in some test runs but most of the time it converges to 50 which is in this case
the global maxima */
public class Driver {
    public static void main(String[] args) {
        String[]startingPopulation=new String[5];
        startingPopulation[0]="1,2";
        startingPopulation[1]="-2,3";
        startingPopulation[2]="4,-1";
        startingPopulation[3]="5,2";
        startingPopulation[4]="-3,3";
        double mutation_rate=0.5;
        double truncation_percent=1.0;
        EvolutionAlgorithm obj=new EvolutionAlgorithm(startingPopulation,mutation_rate,truncation_percent);
        ArrayList<Chromosome>a=obj.SortPopulation(obj.population);
        ArrayList<Chromosome>fittest_iterations=new ArrayList<>();
        Chromosome c=a.get(0);
        fittest_iterations.add(c);
        obj.addInTotalPop();
        for(int i=0;i<19;i++){
            fittest_iterations.add(obj.BinaryTournament());
        }
        String header1="Iteration #";
        String header2="Fitness Value";
        System.out.println("Twenty Iterations Table");
        System.out.println();
        System.out.printf("%-15s %-8s\n", header1, header2);
        for(int i=0;i< fittest_iterations.size();i++){
            Chromosome c2=fittest_iterations.get(i);
            System.out.printf("%-15s %-8s\n", i+1, c2.fitnessValue);
        }
    }
}
