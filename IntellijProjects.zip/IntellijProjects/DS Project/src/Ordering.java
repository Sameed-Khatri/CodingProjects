import com.itextpdf.kernel.color.Color;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.border.Border;
import com.itextpdf.layout.border.DashedBorder;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Scanner;
public class Ordering {
    public static void main(String[] args) throws FileNotFoundException {
        int id = 1;
        CustomerHashTable hashTable = new CustomerHashTable();
        hashTable.addCustomer(new Customer(id, "John Smith", "123 Main St", "555-555-1212"));
        id++;
        hashTable.addCustomer(new Customer(id, "Jane Doe", "456 Market St", "555-555-1213"));
        id++;
        hashTable.addCustomer(new Customer(id, "Bob Johnson", "789 Market St", "555-555-1214"));
        id++;
        wordList word = new wordList();
        word.inventory();
        String w="";
        ShoppingCart itemAdd=new ShoppingCart();
        Scanner sc=new Scanner(System.in);
        System.out.println("Search for more or type (Done) to head towards checkout :");
        while(sc.hasNext()){
            System.out.println();
            w=sc.next();
            if(w.equals("Done")){
                break;
            }
            else{
                word.search(w);
                System.out.println();
                System.out.println("Add to cart using item serial number or type (Back) to go back to previous page :");
                while (sc.hasNext()){
                    String s= sc.next();
                    if(s.equals("Back")){
                        System.out.println();
                        System.out.println("Search for more or type (Done) to head towards checkout :");
                        break;
                    }
                    else{
                        int serialNo = Integer.parseInt(s);
                        wordNode customerInterest= word.cartSearch(w);
                        productNode temp=customerInterest.productData.head;
                        while(temp!=null){
                            if(temp.id==serialNo){
                                itemAdd.addCart(temp);
                                break;
                            }
                            else
                                temp=temp.next;
                        }
                    }
                }
            }

        }
        System.out.println("Do you want to checkout :");
        if(sc.next().equals("Yes")){
            Customer newCust;
            System.out.println("Have u ordered with us before,if so then please enter yes else type register");
            if (sc.next().equals("Yes")) {
                System.out.println("Provide your id:");
                newCust = hashTable.getCustomer(Integer.parseInt(sc.next()));
            } else {
                System.out.println("Enter name,address,telephone");
                String name=sc.next();
                String address= sc.next();
                String telephone= sc.next();
                newCust = new Customer(id, name, address, telephone);
                hashTable.addCustomer(newCust);
                id++;
                System.out.println("Your id is :" + newCust.getId());
            }
            System.out.println("Your order details:");
            itemAdd.total();
            System.out.println(newCust);
            System.out.println("Place order?");
            if (sc.next().equals("Yes")) {
                System.out.println("Order Placed");
                itemAdd.total();
            }
            sc.close();
        }
//        String path="invoice.pdf";
////        PdfWriter pdfWriter=new PdfWriter(path);
//        PdfDocument pdfDocument=new PdfDocument(new PdfWriter(new FileOutputStream(path)));
//        pdfDocument.setDefaultPageSize(PageSize.A4);
//        Document document=new Document(pdfDocument);
//        float twoCol=285f;
//        float twoCol150=twoCol+150f;
//        float twoColumnWidth[]={twoCol150,twoCol};
//        float threeCol=190f;
//        float fullWidth[]={threeCol*3};
//        Paragraph oneSp=new Paragraph("\n");
//        Table table=new Table(twoColumnWidth);
//        table.addCell(new Cell().add("Invoice").setFontSize(20f).setBorder(Border.NO_BORDER).setBold());
//        Table nestedTable=new Table(new float[]{twoCol/2,twoCol/2});
//        nestedTable.addCell(new Cell().add("Invoice no :").setBorder(Border.NO_BORDER).setBold());
//        nestedTable.addCell(new Cell().add("12345").setBorder(Border.NO_BORDER));
//        nestedTable.addCell(new Cell().add("Invoice date :").setBorder(Border.NO_BORDER).setBold());
//        nestedTable.addCell(new Cell().add("22/12/22").setBorder(Border.NO_BORDER));
//        table.addCell(new Cell().add(nestedTable).setBorder(Border.NO_BORDER).setBold());
//        Border gb=new DashedBorder(Color.BLUE,2f);
//        Table divider=new Table(fullWidth);
//        divider.setBorder(gb);
//        document.add(table);
//        document.add(oneSp);
//        document.add(divider);

    }
}