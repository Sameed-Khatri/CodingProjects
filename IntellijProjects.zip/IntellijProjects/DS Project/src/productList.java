import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

class productNode {
    String product;
    productNode next;
    String name; int price; int id; String availaibility; String color; String category; String descirption; double size;

    productNode(String name, int id ,int price, String availaibility, String color, String category, double size) {
        this.name = name;
        this.id = id;
        this.price = price;
        this.availaibility = availaibility;
        this.color = color;
        this.category = category;
        this.size = size;
    }
}

public class productList {
    productNode head;
    ArrayList<String> listOfWords = new ArrayList<>();

    public void insert(String word) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("C:\\Users\\hp\\Desktop\\adidas_usa_copy(draft).csv"));
        sc.useDelimiter(",");   //sets the delimiter pattern
        while (sc.hasNextLine()) {
            String line = sc.nextLine();
            if (isWordPresent(line, word)) {
                listOfWords.add(line);
            }
        }
        int i = 0;
        while (i < listOfWords.size()) {
            String line = listOfWords.get(i);
            String[] data = line.split(",");
            productNode node = new productNode(data[0], Integer.parseInt(data[1]), Integer.parseInt(data[2]), data[3], data[4], data[5], Double.parseDouble(data[6]));
            if (head == null) {
                head = node;
            } else {
                productNode temp = head;
                while (temp.next != null) {
                    temp = temp.next;
                }
                temp.next = node;
            }
            i++;
        }
        listOfWords.clear();
        sc.close();
    }

    public boolean isWordPresent(String line, String word) {
        String[] words = line.split(",");
        for (int i = 0 ; i < words.length;i++) {
            if (words[i].equals(word)) {
                return true;
            }
        }
        return false;
    }

    public String toString() {
        String str = "";
        productNode tempNode = head;
        while (tempNode != null) {
            str += tempNode.name+ " " + tempNode.id + " " + tempNode.price + " " + tempNode.availaibility + " " + tempNode.color + " " + tempNode.category + " " + tempNode.size + "\n";
            tempNode = tempNode.next;
        }
        return str;
    }
}
