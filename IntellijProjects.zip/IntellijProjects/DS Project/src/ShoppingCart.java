import java.util.ArrayList;

public class ShoppingCart {
    ArrayList<productNode> cart=new ArrayList<>();
    public void addCart(productNode n){
        cart.add(n);
    }
    public void total(){
        int totalAmount=0;
        for(int i=0;i< cart.size();i++){
            System.out.println("Product :"+cart.get(i).name+"  Price:"+cart.get(i).price);
            totalAmount=totalAmount+cart.get(i).price;
        }
        System.out.println("Your total amount is $ : "+totalAmount);
    }
}
