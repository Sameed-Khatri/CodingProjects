import java.io.FileNotFoundException;

class wordNode {
    String word;
    wordNode next;
    wordNode prev;
    productList productData = new productList();

    wordNode(String word) {
        this.word = word;
    }
}

public class wordList {
    wordNode head;

    public void inventory() throws FileNotFoundException {
        insert("Clothing");
        insert("Shoes");
        insert("Accessories");
        insert("Black");
        insert("Grey");
        insert("White");
        insert("Blue");
    }

    public void insert(String word) throws FileNotFoundException {
        wordNode newNode = new wordNode(word);
        if (head == null) {
            newNode.next = null;
            newNode.prev = null;
            newNode.productData.insert(word);
            head = newNode;
        } else {
            wordNode temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
            newNode.prev = temp;
            newNode.next = null;
            newNode.productData.insert(word);
        }
    }

    public boolean hasWord(String word) {
        wordNode temp = head;
        while (temp != null) {
            if (temp.word.equals(word)) {
                return true;
            }
            temp = temp.next;
        }
        return false;
    }

    public boolean hasWordInLL(String word) {
        System.out.println("5");
        boolean ans = false;
        wordNode temp = head;
        while (temp != null){
            productNode tempLL = temp.productData.head;
            while (tempLL != null) {
                if (tempLL.name.contains(word)) {
                    ans = true;
                    break;
                }
                if (!ans) {
                    tempLL = tempLL.next;
                }
            }
            if (!ans) {
                temp = temp.next;
            }
        }
        System.out.println(ans);
        return ans;
    }

    public void search(String word) {
        if (hasWord(word)) {
            System.out.println("0");
            wordNode temp = head;
            while (!temp.word.equals(word)) {
                temp = temp.next;
            }
            System.out.print("Result of \"" + word + "\" search is: ");
            System.out.print(temp.productData.toString());
            System.out.println();
        } else if (hasWordInLL(word)) {
            System.out.println("1");
            wordNode temp = head;
            while (temp != null) {
                System.out.println("2");
                productNode tempLL = temp.productData.head;
                while (!tempLL.name.contains(word)) {
                    System.out.println("3");
                    tempLL = tempLL.next;
                }
                System.out.println("4");
                System.out.print("Result of \"" + word + "\" search is: ");
                System.out.print(tempLL.toString());
                System.out.println();
                temp = temp.next;
            }
        } else {
            System.out.println("No urls found for the word \"" + word + "\" search");
        }
    }

    public void delete(String word) {
        if (head == null) {
            System.out.print("Empty List");
        } else if (head.word.equals(word)) {
            head = head.next;
        } else {
            wordNode temp = head.next;
            wordNode p = head;
            while (temp != null) {
                if (temp.word.equals(word)) {
                    p.next = temp.next;
                    break;
                }
                p = temp;
                temp = temp.next;
            }
        }
    }
    public wordNode cartSearch(String data){
        wordNode temp=head;
        while(temp!=null){
            if(temp.word.contains(data)){
                return temp;
            }
            else
                temp=temp.next;
        }
        wordNode temp2=head;
        while(temp2!=null){
            productNode templl=temp2.productData.head;
            while(templl!=null){
                if(templl.name.contains(data)){
                    return templl;
                }
            }
        }
        return null;
    }

    public String toString() {
        String str = "";
        wordNode tempNode = head;
        while (tempNode != null) {
            str += "Word \"" + tempNode.word + "\" has these urls: " + tempNode.productData.toString() + "\n";
            tempNode = tempNode.next;
        }
        return str;
    }
}

