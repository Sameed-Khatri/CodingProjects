import javax.swing.*;

public class Invoice {
    private JTable table1;
}
