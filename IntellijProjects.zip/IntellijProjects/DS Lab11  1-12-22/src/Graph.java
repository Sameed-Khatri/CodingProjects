import java.util.*;

public class Graph {
    ArrayList<vertex> adjList;
    int count;
    vertex[]prev;
    int[]visit;
    Graph(){
        adjList=new ArrayList<>();
        count=0;
    }
    public void AddVertex(String n){
        vertex v=new vertex(n);
        adjList.add(count,v);
        count++;
    }
    public void AddEdge(String n1,String n2) {
        int i=getIndex(n1);
        int j=getIndex(n2);
        adjList.get(i).friendList.add(adjList.get(j));
        adjList.get(j).friendList.add(adjList.get(i));
    }
    public int getIndex(String s){
        for(int i=0;i<count;i++){
            if(adjList.get(i).name.equals(s))
                return i;
        }
        return -1;
    }
    public vertex FindVertex(String n){
        int i=getIndex(n);
        return adjList.get(i);
    }
    public String toString(){
        String s1="";
        for(int i=0;i<adjList.size();i++){
            String s2="";
            LinkedList<vertex>l=adjList.get(i).friendList;
            for(int j=0;j<l.size();j++){
                s2=s2+" ("+l.get(j).name+")";
            }
            s1=s1+"Person :"+adjList.get(i).name+"\n"+"Friends :"+s2+"\n";
        }
        return s1;
    }
    public void BFS(){
        visit=new int[adjList.size()];
        prev=new vertex[adjList.size()];
        Queue<vertex> Q=new ArrayDeque<>();
        vertex v = adjList.get(0);
        int index=getIndex(v.name);
        visit[index]=1;
        Q.add(v);
        prev[index]=null;
        System.out.println(adjList.get(0).name);
        while (!Q.isEmpty()){
            vertex top=Q.remove();
            LinkedList<vertex> l=top.friendList;
            for(int i=0;i< l.size();i++){
                vertex lv=l.get(i);
                int lvIndex=getIndex(lv.name);
                if(visit[lvIndex]==1){}
                else{
                    Q.add(lv);
                    visit[lvIndex]=1;
                    prev[lvIndex]=top;
                    System.out.println(lv.name);
                }
            }
        }
        System.out.println("Printing visit array :");
        for(int i=0;i< visit.length;i++){
            System.out.println(visit[i]);
        }
    }
    public void shortestPath(String s1, String s2){
        System.out.println("BFS :");
        BFS();
        ArrayList<vertex> shortestPath=new ArrayList<>();
        int i=getIndex(s1);
        int j=getIndex(s2);
        if(visit[i]==0||visit[j]==0){
            System.out.println("No path available");
        }
        else{
            vertex findS1=FindVertex(s1);
            vertex findS2=FindVertex(s2);
            String s=s2;
            shortestPath.add(findS1);
            int r=0;
            while(r<prev.length){
                int index=getIndex(s);
                vertex v=prev[index];
                if(v.name.equals(s1)){
                    break;
                }
                else{
                    shortestPath.add(v);
                    s=v.name;
                    r++;
                }
            }
            shortestPath.add(findS2);
        }
        System.out.println("Shortest path from "+s1+" to "+s2+" :");
        for(int k=0;k< shortestPath.size()-1;k++){
            System.out.print(shortestPath.get(k).name+"----");
        }
        System.out.print(shortestPath.get(shortestPath.size()-1).name);
    }

    public static void main(String[] args) {
        Graph obj=new Graph();
        obj.AddVertex("A");
        obj.AddVertex("B");
        obj.AddVertex("C");
        obj.AddVertex("D");
        obj.AddVertex("E");
        obj.AddEdge("A","B");
        obj.AddEdge("A","C");
        obj.AddEdge("B","D");
        obj.AddEdge("D","E");
        obj.AddEdge("C","E");
        obj.shortestPath("A","E");
    }
}
