import java.util.LinkedList;

class vertex{
    String name;
    LinkedList<vertex>friendList=new LinkedList<>();
    vertex(String d){
        name=d;
    }
}