public class ListPriorityQueue<T extends Comparable<T>> implements Queues<T>{
    nodePriority<T> Front;
    nodePriority<T> Rear;
    int length=0;
    nodePriority<T>temp2=null;
    public void Enqueue(T obj){
        int i=0;
        nodePriority<T> n=new nodePriority<T>(obj);
        if(Front==null){
            Rear=n;
            Front=n;
        }
        else{
//            try{
            nodePriority<T> temp=Front;
            while(i<length){
                if((temp.data.compareTo(n.data)>=1) && (temp.next==null)){
                    temp.next=n;
                    temp=Front;
                    temp2=n;
                    Rear=n;
                }
                else if((temp.data.compareTo(n.data)>=1) && (temp2.data.compareTo(n.data)<=-1)){
                    temp.next=n;
                    temp=Front;
                    n.next=temp2;
                    temp2=temp.next;
                }

                else if(temp.data.compareTo(n.data)<=-1){
                    n.next=temp;
                    Front=n;
                    temp2=temp;
                    temp=Front;
                }
                else{
                    temp2=temp.next.next;
                    temp=temp.next;
                    if(temp2.data.compareTo(n.data)>=1){
                        temp2.next=n;
                        Rear=n;
                        temp=Front;
                        temp2=temp.next;
                    }
                }
                i++;
            }
//        } catch (NullPointerException e) {
//                e.getMessage();
//            }
        }
        length++;
    }
    public T Dequeue(){
        if(isEmpty())
            System.out.println("underflow");
        else{
            nodePriority<T> temp=Front;
            T value;
            int i=0;
            while(i<length){
                if(temp.next==Rear){
                    value=Rear.data;
                    Rear=temp;
                    return value;
                }
                else if(Front==Rear){
                    value=Rear.data;
                    Front=null;
                    Rear=null;
                    return value;
                }
                else
                    temp=temp.next;
                i++;
            }
//            temp=Front.data;
//            Front=Front.next;
//            return temp;
        }
        length--;
        return null;
    }
    public boolean isEmpty(){
        if(Front==null)
            return true;
        else
            return false;
    }

    @Override
    public boolean isFull() {
        return false;
    }

    public String toString() {
        String str="";
        if(isEmpty()){
            return null;
        }
        else{
            nodePriority<T> temp=Front;
            while(temp!=null){
                str=str+temp.data+" ";
                temp=temp.next;
            }
        }
        return str;
    }
}


