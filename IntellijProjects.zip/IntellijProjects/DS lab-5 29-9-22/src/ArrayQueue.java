import java.util.Arrays;

public class ArrayQueue<T> implements Queues <T>{
    T[] Q; int F; int R;
    ArrayQueue(){
        Q=(T[])new Object[10];
        F=0; R=0;
    }
    ArrayQueue(int size){
        Q=(T[])new Object[size];
        F=0; R=0;

    }
    public void Enqueue(T obj){
        if(isFull())
            System.out.println("overflow");
        else{
            R=(R+1)%Q.length;
            Q[R]=obj;
        }
    }
    public T Dequeue(){
        if(isEmpty())
            System.out.println("underflow");
        else{
            F=(F+1)%Q.length;
            return Q[F];}
        return null;
    }
    public boolean isEmpty(){
        if(R==F)
            return true;
        else
            return false;
    }
    public boolean isFull(){
        if((R+1)% Q.length==F)
            return true;
        else
            return false;
    }

    @Override
    public String toString() {
        String str="";
        if(isEmpty()){
            return null;
        }
        else{
            for(int i=0;i<Q.length;i++){
                str=str+Q[i]+" ";
            }
        }
        return str;
    }
}
