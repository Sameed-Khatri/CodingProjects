public class nodePriority<T> {
    T data;
    nodePriority<T> next;
    public nodePriority(T d){
        data=d;
    }
}
