public class ArrayPriorityQueue<T extends Comparable<T>> implements Queues<T> {
    T[] Q;
    int F;
    int i;
    ArrayPriorityQueue(){
        Q=(T[])new Comparable[10];
        F=-1;
    }
    ArrayPriorityQueue(int size){
        Q=(T[])new Comparable[size];
        F=-1;
    }
    public void Enqueue(T obj){
        if(isFull())
            System.out.println("overflow");
        else{
            for(i=F;(i>=0 && Q[i].compareTo(obj)<=-1);i--){
                Q[i+1]=Q[i];
            }
            Q[i+1]=obj;
            F++;
        }

    }
    public T Dequeue(){
        if(isEmpty())
            System.out.println("underflow");
        else {
            F--;
            return (Q[F + 1]);
        }
        return null;
    }
    public boolean isEmpty(){
        if(F==-1)
            return true;
        else
            return false;
    }
    public boolean isFull(){
        if(F==Q.length-1)
            return true;
        else
            return false;
    }
    public String toString() {
        String str="";
        for(int i=0;i<Q.length;i++){
            str=str+Q[i]+" ";
        }
        return str;
    }
}
