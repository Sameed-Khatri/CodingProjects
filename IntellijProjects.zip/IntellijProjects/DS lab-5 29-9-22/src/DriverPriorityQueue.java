public class DriverPriorityQueue {
    public static void main(String[] args) {
        System.out.println("Array Priority Queue : ");
        ArrayPriorityQueue<Integer> Q1=new ArrayPriorityQueue<Integer>(10);
        Q1.Enqueue(21);
        Q1.Enqueue(54);
        System.out.println("Array data : "+Q1);
        System.out.println(Q1.Dequeue()+" Dequeued");
        System.out.println(Q1.Dequeue()+" Dequeued");
        System.out.println(Q1.Dequeue());
        System.out.println();
        System.out.println("List Priority Queue : ");
        ListPriorityQueue<Integer> Q2=new ListPriorityQueue<Integer>();
        Q2.Enqueue(44);
        Q2.Enqueue(34);
//        Q2.Enqueue(40);
//        Q2.Enqueue(30);
        System.out.println("List data : "+Q2);
        System.out.println(Q2.Dequeue()+" Dequeued");
        System.out.println(Q2.Dequeue()+" Dequeued");
//        System.out.println(Q2.Dequeue()+" Dequeued");
//        System.out.println(Q2.Dequeue()+" Dequeued");
        System.out.println(Q2.Dequeue());
    }
}
