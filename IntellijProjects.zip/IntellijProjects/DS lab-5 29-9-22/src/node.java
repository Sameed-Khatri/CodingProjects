class node<T>{
    T data;
    node<T> next;
    public node(T d){
        data=d;
    }
}

