public class DriverQueue {
    public static void main(String[] args) {
        System.out.println("Array Queue : ");
        ArrayQueue<String> Q1=new ArrayQueue<String>(10);
        Q1.Enqueue("job1");
        Q1.Enqueue("job2");
        System.out.println("Array data : "+Q1);
        System.out.println(Q1.Dequeue()+" Dequeued");
        System.out.println(Q1.Dequeue()+" Dequeued");
        System.out.println(Q1.Dequeue());
        System.out.println();
        System.out.println("Linked List Queue : ");
        ListQueue<String> Q2=new ListQueue<String>();
        Q2.Enqueue("job1");
        Q2.Enqueue("job2");
        System.out.println("List data : "+Q2);
        System.out.println(Q2.Dequeue()+" Dequeued");
        System.out.println(Q2.Dequeue()+" Dequeued");
        System.out.println(Q2.Dequeue());
    }
}
