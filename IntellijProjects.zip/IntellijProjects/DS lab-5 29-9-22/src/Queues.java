public interface Queues<T> {
    public boolean isEmpty();
    public boolean isFull();
    public void Enqueue(T obj);
    public T Dequeue();
}
