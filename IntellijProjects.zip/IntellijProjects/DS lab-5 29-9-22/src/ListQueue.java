public class ListQueue <T> implements Queues<T>{
    node<T> Front;
    node<T> Rear;
    T temp;
    public void Enqueue(T obj){
        node<T> n=new node(obj);
        if(Front==null){
            Front=n;
            Rear=n;
        }
        else{
            Rear.next=n;
            Rear=n;
        }
    }
    public T Dequeue(){
        if(isEmpty())
            System.out.println("underflow");
        else{
            temp=Front.data;
            Front=Front.next;
            return temp;
        }
        return null;
    }
    public boolean isEmpty(){
        if(Front==null)
            return true;
        else
            return false;
    }

    @Override
    public boolean isFull() {
        return false;
    }
    public String toString() {
        String str="";
        if(isEmpty()){
            return null;
        }
        else{
            node<T> temp=Front;
            while(temp!=null){
                str=str+temp.data+" ";
                temp=temp.next;
            }
        }
        return str;
    }
}
