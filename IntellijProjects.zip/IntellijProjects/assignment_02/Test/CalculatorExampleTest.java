    import static org.junit.Assert.*;
import org.junit.Assert;

import org.junit.Test;

    /**
     * Test class for calculator class
     *
     * @author Samreen
     *
     */
    public class CalculatorExampleTest {


        @Test
        public void computeAdditionTest1()
        {
            try
            {
                Assert.assertEquals("computeAddition is producing the wrong result", 9,
                        Calculator.compute(new String[]{"4", "+", "5"}));
            }
            catch (CalculatorException e)
            {
                Assert.fail("Legal expression threw an Exception");
            }
            finally {
                System.out.println();
            }
        }


        @Test
        public void computeQuitTest1()
        {
            try
            {
                Calculator.compute(new String[]{"quit"});
                Assert.fail("String \"quit\" does not generate an Exception");
            }
            catch (QuitException e)
            {
            }
            catch (CalculatorException e)
            {
                Assert.fail("String \"quit\" should have generated a QuitException");
            }
            finally {
                System.out.println();
            }
        }



        @Test
        public void computeSingleIllegalArgTest() {
            try
            {
                Calculator.compute(new String[]{"foo"});
                Assert.fail("String \"foo\" should generate an Exception");
            }
            catch (IllegalInputException e)
            {
                Assert.assertEquals("IllegalInputException generated, but with incorrect message", "Illegal Argument",
                        e.getExceptionType());
            }
            catch (CalculatorException e)
            {
                Assert.fail("String \"foo\" should generate an IllegalInputException");
            }
            finally {
                System.out.println();
            }
        }



        @Test
        public void parseAndComputeAddition()
        {
            Assert.assertFalse("parseAndCompute() should not return true with a valid expression",
                    Calculator.parseAndCompute("4 + 2"));
            System.out.println();
        }


        @Test
        public void constructorTest()
        {

            new Calculator();
            Assert.assertTrue(true);
            System.out.println();
        }
        @Test
        public void parseAndComputeDivisionZeroTest(){
            Calculator.parseAndCompute("4 / 0");
            System.out.println();
        }
        @Test
        public void parseAndComputeNegation(){
            Calculator.parseAndCompute("- 4");
            System.out.println();
        }
        @Test
        public void parseAndComputeMultiplication(){
            Calculator.parseAndCompute("2 * 4");
            System.out.println();
        }
        @Test
        public void parseAndComputeSubtraction(){
            Calculator.parseAndCompute("7 - 4");
            System.out.println();
        }
        @Test
        public void computeDivisionByZeroTest() {
            try
            {
                Calculator.compute(new String[]{"4","/","0"});
            }
            catch (DivideByZeroException e)
            {
                Assert.assertEquals("Tried to divide by zero", e.getMessage());

            } catch (CalculatorException e) {
                e.printStackTrace();
            }
            finally {
                System.out.println();
            }
        }
        @Test
        public void computeIllegalInputTest() {
            try
            {
                Calculator.compute(new String[]{"6","+","y"});
            }
            catch (IllegalInputException e)
            {
                Assert.assertEquals("Illegal input: ","Not an integer", e.getExceptionType());

            } catch (CalculatorException e) {
                e.printStackTrace();
            }
            finally {
                System.out.println();
            }
        }
        @Test
        public void computeIllegalInputOperatorTest() {
            try
            {
                Calculator.compute(new String[]{"6","y","6"});
            }
            catch (IllegalInputException e)
            {
                Assert.assertEquals("Illegal input: ","Illegal operator", e.getExceptionType());

            } catch (CalculatorException e) {
                e.printStackTrace();
            }
            finally {
                System.out.println();
            }
        }
    }


