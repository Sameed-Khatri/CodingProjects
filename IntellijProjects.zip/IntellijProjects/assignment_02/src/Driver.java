import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/**
     *
     * @author CS2334
     * @version 2016-09-22
     * Lab 5
     *
     * Read lines from the user's keyboard.  For each line, attempt to interpret
     * it as a mathematical expression and print out the result (or an error message).
     *
     * Lines are read as long as the user has not requested that the program be quit
     *
     */

    public class Driver {


        public static void main(String[] args) throws IOException {

            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

            while(true)
            {
                String input = br.readLine();

                if(Calculator.parseAndCompute(input))
                {
                    break;
                }
            }

            br.close();
        }
    }


