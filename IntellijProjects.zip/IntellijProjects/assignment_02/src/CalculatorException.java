 /**
     *
     * @author Samreen
     * Assignment 02
     *
     * Base exception class for representing exceptions that can
     * occur within a calculator.
     *
     * This class extends Exception, requiring only that message be given
     * to determine the issue.
     */
    public class CalculatorException extends Exception
    {
        public CalculatorException(String message){
            super(message);
            System.out.println(message);
        }
    }
    class QuitException extends CalculatorException{

        public QuitException(String message) {
            super(message);
//            System.out.println(message);

        }
    }
    class IllegalInputException extends CalculatorException{
        String exceptionType;
        public IllegalInputException(String message, String Type) {
            super(message);
            exceptionType=Type;
//            System.out.println(message);
        }
        public String getExceptionType(){
            return exceptionType;
        }
    }
    class DivideByZeroException extends CalculatorException{

        public DivideByZeroException(String message) {
            super(message);
//            System.out.println(message);

        }
    }



