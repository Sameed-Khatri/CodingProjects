 /**
     *
     * @author Samreeen
     * Assignment 02
     *
     * The Calculator class provides functionality for parsing input strings
     * that contain simple expressions and for computing the result of the expression.
     *
     */

    public class Calculator
    {
        /**
         * This constructor has been added to trick the code coverage measure into
         * doing the right thing
         */
        public Calculator()
        {
            // Constructor does nothing
        }

        /**
         * Compute the result of the expression encoded in a sequence of tokens.
         *
         * Here are the different cases:
         * 0 tokens: IllegalInputException: "Illegal Token Length"
         * 1 token:
         *      "quit" (any casing): QuitException
         *      All other cases: IllegalInputException: "Illegal Argument"
         * 2 tokens:
         *      "-" and any number: return negative of number
         *      "-" and not a number: IllegalInputException: "Illegal Argument"
         *      other string and any string: IllegalInputException: "Illegal Operator"
         * 3 tokens:
         *      number1, "+", number2: return sum of two numbers
         *      number1, "/", zero: DivideByZeroException
         *      number1, "/", not zero: return number1/number2
         *      not a number, anything, anything: IllegalInputException: "Illegal Argument"
         *      number1, anything, not a number: IllegalInputException: "Illegal Argument"
         *      number1, not an operator, number2: IllegalInputException: "Illegal Operator"
         * 4 or more tokens: IllegalInputException: "Illegal Token Length"
         *
         * Note: all numbers are integers
         *
         * @param tokens The array of tokens to evaluate
         * @return int result of evaluating the expression
         * @throws CalculatorException If some form of error has been generated or
         * "quit" has been typed. Throws one of the several child classes of CalculatorException
         * in order to give more information on what the error is.
         */
        public static int compute(String[] tokens) throws CalculatorException
        {
            int output=0;
            switch(tokens.length)
            {
                case 0:
                    throw new IllegalInputException("Illegal input: "," Illegal Token Length");

                case 1:
                    if(tokens[0].equalsIgnoreCase("quit"))
                            throw new QuitException("Quiting");
                    else
                        throw new IllegalInputException("Illegal input: ","Illegal Argument");

                case 2:
                    String t1=tokens[0];
                    String t2=tokens[1];
                    if(!Character.isDigit(t2.charAt(0))){
                        throw new IllegalInputException("Illegal input: ","Illegal Argument");}
                    if(tokens[0].equals("-")){
                        int out=Integer.parseInt(tokens[1]);
                        output=-out;
                        break;
                    }
                     else if(t1!="-"){
                        throw new IllegalInputException("Illegal input: ","Illegal operator");}

                    break;




                case 3:
                    String s1=tokens[1];
                    String s2=tokens[0];
                    String s3=tokens[2];
                    if(!Character.isDigit(s2.charAt(0)))
                        throw new IllegalInputException("Illegal input: ","Not an integer");
                    if(!Character.isDigit(s3.charAt(0)))
                        throw new IllegalInputException("Illegal input: ","Not an integer");
                    else{
                    int num1=Integer.parseInt(tokens[0]);
                    int num2=Integer.parseInt(tokens[2]);
                    if(s1.equals("/")&& num2==0)
                        throw new DivideByZeroException("Tried to divide by zero");
                    else if(s1.equals("+")){
                        output=num1+num2;
                        break;}
                    else if (s1.equals("-")){
                        output= num1-num2;
                        break;}
                    else if (s1.equals("*")){
                        output= num1*num2;
                        break;}
                    else if (s1.equals("/")){
                        output= num1/num2;
                        break;}
                    else
                        throw new IllegalInputException("Illegal input: ","Illegal operator");}

                default:
                    throw new IllegalInputException("Illegal input: ","Illegal Token Length");

            }
            return output;
        }

        /**
         * Parse the input string as an expression and evaluate it.
         *
         * If the input is a legal expression, then the result is printed
         *
         * Otherwise a CalculatorException has occurred.  Print a message based on
         * what exception type it is.
         *
         * Always print out what the input was. Use a finally block for this.
         *
         * Always prints out two lines, following the rules:
         * 1st line:
         * -No Exception: "The result is: " + result
         * -QuitException: "Quitting"
         * -DivideByZeroException: "Tried to divide by zero"
         * -IllegalInputException: "Illegal input: " + illegalinputtype(given to constructor)
         * -CalculatorException: <should never happen> e.getMessage()
         * 2nd line:
         * "Input was: " + input
         *
         * @param input A String possibly containing a mathematical expression
         * @return true if the String is equal to "quit"; false otherwise
         */
        public static boolean parseAndCompute(String input)
        {
            String[] tokens = input.split(" ");
            try
            {
                System.out.println("Result is: "+compute(tokens));
            }
            catch (QuitException e)
            {
                System.out.println(e);
            }
            catch (IllegalInputException e)
            {
                System.out.println( e + e.getExceptionType() );
            }
            catch (CalculatorException e)
            {
                System.out.println(e);

            }
            finally {
                System.out.print("Input was: ");
                for(int i=0;i<tokens.length;i++){
                    System.out.print(tokens[i]+" ");
                }
            }
            if(tokens[0].equalsIgnoreCase("quit"))
                return true;
            return false;
        }
    }


