import org.junit.*;

import static org.junit.Assert.*;

public class LabTest {
    private static final String name = "Unit Testing";
    private static final int day = 1;
    private static final int month = 9;
    private static final int hour = 23;
    private static final int minute = 59;
    private static final String specification = "Java Lectures.pdf";
    private static final double score = 0.93;
    private static final double totalPoints = 0.99;
    private static final double totalWeight = 0.30;
    private static Lab object;
    @BeforeClass
    public static void LabTestSetUp() {
        object=new Lab(name,month,day,hour,minute,specification);
        object.setScore(score);
        object.setTotalWeight(totalWeight);
        object.setTotalPoints(totalPoints);
    }

    @Test
    public void LabTestToString() {
        String s = String.format(
                "%s (date: %02d %02d at %02d:%02d): score = %.2f; totalPoints = %.2f; totalWeight = %.2f; specification on = %s",
                name,month,day,hour,minute,score,totalPoints,totalWeight,specification);
        Assert.assertTrue(s.equals(object.toString()));
    }
}