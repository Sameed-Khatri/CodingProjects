import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class AssignmentListTest {
    public static AssignmentList value;
    public static Lab obj;
    public static Project obj2;
    public static double grade=0.79;
    @BeforeClass
    public static void AssignmentListTestSetup(){
        value=new AssignmentList();
        obj=new Lab("Unit Testing",12,1,23,0,"Java Lectures.pdf");
        obj2=new Project("Unit Testing",12,1,23,0,"Java Lectures.pdf","Assignment.csv");
        obj.setScore(0.93);
        obj.setTotalWeight(0.30);
        obj.setTotalPoints(0.99);
        obj2.setScore(0.93);
        obj2.setTotalWeight(0.30);
        obj2.setTotalPoints(0.99);
    }
    @Test
    public void AssignmentListAddItem() {
        value.addItem(obj);
        value.addItem(obj2);

    }

    @Test
    public void AssignmentListComputeCourseGrade() {
//        double n1=obj.getTotalWeight()*(obj.getScore()/obj.getTotalPoints());
//        double n2=obj2.getTotalWeight()*(obj2.getScore()/obj2.getTotalPoints());
//        double totalWeight= obj.getTotalWeight()+obj2.getTotalWeight();
//        double courseGrade=(n1+n2)/totalWeight;
//        int n=value.itemList.size();
//        double score;
//        double totalWeight;
//        double totalPoints;
//        double numerator=0;
//        double denominator=0;
//        for(int i=0;i<n-1;i++){
//            score=value.itemList.get(i).score;
//            totalWeight=value.itemList.get(i).totalWeight;
//            totalPoints=value.itemList.get(i).totalPoints;
//            numerator=numerator+(totalWeight*(score/totalPoints));
//            denominator=totalWeight+totalWeight;}
//        double courseGrade=numerator/denominator;
        value.addItem(obj);
        value.addItem(obj2);
        Assert.assertEquals(String.format("%.2f",grade),String.format("%.2f",value.computeCourseGrade()));
    }

    @Test
    public void AssignmentListTestToString() {
        String out = "";
        for (int i = 0; i < value.itemList.size(); ++i)
        {
            out += value.itemList.get(i).toString() + "\n";
        }
        Assert.assertTrue(out.equals(value.toString()));
    }
}