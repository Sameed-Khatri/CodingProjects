import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class ProjectTest {
    private static final String name = "Unit Testing";
    private static final int day = 1;
    private static final int month = 9;
    private static final int hour = 23;
    private static final int minute = 59;
    private static final String specification = "Java Lectures.pdf";
    private static final String datafile = "Assignment.csv";
    private static final double score = 0.93;
    private static final double totalPoints = 0.99;
    private static final double totalWeight = 0.30;
    private static Project object;
    @Before
    public void ProjectSetUp() throws Exception {
        object=new Project(name,month,day,hour,minute,specification,datafile);
        object.setScore(score);
        object.setTotalWeight(totalWeight);
        object.setTotalPoints(totalPoints);
    }

    @Test
    public void ProjectTestToString() {
        String s = String.format(
                "%s (date: %02d %02d at %02d:%02d): score = %.2f; totalPoints = %.2f; totalWeight = %.2f; specification on = %s; datafile = %s",
                name,month,day,hour,minute,score,totalPoints,totalWeight,specification,datafile);
        Assert.assertTrue(s.equals(object.toString()));
    }
}