import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

public class AssignmentTest {
    private static final String NAME = "Unit Testing";
    private static final int DAY = 1;
    private static final int MONTH = 9;
    private static final int HOUR = 23;
    private static final int MINUTE = 59;
    private static final double SCORE = 0.93;
    private static final double TOTALPOINTS = 0.99;
    private static final double TOTALWEIGHT = 0.30;
    private static final double ACCURACY = 0.000001;
    private static Assignment item;
    @BeforeClass
    public static void assignmentTestSetup()
    {
        item = new Assignment(NAME, MONTH, DAY, HOUR, MINUTE);
        item.setScore(SCORE);
        item.setTotalPoints(TOTALPOINTS);
        item.setTotalWeight(TOTALWEIGHT);
    }
    @Test
    public void assignmentGetNameTest()
    {
        Assert.assertTrue("Get name of the Assignment item", NAME.equals(item.getName()));
    }
    @Test
    public void assignmentGetMonthTest()
    {
        Assert.assertEquals("Get month of the Assignment item", MONTH, item.getMonth());
    }
    @Test
    public void assignmentGetDayTest()
    {
        Assert.assertEquals("Get day of the Assignment item", DAY, item.getDay());
    }
    @Test
    public void assignmentGetHourTest()
    {
        Assert.assertEquals("Get hour of the Assignment item", HOUR, item.getHour());
    }
    @Test
    public void gradedItemGetMinuteTest()
    {
        Assert.assertEquals("Get hour of the Assignment item", MINUTE, item.getMinute());
    }
    @Test
    public void assignmentGetScoreTest()
    {
        Assert.assertEquals("Get score of the Assignment item", SCORE, item.getScore(), ACCURACY);
    }
    @Test
    public void assignmentGetTotalPointsTest()
    {
        Assert.assertEquals("Get totalPoints of the Assignment item", TOTALPOINTS, item.getTotalPoints(), ACCURACY);
    }
    @Test
    public void assignmentGetTotalWeightTest()
    {
        Assert.assertEquals("Get totalWeight of the Assignment item", TOTALWEIGHT, item.getTotalWeight(), ACCURACY);
    }
    @Test
    public void assignmentSetGradeTest()
    {
        item.setScore(0.93);
        Assert.assertEquals("Set score of the Assignment item", 0.93, item.getScore(), ACCURACY);
        item.setScore(SCORE);
    }
    @Test
    public void assignmentSetTotalPointsTest()
    {
        item.setTotalPoints(0.99);
        Assert.assertEquals("Set totalPoints of the Assignment item", 0.99, item.getTotalPoints(), ACCURACY);
        item.setTotalPoints(TOTALPOINTS);
    }
    @Test
    public void assignmentSetTotalWeightTest()
    {
        item.setTotalWeight(0.30);
        Assert.assertEquals("Set totalWeight of the Assignment item", 0.30, item.getTotalWeight(), ACCURACY);
        item.setTotalWeight(TOTALWEIGHT);
    }
    @Test
    public void assignmentToStringTest()
    {
        String expected = String.format(
                "%s (date: %02d %02d at %02d:%02d): score = %.2f; totalPoints = %.2f; totalWeight = %.2f",
                NAME, MONTH, DAY, HOUR, MINUTE, SCORE, TOTALPOINTS, TOTALWEIGHT);

        Assert.assertTrue(expected.equals(item.toString()));
    }
}
