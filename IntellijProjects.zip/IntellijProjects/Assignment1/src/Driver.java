public class Driver {
    public static void main(String[] args)
    {
        AssignmentList list = new AssignmentList();
        Assignment test=new Assignment("Unit Testing",12,1,23,0);
        Lab obj=new Lab("Unit Testing",12,1,23,0,"Java Lectures.pdf");
        Project obj2=new Project("Unit Testing",12,1,23,0,"Java Lectures.pdf","Assignment.csv");
        list.addItem(obj);
        list.addItem(obj2);
        test.setScore(0.78);
        test.setTotalPoints(0.99);
        test.setTotalWeight(0.30);
        obj.setScore(0.78);
        obj.setTotalPoints(0.99);
        obj.setTotalWeight(0.30);
        obj2.setScore(0.78);
        obj2.setTotalPoints(0.99);
        obj2.setTotalWeight(0.30);
        System.out.println(list.toString());
        System.out.println("Course Grade = "+String.format("%.2f",list.computeCourseGrade()));
    }
}
