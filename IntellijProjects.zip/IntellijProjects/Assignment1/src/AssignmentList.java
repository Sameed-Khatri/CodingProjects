import java.util.ArrayList;

public class AssignmentList {
        public ArrayList<Assignment> itemList;
        public AssignmentList()
        {
            itemList = new ArrayList<Assignment>();

        }

        public void addItem(Assignment item)
        {
            itemList.add(item);
        }

        public double computeCourseGrade()
        {
            int n=itemList.size();
            double score;
            double totalWeight;
            double totalPoints;
            double numerator=0;
            double denominator=0;
            if(n==0)
                return 0;
            for(int i=0;i<n-1;i++){
                score=itemList.get(i).score;
                totalPoints=itemList.get(i).totalPoints;
                totalWeight=itemList.get(i).totalWeight;
                numerator=numerator+(totalWeight*(score/totalPoints));
                denominator=denominator+itemList.get(i).totalWeight;
            }
            return(numerator/denominator);
        }

        public String toString()
        {
            String out = "";
            for (int i = 0; i < itemList.size(); ++i)
            {
                out += itemList.get(i).toString() + "\n";
            }

            return out;
        }
    }
