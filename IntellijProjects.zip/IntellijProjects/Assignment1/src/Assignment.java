public class Assignment {
    String name;
    int month;
    int day;
    int hour;
    int minute;
    double score;
    double totalPoints;
    double totalWeight;
    public Assignment(String name, int month, int day, int hour, int minute){
        this.name=name;
        this.month=month;
        this.day=day;
        this.hour=hour;
        this.minute=minute;
    }
    public String getName(){
        return name;
    }
    public int getMonth(){
        return month;
    }
    public int getDay(){
        return day;
    }
    public int getHour(){
        return hour;
    }
    public int getMinute(){
        return minute;
    }
    public void setScore(double score){
        this.score=score;
    }
    public double getScore(){
        return score;
    }
    public void setTotalPoints(double points){
        this.totalPoints=points;
    } public double getTotalPoints(){
        return totalPoints;
    }
    public void setTotalWeight(double weight){
        this.totalWeight=weight;
    }
    public double getTotalWeight(){
        return totalWeight;
    }
    public String toString(){
//        return(name+" (date: "+month+"-"+day+" at "+hour+":"+minute+"): score = "+score+"; totalPoints = "+totalPoints+"; totalWeight = "+totalWeight);
        String s = String.format(
                "%s (date: %02d %02d at %02d:%02d): score = %.2f; totalPoints = %.2f; totalWeight = %.2f",
                name,month,day,hour,minute, score, totalPoints, totalWeight);
        return s;
    }
}

class Lab extends Assignment{
    String specification;
    public Lab(String name, int month, int day, int hour, int minute, String specification) {
        super(name, month, day, hour, minute);
        this.specification=specification;
    }
    public String toString(){
        String s = String.format(
                "%s (date: %02d %02d at %02d:%02d): score = %.2f; totalPoints = %.2f; totalWeight = %.2f; specification on = %s",
                name,month,day,hour,minute,score,totalPoints,totalWeight,specification);
//        return(super.toString()+" ; specification on = "+specification);
        return s;
    }
}

class Project extends Assignment{
    String specification;
    String dataFile;
    public Project(String name, int month, int day, int hour, int minute, String specification, String dataFile) {
        super(name, month, day, hour, minute);
        this.specification=specification;
        this.dataFile=dataFile;
    }
    public String toString(){
        String s = String.format(
                "%s (date: %02d %02d at %02d:%02d): score = %.2f; totalPoints = %.2f; totalWeight = %.2f; specification on = %s; datafile = %s",
                name,month,day,hour,minute,score,totalPoints,totalWeight,specification,dataFile);
//        return (super.toString()+" ; specification on = "+specification+" ; datafile = "+dataFile);
        return s;
    }
}
