/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
/**
 *
 * @author hp
 */
public class register extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Connection con=null;
        Statement stmt=null;
        PrintWriter out=response.getWriter();
        String firstName=request.getParameter("firstname");
        String lastName=request.getParameter("lastname");
        String country=request.getParameter("country");
        String city=request.getParameter("city");
        String phoneNumber=request.getParameter("phone");
        String email=request.getParameter("email");
        String password=request.getParameter("password");
        
        try{
            Class.forName("org.sqlite.JDBC");
            con=DriverManager.getConnection("jdbc:sqlite:AppTest1.db");
            stmt=con.createStatement();
            stmt.executeUpdate("INSERT INTO user (firstName, lastName, country, city, phoneNumber, email, password) " +
                "VALUES ('" + firstName + "', '" + lastName + "', '" + country + "', '" + city + "', '" +
                phoneNumber + "', '" + email + "', '" + password + "')");
            out.print("Success");
        }
        catch(Exception e){
            out.print("failure");
        }
    }
}
