import java.awt.Color;
public class Warmup_Practice {
    public static void main(String[] args) {
        Color black=new Color(0,0,0);	//instantiated Color object from class Color using the color code for black color
        Color red=new Color(255,0,0);	//instantiated Color object from class Color using the color code for red color
        StdDraw.setPenColor(black);		//setting pen color to black
        StdDraw.circle(0.3,0.3,0.1);   //black circle
        StdDraw.setPenColor(red);		//setting pen color to red
        StdDraw.filledSquare(0.6,0.6,0.1);   //red filled square
        StdDraw.show();	//shows the shapes drawn by the code
    }
}
