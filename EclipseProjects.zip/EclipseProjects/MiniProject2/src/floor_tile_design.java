import java.awt.Color;     //imported and stdlib.jar added to project

public class floor_tile_design {
    public static void main(String[] args) {
        Color black=new Color(0,0,0);  //instantiated Color object from class Color using the color code for black color
        Color red=new Color(255,0,0);  //instantiated Color object from class Color using the color code for red color
        int n=Integer.parseInt(args[0]); //input parameter from Run Configuration Arguments
        if(n>=2 && n<=50) {	//checks if the value of n is in given range
        	StdDraw.setXscale(0,n);  //setting the x-axis range (from 0 -- n) on the canvas to draw shapes in n rows of canvas
        	StdDraw.setYscale(0,n);  //setting the y-axis range (from 0 -- n) on the canvas to draw shapes in n columns of canvas
        	for(int x=0; x<n; x++){	//outer loop to shift columns 
        		for(int y=0; y<n; y++){  //inner loop to shift rows
        			if((x+y)%2==0){		//condition that checks if the sum of x and y is even or odd to switch between shape and its respective color
        				StdDraw.setPenColor(red);  //method used as per requirement to set the pen color to red
        				StdDraw.filledSquare(x+0.5,y+0.5,0.5);  //method used as per requirement to draw filled square with the pen color set in the previous line
        			}
        			else{
        				StdDraw.setPenColor(black);  //method used as per requirement to set the pen color to black
        				StdDraw.circle(x+0.5,y+0.5,0.5);  //method used as per requirement to draw circle with the pen color set in the previous line
        				//since the code is iterating on values of x and y so using x+0.5, y+0.5 tells the coordinate of the center of the grid/cell of a row and column on canvas, that is scaled according to the value of n, on which a shape is drawn  
        			} 
        		}
        	}
        	System.out.println("n = "+n);
        	StdDraw.show();  //shows the pattern drawn by the code
        }
        else {  //print statements to highlight any incorrect argument value of n that is outside the defined range
        	System.out.println("The input value of parameter n is : "+n);
        	System.out.println("Please enter the value of parameter n within the range of : 20 <= n <= 50 ");
        }
    }
}
