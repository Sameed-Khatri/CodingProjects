package newproject;

public class trytype {

}
