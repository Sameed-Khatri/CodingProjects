import java.util.Scanner;
public class Words_Score {										
 public static boolean is_vowel(char letter) {		//takes a character as an input argument and checks if it is a vowel or not			
	 if(letter=='a' || letter=='e'||letter=='i'||letter=='o'||letter=='u'||letter=='y') {	//condition to tell that the input letter is a vowel
		 return true;
	 }
	 else 
		 return false;			//false is returned to tell that input letter is not a vowel
 }
 public static int score_word(String word) {		//takes a string which has to be a valid lower case English-language word and tells the score of that word
	 int m=0;
	 int score;
	 for(int i=0;i<word.length();i++) {
		 char c=word.charAt(i);			//separates each character of the input string
		 if(is_vowel(c)) {				//checks if that character is a vowel or not by calling the is_vowel function
			 m++;						//if is_vowel function returns true then the value of m is incremented and this continues until all the characters of the input string are checked
		 }
	 }
	 if(m>=3)							//the conditions to update the score based on the last updated value of m and the score is returned at last
		 score=2;
	 else if(m>=1 && m<3)
		 score=1;
	 else
		 score=0;
	 return score;
 }
 public static int score_words(String[]list_of_words) {	//the user input is split into an array of strings which is the input argument in this function
	 int score_list=0;								//a variable that calculates the total score of all the words in the user input/the array
	 for(int i=0;i<list_of_words.length;i++) {
		 String s= list_of_words[i];			//for loop takes every word in the string input array 
		 int temp=score_word(s);				//score_word function is called to get the score of the word in the current cell of the array 
		 score_list=score_list+temp;
	 }
	 return score_list;							//final score of the entire user input is returned
 }
// public static void main(String[]args) {
//	 System.out.println("Enter number of words between 0 and 21 exclusive");
//     Scanner sc=new Scanner(System.in);    	//creating a scanner to get user input
//     int n=sc.nextInt();					//fetching the value of n form user
//     if(n<=0 || n>=21){						//condition of range of n 
//         System.out.println("Number of words are not in the limit, re run the code ");
//     }
//     String s;
//     System.out.println("Enter "+n+" space-separated lower case english words ");
//     sc.nextLine();
//     s=sc.nextLine();     		//fetching the input line with words from user
//     String[]words=s.split(" ");		//separating the words in user input using blank space and placing them in an array
//     for(int i=0;i< words.length;i++){	//this loop checks the condition if the length of each word is exceeding 15 or not 
//         String temp=words[i];
//         if(temp.length()>15){
//             System.out.println("Number of letters are not in the limit, re run the code with correct input");
//         }
//         else{					
//             for(int j=0;j<temp.length();j++){		//this loop checks if the characters in each word of user input are lower case or not
//                 char c=temp.charAt(i);
//                 if(! Character.isLowerCase(c)){
//                     System.out.println("Letter is not in lower case format, re run the code with correct input");
//                 }
//             }
//         }
//     }
//     int score=score_words(words);		//score_words function is called which takes the input of array that has all the words given by user and it returns the total score of all the words 
//     System.out.println("Word score is :");
//     System.out.println(score);
//     sc.close();					//scanner closed
// }
}
