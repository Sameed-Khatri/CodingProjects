public class PopularityOption {
    String[]options={"NO_TXN","Max_ON_TXN","Min_ON_TXN"};
    public void setOptions(String[] options) {
        this.options = options;
    }
    public String[] getOptions() {
        return options;
    }

}
