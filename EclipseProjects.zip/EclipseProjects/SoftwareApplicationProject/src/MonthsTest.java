import org.junit.Assert;
import org.junit.jupiter.api.Test;

class MonthsTest {
    @Test
    public void testMonthElements() {
        Months monthsObj = new Months();
        String[] expected = {
                "January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"};
        String[] actual = monthsObj.getMonths();

        Assert.assertArrayEquals(expected, actual);
    }
}