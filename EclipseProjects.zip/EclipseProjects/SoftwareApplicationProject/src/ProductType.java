public class ProductType {
    String[]type={"vegetable","fruit","meat","bakery","pet","baby","beauty"};
    public ProductType() {
    	
    }
    public void setType(String[] type) {
        this.type = type;
    }
    public String[] getType() {
        return type;
    }
}
