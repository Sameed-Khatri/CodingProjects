import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class SQLiteDataBase {
    private static final String DATABASE_URL = "jdbc:sqlite:SuperMarketDatabase.db";

    public void createDatabase() {
        try (Connection connection = DriverManager.getConnection(DATABASE_URL)) {
            if (connection != null) {
                System.out.println("Connected to SQLite database.");

                // Create the necessary tables
                createProductsTable(connection);
                createSellingHistoryTable(connection);

                System.out.println("Database creation completed.");
            }
        } catch (SQLException e) {
            System.out.println("Error creating database: " + e.getMessage());
        }
    }
    private void createProductsTable(Connection connection) throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS products (" +
                "ProductName TEXT NOT NULL," +
                "ProductType TEXT NOT NULL," +
                "ProductQuantity INTEGER NOT NULL" +
                ")";

        try (Statement statement = connection.createStatement()) {
            statement.execute(sql);
        }
    }
    private void createSellingHistoryTable(Connection connection) throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS SellingHistory (" +
                "ProductName TEXT NOT NULL," +
                "ProductType TEXT NOT NULL," +
                "ProductQuantity INTEGER NOT NULL," +
                "SellingYear TEXT NOT NULL," +
                "SellingMonth TEXT NOT NULL" +
                ")";

        try (Statement statement = connection.createStatement()) {
            statement.execute(sql);
        }
    }

    public static void main(String[] args) {
        SQLiteDataBase marketDatabase=new SQLiteDataBase();
        marketDatabase.createDatabase();
    }
}
