import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DeletePreviousTables {
    public static void deleteTables(){
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:SuperMarketDatabase.db")) {
            // Create the SQL statement to drop the table
            String tableName = "SellingHistory";
            String sql = "DROP TABLE IF EXISTS " + tableName;

            // Create a statement object
            try (Statement statement = connection.createStatement()) {
                // Execute the SQL statement
                statement.executeUpdate(sql);
                System.out.println("Table " + tableName + " deleted successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:SuperMarketDatabase.db")) {
            // Create the SQL statement to drop the table
            String tableName = "products";
            String sql = "DROP TABLE IF EXISTS " + tableName;

            // Create a statement object
            try (Statement statement = connection.createStatement()) {
                // Execute the SQL statement
                statement.executeUpdate(sql);
                System.out.println("Table " + tableName + " deleted successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public static void main(String[] args) {
        deleteTables();
    }
}
