import org.junit.Assert;
import org.junit.jupiter.api.Test;

class PopularityOptionTest {
    @Test
    public void testMonthElements() {
        PopularityOption popularityOptionObj = new PopularityOption();
        String[] expected = {"NO_TXN","Max_ON_TXN","Min_ON_TXN"};
        String[] actual = popularityOptionObj.getOptions();

        Assert.assertArrayEquals(expected, actual);
    }
}