import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.SpinnerNumberModel;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.awt.event.ActionEvent;

public class SellingStatistics extends JFrame {

	public JPanel SellingStatisticsPanel;
	private static final String DATABASE_URL = "jdbc:sqlite:SuperMarketDatabase.db";

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					SellingStatistics frame = new SellingStatistics();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public SellingStatistics() {
		int targetYearValue=2023;
		setTitle("Selling Statistics");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		SellingStatisticsPanel = new JPanel();
		SellingStatisticsPanel.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(SellingStatisticsPanel);
		SellingStatisticsPanel.setLayout(null);
		
		JLabel SellingStatisticsLabel = new JLabel("Selling Statistics");
		SellingStatisticsLabel.setHorizontalAlignment(SwingConstants.CENTER);
		SellingStatisticsLabel.setBounds(128, 11, 154, 14);
		SellingStatisticsPanel.add(SellingStatisticsLabel);
		
		JLabel typeLabel = new JLabel("Type");
		typeLabel.setBounds(27, 47, 46, 14);
		SellingStatisticsPanel.add(typeLabel);
		
		JLabel yearLabel = new JLabel("Year");
		yearLabel.setBounds(27, 91, 46, 14);
		SellingStatisticsPanel.add(yearLabel);
		
		JLabel monthLabel = new JLabel("Month");
		monthLabel.setBounds(27, 143, 46, 14);
		SellingStatisticsPanel.add(monthLabel);
		
		JLabel optionLabel = new JLabel("Option");
		optionLabel.setBounds(27, 199, 46, 14);
		SellingStatisticsPanel.add(optionLabel);
		
		JComboBox<String>TypeComboBox = new JComboBox<>();
		ProductType type=new ProductType();
        TypeComboBox.addItem("--");
        String[]types= type.getType();
        for(int i=0;i< types.length;i++){
            TypeComboBox.addItem(types[i]);
        }
		TypeComboBox.setBounds(112, 43, 88, 22);
		SellingStatisticsPanel.add(TypeComboBox);
		
		JSpinner YearSpinner = new JSpinner();
		YearSpinner.setBounds(112, 88, 88, 20);
		SellingStatisticsPanel.add(YearSpinner);
		
		JComboBox<String>MonthComboBox = new JComboBox<>();
		Months month=new Months();
        MonthComboBox.addItem("--");
        String[]months=month.getMonths();
        for(int i=0;i< months.length;i++){
            MonthComboBox.addItem(months[i]);
        }
		MonthComboBox.setBounds(112, 139, 88, 22);
		SellingStatisticsPanel.add(MonthComboBox);
		
		JComboBox<String>OptionComboBox = new JComboBox<>();
		PopularityOption option=new PopularityOption();
        String[]options= option.getOptions();
        for(int i=0;i< options.length;i++){
            OptionComboBox.addItem(options[i]);
        }
		OptionComboBox.setBounds(112, 195, 88, 22);
		SellingStatisticsPanel.add(OptionComboBox);
		OptionComboBox.setSelectedIndex(0);
        YearSpinner.setModel(new SpinnerNumberModel(2023, 1900, 2100, 1));
        JSpinner.NumberEditor editor = (JSpinner.NumberEditor) YearSpinner.getEditor();
        DecimalFormat format = editor.getFormat();
        format.setGroupingUsed(false);
        YearSpinner.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                JSpinner spinner = (JSpinner) e.getSource();
                SpinnerNumberModel spinnerModel = (SpinnerNumberModel) spinner.getModel();
                spinnerModel.setMinimum(1900); // Set minimum year value
                spinnerModel.setMaximum(2100); // Set maximum year value
            }
        });
        YearSpinner.setValue(targetYearValue);
		
		JLabel popularityLabel = new JLabel("Popularity");
		popularityLabel.setHorizontalAlignment(SwingConstants.CENTER);
		popularityLabel.setBounds(265, 91, 130, 14);
		SellingStatisticsPanel.add(popularityLabel);
		
		JTextArea PopularityTextArea = new JTextArea();
		PopularityTextArea.setBounds(210, 116, 224, 74);
		SellingStatisticsPanel.add(PopularityTextArea);
		
		JButton showButton = new JButton("Show");
		showButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String productType=(String)TypeComboBox.getSelectedItem();
                String sellYear=String.valueOf(YearSpinner.getValue());
                String sellMonth=(String)MonthComboBox.getSelectedItem();
                String popularityOption=(String)OptionComboBox.getSelectedItem();
                try(Connection connection = DriverManager.getConnection(DATABASE_URL)){
                    String check = "SELECT ProductName, ProductQuantity FROM SellingHistory WHERE ProductType = ? AND SellingMonth = ? AND SellingYear = ?";
                    PreparedStatement statement = connection.prepareStatement(check);
                    statement.setString(1,productType);
                    statement.setString(2,sellMonth);
                    statement.setString(3,sellYear);
                    ResultSet resultSet= statement.executeQuery();
                    String output="";
                    if(popularityOption.equals("Max_ON_TXN")){
                        int maxSellQuantity=Integer.MIN_VALUE;
                        String mostPopularProductName="";
                        while(resultSet.next()){
                            String name=resultSet.getString("ProductName");
                            int sellQuantity=resultSet.getInt("ProductQuantity");
                            if(sellQuantity>maxSellQuantity){
                                maxSellQuantity=sellQuantity;
                                mostPopularProductName=name;
                            }
                        }
                        output=mostPopularProductName+" is the most popular product";
                    }
                    else if(popularityOption.equals("Min_ON_TXN")) {
                        int minSellQuantity = Integer.MAX_VALUE;
                        String leastPopularProductName = "";
                        while (resultSet.next()) {
                            String name = resultSet.getString("ProductName");
                            int sellQuantity = resultSet.getInt("ProductQuantity");
                            if (sellQuantity < minSellQuantity) {
                                minSellQuantity = sellQuantity;
                                leastPopularProductName = name;
                            }
                        }
                        output = leastPopularProductName + " is the least popular product";
                    }
                    else{
                        output = "no products in the table";
                    }
                    PopularityTextArea.setText(output);
                    resultSet.close();
                    statement.close();
                }
                catch (SQLException exception){
                    System.out.println(exception.getMessage());
                }
			}
		});
		showButton.setBounds(226, 214, 89, 23);
		SellingStatisticsPanel.add(showButton);
		
		JButton ClearButton = new JButton("Clear");
		ClearButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PopularityTextArea.setText("");
				OptionComboBox.setSelectedIndex(0);
				YearSpinner.setValue(targetYearValue);
				MonthComboBox.setSelectedIndex(0);
				TypeComboBox.setSelectedIndex(0);
			}
		});
		ClearButton.setBounds(340, 214, 74, 23);
		SellingStatisticsPanel.add(ClearButton);
	}

}
