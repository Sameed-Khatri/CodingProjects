import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import javax.swing.JButton;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class MainMenuFrame extends JFrame {

	private JPanel MainMenuPanel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainMenuFrame frame = new MainMenuFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainMenuFrame() {
		setTitle("Main Menu");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		MainMenuPanel = new JPanel();
		MainMenuPanel.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(MainMenuPanel);
		MainMenuPanel.setLayout(null);
//		
		JLabel lblNewLabel = new JLabel("Main Menu");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(135, 34, 152, 14);
		MainMenuPanel.add(lblNewLabel);
		
		JButton importProductsButton = new JButton("Import Products");
		importProductsButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame ImportProductsFrame = new JFrame("Import Products");
				ImportProductsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                ImportProductsFrame.setContentPane(new ImportProductsFrame().importProductsPanel);
                ImportProductsFrame.setLocationRelativeTo(null);
                ImportProductsFrame.setSize(600, 300);
                ImportProductsFrame.setVisible(true);
			}
		});
		importProductsButton.setBounds(135, 83, 152, 23);
		MainMenuPanel.add(importProductsButton);
		
		JButton SellProductsButton = new JButton("Sell Products");
		SellProductsButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame sellProductsFrame = new JFrame("Sell Products");
                sellProductsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                sellProductsFrame.setContentPane(new SellProducts().SellProductsPanel);
                sellProductsFrame.setLocationRelativeTo(null);
                sellProductsFrame.setSize(600,300);
                sellProductsFrame.setVisible(true);
			}
		});
		SellProductsButton.setBounds(135, 141, 152, 23);
		MainMenuPanel.add(SellProductsButton);
		
		JButton StatisticsButton = new JButton("Statistics");
		StatisticsButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame SellingStatisticsFrame = new JFrame("Statistics");
                SellingStatisticsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                SellingStatisticsFrame.setContentPane(new SellingStatistics().SellingStatisticsPanel);
                SellingStatisticsFrame.setLocationRelativeTo(null);
                SellingStatisticsFrame.setSize(600,300);
                SellingStatisticsFrame.setVisible(true);
			}
		});
		StatisticsButton.setBounds(135, 199, 152, 23);
		MainMenuPanel.add(StatisticsButton);
	}

}
