import org.junit.Assert;
import org.junit.jupiter.api.Test;

class TypeTest {
 @Test
 public void testTypeElements() {
     ProductType typeObj = new ProductType();
     String[] expected = {"vegetable", "fruit", "meat", "bakery", "pet", "baby", "beauty"};
     String[] actual = typeObj.getType();

     Assert.assertArrayEquals(expected, actual);
 }
}