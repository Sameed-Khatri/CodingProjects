import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.awt.event.ActionEvent;

public class SellProducts extends JFrame {

	public JPanel SellProductsPanel;
	private JTextField productNameText;
	private JTextField productQuantityText;
	private static final String DATABASE_URL = "jdbc:sqlite:SuperMarketDatabase.db";

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					SellProducts frame = new SellProducts();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public SellProducts() {
		int targetYearValue=2023;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		SellProductsPanel = new JPanel();
		SellProductsPanel.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(SellProductsPanel);
		SellProductsPanel.setLayout(null);
		
		JLabel SellProductsLabel = new JLabel("Sell Products");
		SellProductsLabel.setHorizontalAlignment(SwingConstants.CENTER);
		SellProductsLabel.setBounds(138, 11, 153, 14);
		SellProductsPanel.add(SellProductsLabel);
		
		JLabel ProductNameLabel = new JLabel("Product Name");
		ProductNameLabel.setBounds(10, 47, 82, 14);
		SellProductsPanel.add(ProductNameLabel);
		
		JLabel ProductQuantityLabel = new JLabel("Product Quantity");
		ProductQuantityLabel.setBounds(10, 88, 99, 14);
		SellProductsPanel.add(ProductQuantityLabel);
		
		JLabel ProductTypeLabel = new JLabel("Product Type");
		ProductTypeLabel.setBounds(10, 139, 82, 14);
		SellProductsPanel.add(ProductTypeLabel);
		
		JLabel SellingDateLabel = new JLabel("Selling Date");
		SellingDateLabel.setBounds(10, 194, 82, 14);
		SellProductsPanel.add(SellingDateLabel);
		
		productNameText = new JTextField();
		productNameText.setBounds(119, 44, 86, 20);
		SellProductsPanel.add(productNameText);
		productNameText.setColumns(10);
		
		productQuantityText = new JTextField();
		productQuantityText.setBounds(119, 85, 86, 20);
		SellProductsPanel.add(productQuantityText);
		productQuantityText.setColumns(10);
		
		JComboBox<String>productTypeComboBox = new JComboBox<>();
		ProductType type=new ProductType();
        productTypeComboBox.addItem("--");
        String[]types= type.getType();
        for(int i=0;i< types.length;i++){
            productTypeComboBox.addItem(types[i]);
        }
		productTypeComboBox.setBounds(119, 135, 86, 22);
		SellProductsPanel.add(productTypeComboBox);
		
		JComboBox<String>sellMonthComboBox = new JComboBox<>();
		Months month=new Months();
        sellMonthComboBox.addItem("--");
        String[]months=month.getMonths();
        for(int i=0;i< months.length;i++){
            sellMonthComboBox.addItem(months[i]);
        }
		sellMonthComboBox.setBounds(119, 190, 86, 22);
		SellProductsPanel.add(sellMonthComboBox);
		
		JSpinner sellYearSpinner = new JSpinner();
		sellYearSpinner.setBounds(215, 191, 57, 20);
		SellProductsPanel.add(sellYearSpinner);
		sellYearSpinner.setModel(new SpinnerNumberModel(2023, 1900, 2100, 1));
        JSpinner.NumberEditor editor = (JSpinner.NumberEditor) sellYearSpinner.getEditor();
        DecimalFormat format = editor.getFormat();
        format.setGroupingUsed(false);
        sellYearSpinner.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                JSpinner spinner = (JSpinner) e.getSource();
                SpinnerNumberModel spinnerModel = (SpinnerNumberModel) spinner.getModel();
                spinnerModel.setMinimum(1900); // Set minimum year value
                spinnerModel.setMaximum(2100); // Set maximum year value
            }
        });
		
		JLabel StatusLabel = new JLabel("Status");
		StatusLabel.setHorizontalAlignment(SwingConstants.CENTER);
		StatusLabel.setBounds(284, 88, 92, 14);
		SellProductsPanel.add(StatusLabel);
		
		JTextArea statusTextArea = new JTextArea();
		statusTextArea.setBounds(227, 113, 207, 58);
		SellProductsPanel.add(statusTextArea);
		
		JButton sellButton = new JButton("Sell");
		sellButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String productName=productNameText.getText();
                String productType=(String)productTypeComboBox.getSelectedItem();
                int productQuantity=Integer.parseInt(productQuantityText.getText());
                String sellYear=String.valueOf(sellYearSpinner.getValue());
                String sellMonth=(String)sellMonthComboBox.getSelectedItem();
                boolean status=sell(productName,productType,productQuantity,sellYear,sellMonth);
                if(status){
                    statusTextArea.setText("Product Sold Successfully");
                    
                }
                else{
                    statusTextArea.setText("Not Enough Products");
                }
			}
		});
		sellButton.setBounds(183, 227, 89, 23);
		SellProductsPanel.add(sellButton);
		
		JButton ClearButton = new JButton("Clear");
		ClearButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				statusTextArea.setText("");
				productNameText.setText("");
                productTypeComboBox.setSelectedIndex(0);
                productQuantityText.setText("");
                sellMonthComboBox.setSelectedIndex(0);
                sellYearSpinner.setValue(targetYearValue);
			}
		});
		ClearButton.setBounds(313, 227, 89, 23);
		SellProductsPanel.add(ClearButton);
	}
	public boolean sell(String productName, String productType, int productQuantity, String sellYear, String sellMonth) {
        try (Connection connection = DriverManager.getConnection(DATABASE_URL)) {
            String matchProduct = "SELECT ProductQuantity FROM products WHERE ProductName = ?";
            PreparedStatement selectStatement = connection.prepareStatement(matchProduct);
            selectStatement.setString(1, productName);
            ResultSet resultSet = selectStatement.executeQuery();

            if(resultSet.next()){
                int currentProductQuantity=resultSet.getInt("ProductQuantity");
                int remainingQuantity=currentProductQuantity-productQuantity;
                if(remainingQuantity>=0){
                    String updateProduct="UPDATE products SET ProductQuantity = ? WHERE ProductName = ?";
                    PreparedStatement updateStatement = connection.prepareStatement(updateProduct);
                    updateStatement.setInt(1,remainingQuantity);
                    updateStatement.setString(2,productName);
                    int rowsUpdated=updateStatement.executeUpdate();
                    updateStatement.close();

                    if(rowsUpdated>0){
                        String insertSaleDone="INSERT INTO SellingHistory (ProductName, ProductType, ProductQuantity, SellingYear, SellingMonth) VALUES (?, ?, ?, ?, ?)";
                        PreparedStatement insertSaleStatement=connection.prepareStatement(insertSaleDone);
                        insertSaleStatement.setString(1,productName);
                        insertSaleStatement.setString(2,productType);
                        insertSaleStatement.setInt(3,productQuantity);
                        insertSaleStatement.setString(4,sellYear);
                        insertSaleStatement.setString(5,sellMonth);
                        int saleInserted=insertSaleStatement.executeUpdate();
                        insertSaleStatement.close();
                        return saleInserted>0;
                    }
                }
            }
            resultSet.close();
            selectStatement.close();
        }
        catch (SQLException e){
            System.out.println(e.getMessage());
        }
        return false;
	}
}
