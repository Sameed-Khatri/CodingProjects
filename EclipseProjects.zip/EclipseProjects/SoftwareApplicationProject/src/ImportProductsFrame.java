import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class ImportProductsFrame extends JFrame {

	public JPanel importProductsPanel;
	private JTextField ProductNameText;
	private JTextField ProductQuantityText;
	private JTextArea ImportStatusTextArea;
	private JComboBox<String>ProductTypeComboBox;
	private JButton ImportButton;
	private static final String DATABASE_URL = "jdbc:sqlite:SuperMarketDatabase.db";
	private JButton ClearButton;
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					ImportProductsFrame frame = new ImportProductsFrame();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}
	
	/**
	 * Create the frame.
	 */
	public ImportProductsFrame() {
		setTitle("Import Products");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		importProductsPanel = new JPanel();
		importProductsPanel.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(importProductsPanel);
		importProductsPanel.setLayout(null);
		
		JLabel ProductNameLabel = new JLabel("Product Name");
		ProductNameLabel.setBounds(10, 61, 89, 14);
		importProductsPanel.add(ProductNameLabel);
		
		JLabel ImportProductsLabel = new JLabel("Import Products");
		ImportProductsLabel.setBounds(156, 11, 77, 14);
		importProductsPanel.add(ImportProductsLabel);
		
		JLabel ProductTypeLabel = new JLabel("Product Type");
		ProductTypeLabel.setBounds(10, 120, 89, 14);
		importProductsPanel.add(ProductTypeLabel);
		
		JLabel ProductQuantityLabel = new JLabel("Product Quantity");
		ProductQuantityLabel.setBounds(10, 190, 116, 14);
		importProductsPanel.add(ProductQuantityLabel);
		
		ProductNameText = new JTextField();
		ProductNameText.setBounds(147, 58, 86, 20);
		importProductsPanel.add(ProductNameText);
		ProductNameText.setColumns(10);
		
		ProductQuantityText = new JTextField();
		ProductQuantityText.setBounds(147, 187, 86, 20);
		importProductsPanel.add(ProductQuantityText);
		ProductQuantityText.setColumns(10);
		
		ProductTypeComboBox = new JComboBox<>();
		ProductType type=new ProductType();
        ProductTypeComboBox.addItem("--");
        String[]types= type.getType();
        for(int i=0;i< types.length;i++){
            ProductTypeComboBox.addItem(types[i]);
        }
		ProductTypeComboBox.setBounds(147, 116, 86, 22);
		importProductsPanel.add(ProductTypeComboBox);
		
		JLabel ImportStatusLabel = new JLabel("Import Status");
		ImportStatusLabel.setBounds(298, 90, 77, 14);
		importProductsPanel.add(ImportStatusLabel);
		
		ImportStatusTextArea = new JTextArea();
		ImportStatusTextArea.setBounds(243, 115, 181, 55);
		importProductsPanel.add(ImportStatusTextArea);
		
		ImportButton = new JButton("Import");
		ImportButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String productName=ProductNameText.getText();
                String productType=(String) ProductTypeComboBox.getSelectedItem();
                int productQuantity=Integer.parseInt(ProductQuantityText.getText());
                boolean status=addProductInTable(productName,productType,productQuantity);
                if(status){
                    ImportStatusTextArea.setText("Product Imported Successfully");
                    
                }
                else
                    ImportStatusTextArea.setText("Failed to Import Product");
			}
		});
		ImportButton.setBounds(147, 227, 89, 23);
		importProductsPanel.add(ImportButton);
		
		ClearButton = new JButton("Clear");
		ClearButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImportStatusTextArea.setText("");
				ProductNameText.setText("");
                ProductTypeComboBox.setSelectedIndex(0);
                ProductQuantityText.setText("");
			}
		});
		ClearButton.setBounds(286, 227, 89, 23);
		importProductsPanel.add(ClearButton);
	}
	public boolean addProductInTable(String productName, String productType, int productQuantity){
		try(Connection connection= DriverManager.getConnection(DATABASE_URL)){
            String matchProduct = "SELECT ProductQuantity FROM products WHERE ProductName = ?";
            PreparedStatement selectStatement=connection.prepareStatement(matchProduct);
            selectStatement.setString(1,productName);
            ResultSet resultSet=selectStatement.executeQuery();

            if(resultSet.next()){
                int currentProductQuantity=resultSet.getInt("ProductQuantity");
                int newProductQuantity=currentProductQuantity+productQuantity;
                String updateProduct = "UPDATE products SET ProductQuantity = ? WHERE ProductName = ?";
                PreparedStatement updateStatement = connection.prepareStatement(updateProduct);
                updateStatement.setInt(1, newProductQuantity);
                updateStatement.setString(2, productName);
                int rowsUpdated = updateStatement.executeUpdate();
                updateStatement.close();
                resultSet.close();
                selectStatement.close();
                return rowsUpdated>0;
            }
            else{
                String insertProducts = "INSERT INTO products (ProductName, ProductType, ProductQuantity) VALUES (?, ?, ?)";
                PreparedStatement insertStatement = connection.prepareStatement(insertProducts);
                insertStatement.setString(1,productName);
                insertStatement.setString(2,productType);
                insertStatement.setInt(3,productQuantity);
                int rowsInserted=insertStatement.executeUpdate();
                insertStatement.close();
                resultSet.close();
                selectStatement.close();
                return rowsInserted>0;
            }
        }
        catch (SQLException e){
            System.out.println(e.getMessage());
        }
        return false;
	}
}
