/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package card;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 *
 * @author hp
 */
public class Register extends HttpServlet {
    Front front=new Front();
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out=response.getWriter();
        String firstName=request.getParameter("firstname");
        String lastName=request.getParameter("lastname");
        String country=request.getParameter("country");
        String city=request.getParameter("city");
        String phoneNumber=request.getParameter("phone");
        String email=request.getParameter("email");
        String password=request.getParameter("password");
        front.insertUser(firstName, lastName, country, city, phoneNumber, email, password);
//        String s=front.printUsers();
        out.print(firstName+lastName+country+city+phoneNumber+email+password);
//        out.print(s);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
