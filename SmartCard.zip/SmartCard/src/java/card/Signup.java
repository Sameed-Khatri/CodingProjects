/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package card;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 *
 * @author hp
 */
@WebServlet(name = "Signup", urlPatterns = {"/Signup"})
public class Signup extends HttpServlet {
    Front front=new Front();
    @Override
     protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out=response.getWriter();
        String firstName = request.getParameter("firstname");
        System.out.println("First Name: " + firstName);
        String lastName = request.getParameter("lastname");
        String country = request.getParameter("country");
        String city = request.getParameter("city");
        String phoneNumber = request.getParameter("phone");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
//        front.print(firstName, lastName, country, city, phoneNumber, email, password);
        // Call the method from the Front class to insert user data into the database
        front.insertUser(firstName, lastName, country, city, phoneNumber, email, password);
        out.print(firstName+lastName+country+city+phoneNumber+email+password);

        // Redirect to a success page or display a success message
        response.sendRedirect("success.html");
    }

    @Override
    public String getServletInfo() {
        return "Signup Servlet";
    }
}
