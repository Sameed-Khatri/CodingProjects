import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SQLiteDatabaseCreator {

    public static void createDatabase(String dbName) {
        Connection connection = null;

        try {
            // Register the JDBC driver (SQLite driver)
            Class.forName("org.sqlite.JDBC");

            // Establish a connection to the database
            String url = "jdbc:sqlite:" + dbName + ".db";
            connection = DriverManager.getConnection(url);

            System.out.println("Database created successfully at path: " + url);

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        createDatabase("SmartBusinessCard");
    }
}
